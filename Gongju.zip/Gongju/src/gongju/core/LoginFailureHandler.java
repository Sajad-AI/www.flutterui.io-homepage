package gongju.core;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;

public class LoginFailureHandler implements AuthenticationFailureHandler {
	
	private static final Log logger = LogFactory.getLog(LoginSuccessHandler.class);

	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException auth) throws IOException, ServletException {
		logger.error("*****************************************************************************************");
		logger.error("********  Oops! Login Failure, Please Check Your Id Or Password, And Try Again.  ********");
		logger.error("*****************************************************************************************");
		
		HttpSession session = request.getSession();
		int cnt = 0;
		if(session!=null){
			Object o = session.getAttribute("BadCredentialsCnt");
			if(o!=null)cnt=(Integer)o;
		}
		
		session.setAttribute("BadCredentialsCnt", ++cnt);
		logger.error("Login Failure Count : " + cnt);
		
		response.sendRedirect(request.getContextPath() + "/");
		
		if(cnt>=3){
			// Do something in database.
		}
	}

}
