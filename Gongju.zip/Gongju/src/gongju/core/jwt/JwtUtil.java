package gongju.core.jwt;

import java.time.ZonedDateTime;
import java.util.Date;

import gongju.model.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JwtUtil {
	
	private static final String SECURITY_TOKEN_KEY = "gongju__DASH_";
	
	public static User parseToken(String token) {
		User u = null;
		try {
		    Claims body = Jwts.parser()
		            .setSigningKey(SECURITY_TOKEN_KEY)
		            .parseClaimsJws(token)
		            .getBody();
		
		    u = new User();
		    u.setUserFullName(body.getSubject());
		    u.setUserID((String) body.get("userID"));
		    u.setIsAdminPerm((Boolean) body.get("isAdminPerm"));
		    u.setIsSMSPerm((Boolean) body.get("isSMSPerm"));
		    u.setIsBroadcastPerm((Boolean) body.get("isBroadcastPerm"));
		    u.setIsCCTVViewPerm((Boolean) body.get("isCCTVViewPerm"));
		    u.setIsCCTVCtrlPerm((Boolean) body.get("isCCTVCtrlPerm"));
		    
		} catch (JwtException e) {
			e.printStackTrace();
		}
		
		return u;
	}
	
	public static String generateToken(User u) {
        Claims claims = Jwts.claims().setSubject(u.getUserFullName());
        claims.put("userID", u.getUserID());
        claims.put("isAdminPerm", u.getIsAdminPerm());
        claims.put("isSMSPerm", u.getIsSMSPerm());
        claims.put("isBroadcastPerm", u.getIsBroadcastPerm());
        claims.put("isCCTVViewPerm", u.getIsCCTVViewPerm());
        claims.put("isCCTVCtrlPerm", u.getIsCCTVCtrlPerm());
        
        Date exp = Date.from(ZonedDateTime.now().plusDays(30).toInstant());
        
        return Jwts.builder()
                .setClaims(claims)
                .signWith(SignatureAlgorithm.HS512, SECURITY_TOKEN_KEY)
                .setExpiration(exp)
                .compact();
    }
	
}
