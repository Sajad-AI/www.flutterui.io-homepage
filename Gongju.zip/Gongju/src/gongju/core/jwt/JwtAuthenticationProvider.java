package gongju.core.jwt;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import gongju.core.jwt.exception.JwtTokenMalformedException;
import gongju.dao.LoginDao;
import gongju.model.User;

@Component
public class JwtAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider {

	@Autowired 
	LoginDao loginDao;
	
	@Override
    public boolean supports(Class<?> authentication) {
        return (JwtAuthenticationToken.class.isAssignableFrom(authentication));
    }
	
	@Override
	protected void additionalAuthenticationChecks(UserDetails userDetails,
			UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
		
	}

	@Override
	protected UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication)
			throws AuthenticationException {
		
		JwtAuthenticationToken jwtAuthenticationToken = (JwtAuthenticationToken) authentication;
		
		String token = jwtAuthenticationToken.getToken();
		
		User parsedUser = JwtUtil.parseToken(token);
		
		if(parsedUser == null) {
            throw new JwtTokenMalformedException("JWT token is not valid");
        }
		
		Collection<GrantedAuthority> role = new ArrayList<GrantedAuthority>();
		if(parsedUser.getIsAdminPerm()) {
			role.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
		} else {
			role.add(new SimpleGrantedAuthority("ROLE_USER"));
		}
		
		parsedUser.setAuthorities(role);
		
		return parsedUser;
	}

}
