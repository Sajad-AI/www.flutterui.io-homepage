package gongju.core;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

public class LoginSuccessHandler implements AuthenticationSuccessHandler {
	
	private static final Log logger = LogFactory.getLog(LoginSuccessHandler.class);
	    
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication auth) throws IOException, ServletException {
		logger.debug("*****************************************************************************************");
		logger.debug("*******  Login Successful, And Will Be Authentication With 'ROLE_USER' Authority  *******");
		logger.debug("*****************************************************************************************");
		
		response.sendRedirect(request.getContextPath() + "/");
	}

}
