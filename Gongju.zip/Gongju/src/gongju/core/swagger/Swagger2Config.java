package gongju.core.swagger;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMethod;

import com.google.common.collect.Lists;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class Swagger2Config {

	@Bean 
	public Docket webDocket() {
		String groupName = "WEB API"; 
		List<ResponseMessage> responseMessages = new ArrayList<ResponseMessage>();
		responseMessages.add(new ResponseMessageBuilder().code(200).message("성공").build());
		responseMessages.add(new ResponseMessageBuilder().code(203).message("토큰 오류").build());
		responseMessages.add(new ResponseMessageBuilder().code(204).message("회원정보 없음").build());
		responseMessages.add(new ResponseMessageBuilder().code(406).message("비밀번호 오류").build());
		responseMessages.add(new ResponseMessageBuilder().code(423).message("사용자 승인 신청중").build());
		responseMessages.add(new ResponseMessageBuilder().code(424).message("데이터 중복").build());
		responseMessages.add(new ResponseMessageBuilder().code(500).message("서버 오류").build());
		
		return new Docket(DocumentationType.SWAGGER_2)
					.select()
					.apis(RequestHandlerSelectors.basePackage("gongju.web.rest"))
					.paths(PathSelectors.any())
					.build()
					.securityContexts(Lists.newArrayList(securityContext()))
					.securitySchemes(Lists.newArrayList(apiKey()))
					.groupName(groupName)
					.apiInfo(webInfo())
					.globalResponseMessage(RequestMethod.GET, responseMessages)
					.globalResponseMessage(RequestMethod.POST, responseMessages);
	} 
	
	private ApiInfo webInfo() {
		return new ApiInfoBuilder()
				.title("WEB API")
				.description("공주재해재난 WEB API")
				.version("1.0.0")
				.build(); 
	}
	
	private springfox.documentation.spi.service.contexts.SecurityContext securityContext(){
		return springfox.documentation.spi.service.contexts.SecurityContext.builder()
				.securityReferences(defaultAuth())
				.forPaths(PathSelectors.any())
				.build();
	}
	
	List<SecurityReference> defaultAuth() { 
		AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything"); 
		AuthorizationScope[] authorizationScopes = new AuthorizationScope[1]; 
		authorizationScopes[0] = authorizationScope; 
		return Lists.newArrayList(new SecurityReference("JWT", authorizationScopes)); 
	}
	
	private ApiKey apiKey() {
		return new ApiKey("JWT", "Authorization", "header");
	}
	
}
