package gongju.web.rest;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gongju.model.PaginationList;
import gongju.model.ResponseObject;
import gongju.model.SmsGroup;
import gongju.model.SmsMst;
import gongju.model.SmsMstList;
import gongju.model.SmsTemplate;
import gongju.model.param.SmsGroupAdd;
import gongju.model.param.SmsGroupDelete;
import gongju.model.param.SmsGroupExcel;
import gongju.model.param.SmsGroupList;
import gongju.model.param.SmsGroupModify;
import gongju.model.param.SmsPhoneAdd;
import gongju.model.param.SmsPhoneDelete;
import gongju.model.param.SmsPhoneModify;
import gongju.model.param.SmsSendDelete;
import gongju.model.param.SmsSendReserveList;
import gongju.model.param.SmsSendResultList;
import gongju.model.param.SmsTemplateAdd;
import gongju.model.param.SmsTemplateDelete;
import gongju.model.param.SmsTemplateDetail;
import gongju.model.param.SmsTemplateList;
import gongju.model.param.SmsTemplateModify;
import gongju.service.SmsService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api("SMS API")
@RequestMapping("/api/sms")
public class SmsRestController {

	@Autowired
	private SmsService smsService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	@ApiOperation(value="SMS 그룹 등록")
	@RequestMapping(value="/group/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsGroupAdd(@RequestBody SmsGroupAdd params){
		String smsGroupName = params.getSmsGroupName();
		String userID = params.getUserID();
		
		return smsService.smsGroupAdd(smsGroupName, userID);
	}
	
	@ApiOperation(value="SMS 그룹 수정")
	@RequestMapping(value="/group/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsGroupModify(@RequestBody SmsGroupModify params){
		Integer smsGroupSeq = params.getSmsGroupSeq();
		String smsGroupName = params.getSmsGroupName();
		
		return smsService.smsGroupModify(smsGroupSeq, smsGroupName);
	}
	
	@ApiOperation(value="SMS 그룹 삭제")
	@RequestMapping(value="/group/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsGroupDelete(@RequestBody SmsGroupDelete params){
		Integer smsGroupSeq = params.getSmsGroupSeq();
		
		return smsService.smsGroupDelete(smsGroupSeq);
	}
	
	@ApiOperation(value="SMS 그룹 / 연락처 목록")
	@RequestMapping(value="/group/list", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<List<SmsGroup>> smsGroupList(@RequestBody SmsGroupList params){
		String userID = params.getUserID();
		
		return smsService.smsGroupList(userID);
	}
	
	@ApiOperation(value="SMS 그룹 엑셀")
	@RequestMapping(value="/group/excel", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsGroupExcel(@RequestBody SmsGroupExcel params, HttpServletResponse response){
		Integer smsGroupSeq = params.getSmsGroupSeq();
		
		return smsService.smsGroupExcel(smsGroupSeq, response);
	}
	
	
	
	@ApiOperation(value="SMS 그룹 > 연락처 등록")
	@RequestMapping(value="/phone/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsPhoneAdd(@RequestBody SmsPhoneAdd params){
		Integer smsGroupSeq = params.getSmsGroupSeq();
		String phoneName = params.getPhoneName();
		String phoneNumber = params.getPhoneNumber();
		
		return smsService.smsPhoneAdd(smsGroupSeq, phoneName, phoneNumber);
	}
	
	@ApiOperation(value="SMS 그룹 > 연락처 수정")
	@RequestMapping(value="/phone/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsPhoneModify(@RequestBody SmsPhoneModify params){
		Integer smsPhoneSeq = params.getSmsPhoneSeq();
		String phoneName = params.getPhoneName();
		String phoneNumber = params.getPhoneNumber();
		
		return smsService.smsPhoneModify(smsPhoneSeq, phoneName, phoneNumber);
	}
	
	@ApiOperation(value="SMS 그룹 > 연락처 삭제")
	@RequestMapping(value="/phone/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsPhoneDelete(@RequestBody SmsPhoneDelete params){
		Integer smsPhoneSeq = params.getSmsPhoneSeq();
		
		return smsService.smsPhoneDelete(smsPhoneSeq);
	}
	
	
	
	@ApiOperation(value="SMS 문안 등록")
	@RequestMapping(value="/template/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsTemplateAdd(@RequestBody SmsTemplateAdd params){
		String userID = params.getUserID();
		String smsTemplateTitle = params.getSmsTemplateTitle();
		String smsTemplate = params.getSmsTemplate();
		
		return smsService.smsTemplateAdd(userID, smsTemplateTitle, smsTemplate);
	}
	
	@ApiOperation(value="SMS 문안 수정")
	@RequestMapping(value="/template/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsTemplateModify(@RequestBody SmsTemplateModify params){
		Integer smsTemplateSeq = params.getSmsTemplateSeq();
		String smsTemplateTitle = params.getSmsTemplateTitle();
		String smsTemplate = params.getSmsTemplate();
		
		return smsService.smsTemplateModify(smsTemplateSeq, smsTemplateTitle, smsTemplate);
	}
	
	@ApiOperation(value="SMS 문안 삭제")
	@RequestMapping(value="/template/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsTemplateDelete(@RequestBody SmsTemplateDelete params){
		Integer smsTemplateSeq = params.getSmsTemplateSeq();
		
		return smsService.smsTemplateDelete(smsTemplateSeq);
	}
	
	@ApiOperation(value="SMS 문안 목록")
	@RequestMapping(value="/template/list", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<PaginationList<SmsTemplate>> smsTemplateList(@RequestBody SmsTemplateList params){
		Integer currentPage = params.getCurrentPage();
		String userID = params.getUserID();
		
		return smsService.smsTemplateList(currentPage, userID);
	}
	
	@ApiOperation(value="SMS 문안 상세")
	@RequestMapping(value="/template/detail", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<SmsTemplate> smsTemplateDetail(@RequestBody SmsTemplateDetail params){
		Integer smsTemplateSeq = params.getSmsTemplateSeq();
		
		return smsService.smsTemplateDetail(smsTemplateSeq);
	}
	
	
	
	@ApiOperation(value="SMS 발송")
	@RequestMapping(value="/send/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsSendAdd(@RequestBody SmsMst smsMst){
		return smsService.smsSendAdd(smsMst);
	}
	
	@ApiOperation(value="SMS 예약 수정", notes="SMS 발송(/send/add)때와 마찬가지로 수신자 목록의 전체 전달이 필요합니다. (삭제 후 재등록)")
	@RequestMapping(value="/send/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsSendModify(@RequestBody SmsMst smsMst){
		return smsService.smsSendModify(smsMst);
	}
	
	@ApiOperation(value="SMS 예약 삭제")
	@RequestMapping(value="/send/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> smsSendDelete(@RequestBody SmsSendDelete params){
		Integer smsMstSeq = params.getSmsMstSeq();
		
		return smsService.smsSendDelete(smsMstSeq);
	}
	
	@ApiOperation(value="SMS 발송 목록")
	@RequestMapping(value="/send/result/list", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<PaginationList<SmsMstList>> smsSendResultList(@RequestBody SmsSendResultList params){
		Integer currentPage = params.getCurrentPage();
		String userID = params.getUserID();
		String beginSendDate = params.getBeginSendDate();
		String endSendDate = params.getEndSendDate();
		String smsContent = params.getSmsContent();
		
		return smsService.smsSendResultList(currentPage, userID, beginSendDate, endSendDate, smsContent);
	}
	
	@ApiOperation(value="SMS 예약 목록")
	@RequestMapping(value="/send/reserve/list", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<PaginationList<SmsMstList>> smsSendReserveList(@RequestBody SmsSendReserveList params){
		Integer currentPage = params.getCurrentPage();
		String userID = params.getUserID();
		String beginReserveDate = params.getBeginReserveDate();
		String endReserveDate = params.getEndReserveDate();
		String smsContent = params.getSmsContent();
		
		return smsService.smsSendReserveList(currentPage, userID, beginReserveDate, endReserveDate, smsContent);
	}
	
}
