package gongju.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gongju.model.BroadcastMst;
import gongju.model.BroadcastMstList;
import gongju.model.BroadcastTemplate;
import gongju.model.BroadcastTts;
import gongju.model.PaginationList;
import gongju.model.ResponseObject;
import gongju.model.param.BroadcastMstDelete;
import gongju.model.param.BroadcastTemplateDelete;
import gongju.model.param.BroadcastTemplateDetail;
import gongju.model.param.BroadcastTemplateList;
import gongju.model.param.BroadcastTemplateModify;
import gongju.model.param.BroadcastTtsAdd;
import gongju.model.param.VmsSendReserveList;
import gongju.model.param.VmsSendResultList;
import gongju.service.BroadcastService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api("방송 API")
@RequestMapping("/api/broadcast")
public class BroadcastRestController {

	@Autowired
	private BroadcastService broadcastService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@ApiOperation(value="방송 문안 등록")
	@RequestMapping(value="/template/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> broadcastTemplateAdd(@RequestBody BroadcastTemplate params){
		return broadcastService.broadcastTemplateAdd(params);
	}
	
	@ApiOperation(value="방송 문안 수정")
	@RequestMapping(value="/template/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> broadcastTemplateModify(@RequestBody BroadcastTemplateModify params){
		return broadcastService.broadcastTemplateModify(params);
	}
	
	@ApiOperation(value="방송 문안 삭제")
	@RequestMapping(value="/template/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> broadcastTemplateDelete(@RequestBody BroadcastTemplateDelete params){
		return broadcastService.broadcastTemplateDelete(params);
	}
	
	@ApiOperation(value="방송 문안 목록")
	@RequestMapping(value="/template/list", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<PaginationList<BroadcastTemplate>> broadcastTemplateList(@RequestBody BroadcastTemplateList params){
		return broadcastService.broadcastTemplateList(params);
	}
	
	@ApiOperation(value="방송 문안 상세")
	@RequestMapping(value="/template/detail", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<BroadcastTemplate> broadcastTemplateDetail(@RequestBody BroadcastTemplateDetail params){
		return broadcastService.broadcastTemplateDetail(params);
	}
	
	
	
	@ApiOperation(value="방송 송출 > 음성생성")
	@RequestMapping(value="/tts", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<BroadcastTts> broadcastTts(@RequestBody BroadcastTtsAdd params){
		return broadcastService.broadcastTts(params);
	}
	
	@ApiOperation(value="방송 송출 등록")
	@RequestMapping(value="/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> broadcastMstAdd(@RequestBody BroadcastMst params){
		return broadcastService.broadcastMstAdd(params);
	}
	
	@ApiOperation(value="방송 송출 > 예약 수정", notes="방송 송출 등록(/broadcast/add)때와 마찬가지로 수신장비 목록의 전체 전달이 필요합니다. (삭제 후 재등록)")
	@RequestMapping(value="/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> broadcastMstModify(@RequestBody BroadcastMst params){
		return broadcastService.broadcastMstModify(params);
	}
	
	@ApiOperation(value="방송 송출 > 예약 삭제")
	@RequestMapping(value="/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> broadcastMstDelete(@RequestBody BroadcastMstDelete params){
		Integer broadcastMstSeq = params.getBroadcastMstSeq();
		
		return broadcastService.broadcastMstDelete(broadcastMstSeq);
	}
	
	@ApiOperation(value="방송 송출 목록")
	@RequestMapping(value="/result/list", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<PaginationList<BroadcastMstList>> smsSendResultList(@RequestBody VmsSendResultList params){
		Integer currentPage = params.getCurrentPage();
		String userID = params.getUserID();
		String beginSendDate = params.getBeginSendDate();
		String endSendDate = params.getEndSendDate();
		String broadcastTitle = params.getBroadcastTitle();
		
		return broadcastService.vmsSendResultList(currentPage, userID, beginSendDate, endSendDate, broadcastTitle);
	}
	
	@ApiOperation(value="방송 송출 예약 목록")
	@RequestMapping(value="/reserve/list", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<PaginationList<BroadcastMstList>> smsSendReserveList(@RequestBody VmsSendReserveList params){
		Integer currentPage = params.getCurrentPage();
		String userID = params.getUserID();
		String beginReserveDate = params.getBeginReserveDate();
		String endReserveDate = params.getEndReserveDate();
		String broadcastTitle = params.getBroadcastTitle();
		
		return broadcastService.vmsSendReserveList(currentPage, userID, beginReserveDate, endReserveDate, broadcastTitle);
	}
	
}
