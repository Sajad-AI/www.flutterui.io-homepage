package gongju.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gongju.model.AreaMst;
import gongju.model.BroadcastDevice;
import gongju.model.CCTVDevice;
import gongju.model.PaginationList;
import gongju.model.RTUDevice;
import gongju.model.RTUDeviceStatus;
import gongju.model.ResponseObject;
import gongju.model.SensorInfo;
import gongju.model.SensorInfoStatus;
import gongju.model.param.AreaMstAdd;
import gongju.model.param.AreaMstDelete;
import gongju.model.param.AreaMstDetail;
import gongju.model.param.AreaMstList;
import gongju.model.param.AreaMstModify;
import gongju.model.param.BroadcastDeviceDelete;
import gongju.model.param.BroadcastDeviceModify;
import gongju.model.param.CCTVDeviceDelete;
import gongju.model.param.CCTVDeviceModify;
import gongju.model.param.RTUDeviceDelete;
import gongju.model.param.RTUDeviceModify;
import gongju.model.param.SensorInfoDelete;
import gongju.model.param.SensorInfoModify;
import gongju.service.AreaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api("재해지역 API")
@RequestMapping("/api/area")
public class AreaRestController {

	@Autowired
	private AreaService areaService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@ApiOperation(value="재해 위험 지역 등록")
	@RequestMapping(value="/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> areaAdd(@RequestBody AreaMstAdd areaMst){
		return areaService.areaAdd(areaMst);
	}
	
	@ApiOperation(value="재해 위험 지역 수정")
	@RequestMapping(value="/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> areaModify(@RequestBody AreaMstModify areaMst){
		return areaService.areaModify(areaMst);
	}

	@ApiOperation(value="재해 위험 지역 삭제")
	@RequestMapping(value="/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> areaDelete(@RequestBody AreaMstDelete areaMst){
		return areaService.areaDelete(areaMst);
	}
	
	@ApiOperation(value="재해 위험 지역 목록")
	@RequestMapping(value="/list", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<PaginationList<AreaMst>> areaList(@RequestBody AreaMstList areaMst){
		return areaService.areaList(areaMst);
	}
	
	@ApiOperation(value="재해 위험 지역 상세")
	@RequestMapping(value="/detail", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<AreaMst> areaDetail(@RequestBody AreaMstDetail areaMst){
		return areaService.areaDetail(areaMst);
	}
	
	
	
	@ApiOperation(value="CCTV 등록")
	@RequestMapping(value="/cctv/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> cctvDeviceAdd(@RequestBody CCTVDevice cctvDevice){
		return areaService.cctvDeviceAdd(cctvDevice);
	}
	
	@ApiOperation(value="CCTV 수정")
	@RequestMapping(value="/cctv/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> cctvDeviceModify(@RequestBody CCTVDeviceModify cctvDevice){
		return areaService.cctvDeviceModify(cctvDevice);
	}

	@ApiOperation(value="CCTV 삭제")
	@RequestMapping(value="/cctv/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> cctvDeviceDelete(@RequestBody CCTVDeviceDelete cctvDevice){
		return areaService.cctvDeviceDelete(cctvDevice);
	}
	
	@ApiOperation(value="CCTV 상세")
	@RequestMapping(value="/cctv/detail", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<CCTVDevice> cctvDeviceDetail(@RequestBody CCTVDeviceDelete cctvDevice){
		return areaService.cctvDeviceDetail(cctvDevice);
	}
	
	
	
	@ApiOperation(value="방송장비 (비상예경보방송기기 / 마을방송) 등록")
	@RequestMapping(value="/broadcast/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> broadcastDeviceAdd(@RequestBody BroadcastDevice broadcastDevice){
		return areaService.broadcastDeviceAdd(broadcastDevice);
	}
	
	@ApiOperation(value="방송장비 (비상예경보방송기기 / 마을방송) 수정")
	@RequestMapping(value="/broadcast/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> broadcastDeviceModify(@RequestBody BroadcastDeviceModify broadcastDevice){
		return areaService.broadcastDeviceModify(broadcastDevice);
	}

	@ApiOperation(value="방송장비 (비상예경보방송기기 / 마을방송) 삭제")
	@RequestMapping(value="/broadcast/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> broadcastDeviceDelete(@RequestBody BroadcastDeviceDelete broadcastDevice){
		return areaService.broadcastDeviceDelete(broadcastDevice);
	}
	
	@ApiOperation(value="방송장비 (비상예경보방송기기 / 마을방송) 상세")
	@RequestMapping(value="/broadcast/detail", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<BroadcastDevice> broadcastDeviceDetail(@RequestBody BroadcastDeviceDelete broadcastDevice){
		return areaService.broadcastDeviceDetail(broadcastDevice);
	}
	
	
	
	@ApiOperation(value="RTU 등록")
	@RequestMapping(value="/rtu/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> rtuDeviceAdd(@RequestBody RTUDevice rtuDevice){
		return areaService.rtuDeviceAdd(rtuDevice);
	}
	
	@ApiOperation(value="RTU 수정")
	@RequestMapping(value="/rtu/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> rtuDeviceModify(@RequestBody RTUDeviceModify rtuDevice){
		return areaService.rtuDeviceModify(rtuDevice);
	}

	@ApiOperation(value="RTU 삭제")
	@RequestMapping(value="/rtu/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> rtuDeviceDelete(@RequestBody RTUDeviceDelete rtuDevice){
		return areaService.rtuDeviceDelete(rtuDevice);
	}
	
	@ApiOperation(value="RTU 상세")
	@RequestMapping(value="/rtu/detail", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<RTUDevice> rtuDeviceDetail(@RequestBody RTUDeviceDelete rtuDevice){
		return areaService.rtuDeviceDetail(rtuDevice);
	}
	
	@ApiOperation(value="RTU 상태")
	@RequestMapping(value="/rtu/status", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<RTUDeviceStatus> rtuDeviceStatus(@RequestBody gongju.model.param.RTUDeviceStatusParam rtuDevice){
		return areaService.rtuDeviceStatus(rtuDevice);
	}
	
	
	
	@ApiOperation(value="센서 등록")
	@RequestMapping(value="/sensor/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> sensorInfoAdd(@RequestBody SensorInfo sensorInfo){
		return areaService.sensorInfoAdd(sensorInfo);
	}
	
	@ApiOperation(value="센서 수정")
	@RequestMapping(value="/sensor/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> sensorInfoModify(@RequestBody SensorInfoModify sensorInfo){
		return areaService.sensorInfoModify(sensorInfo);
	}

	@ApiOperation(value="센서 삭제")
	@RequestMapping(value="/sensor/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> sensorInfoDelete(@RequestBody SensorInfoDelete sensorInfo){
		return areaService.sensorInfoDelete(sensorInfo);
	}
	
	@ApiOperation(value="센서 상세")
	@RequestMapping(value="/sensor/detail", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<SensorInfo> sensorInfoDetail(@RequestBody SensorInfoDelete sensorInfo){
		return areaService.sensorInfoDetail(sensorInfo);
	}
	
	@ApiOperation(value="센서 상태")
	@RequestMapping(value="/sensor/status", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<SensorInfoStatus> sensorInfoStatus(@RequestBody gongju.model.param.SensorInfoStatusParam sensorInfo){
		return areaService.sensorInfoStatus(sensorInfo);
	}
	
}
