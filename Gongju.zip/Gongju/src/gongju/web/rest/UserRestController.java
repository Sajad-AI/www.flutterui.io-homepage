package gongju.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gongju.model.PaginationList;
import gongju.model.ResponseObject;
import gongju.model.UserMst;
import gongju.model.param.UserAdd;
import gongju.model.param.UserLogin;
import gongju.model.param.UserMstDelete;
import gongju.model.param.UserMstList;
import gongju.model.param.UserMstModify;
import gongju.model.param.UserVerify;
import gongju.service.LoginService;
import gongju.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api("USER API")
@RequestMapping("/api/user")
public class UserRestController {

	@Autowired
	private LoginService loginService;
	
	@Autowired
	private UserService userService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@CrossOrigin(origins="*")
	@ApiOperation(value="로그인")
	@RequestMapping(value="/login", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> login(@RequestBody UserLogin params) {
		String userID = params.getUserID();
		String loginPassword = params.getLoginPassword();
		
		return loginService.loginUser(userID, loginPassword);
	}
	
	@CrossOrigin(origins="*")
	@ApiOperation(value="계정 등록 신청")
	@RequestMapping(value="/add", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> insertUser(@RequestBody UserAdd params){
		String userID = params.getUserID();
		String loginPassword = params.getLoginPassword();
		String userFullName = params.getUserFullName();
		String phoneNum = params.getPhoneNum();
		String organizationName = params.getOrganizationName();
		Boolean isAdminPerm = params.getIsAdminPerm();
		Boolean isSMSPerm = params.getIsSMSPerm();
		Boolean isBroadcastPerm = params.getIsBroadcastPerm();
		Boolean isCCTVViewPerm = params.getIsCCTVViewPerm();
		Boolean isCCTVCtrlPerm = params.getIsCCTVCtrlPerm();
		
		return loginService.insertUser(userID, loginPassword, userFullName, phoneNum, organizationName, isAdminPerm, isSMSPerm, isBroadcastPerm, isCCTVViewPerm, isCCTVCtrlPerm);
	}
	
	@ApiOperation(value="계정 등록 승인")
	@RequestMapping(value="/verify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> verifyUser(@RequestBody UserVerify params){
		String userID = params.getUserID();
		
		return loginService.verifyUser(userID);
	}
	
	@ApiOperation(value="사용자 목록")
	@RequestMapping(value="/list", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<PaginationList<UserMst>> userList(@RequestBody UserMstList userMst){
		return userService.userList(userMst);
	}
	
	@ApiOperation(value="사용자 수정")
	@RequestMapping(value="/modify", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> userMstModify(@RequestBody UserMstModify userMst){
		return userService.userMstModify(userMst);
	}
	
	@ApiOperation(value="사용자 삭제")
	@RequestMapping(value="/delete", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<?> userMstDelete(@RequestBody UserMstDelete userMst){
		return userService.userMstDelete(userMst);
	}
	
	
}
