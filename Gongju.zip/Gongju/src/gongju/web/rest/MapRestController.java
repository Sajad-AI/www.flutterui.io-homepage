package gongju.web.rest;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import gongju.model.AreaSensor;
import gongju.model.Rainfall;
import gongju.model.ReservoirRate;
import gongju.model.ResponseObject;
import gongju.model.SensorInfoStatusCount;
import gongju.model.param.AreaMstDetail;
import gongju.service.MapService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api("MAP API")
@RequestMapping("/api/map")
public class MapRestController {

	@Autowired
	private MapService mapService;
	
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@ApiOperation(value="재해 위험 지역 센서값 정보")
	@RequestMapping(value="/area/sensor", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<AreaSensor> sensorValue(@RequestBody AreaMstDetail areaMst){
		return mapService.sensorValue(areaMst);
	}
	
	@ApiOperation(value="저수율 정보")
	@RequestMapping(value="/reservoir/rate", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<List<ReservoirRate>> reservoirRate(){
		return mapService.reservoirRate();
	}
	
	@ApiOperation(value="공주시 일강우 현황")
	@RequestMapping(value="/rainfall", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<List<Rainfall>> rainfall(){
		return mapService.rainfall();
	}

	@ApiOperation(value="통신상태 현황")
	@RequestMapping(value="/sensor/status", method=RequestMethod.POST, produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseObject<SensorInfoStatusCount> sensorStatus(){
		return mapService.sensorStatus();
	}
	
}
