-- SMS 그룹
CREATE TABLE smsGroup(
	smsGroupSeq				INT  					NOT NULL AUTO_INCREMENT 	COMMENT '그룹키',
	smsGroupName			VARCHAR(100) 	   		NOT NULL 					COMMENT '그룹명', 
	
	userID					VARCHAR(50)				NOT NULL					COMMENT '사용자 ID',
	
	createDate				DATETIME 			   	NOT NULL					COMMENT '생성일', 
	updateDate 				DATETIME 			   		NULL					COMMENT '수정일', 
	deleteDate				DATETIME 			   		NULL					COMMENT '삭제일',
	PRIMARY KEY(smsGroupSeq)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- SMS 그룹 > 연락처
CREATE TABLE smsPhone(
	smsPhoneSeq				INT  					NOT NULL AUTO_INCREMENT 	COMMENT '연락처키',
	smsGroupSeq				INT  					NOT NULL 				 	COMMENT '그룹키',
	
	phoneName				VARCHAR(100) 	   		NOT NULL 					COMMENT '성함', 
	phoneNumber				VARCHAR(13)				NOT NULL					COMMENT '전화번호',
	PRIMARY KEY(smsPhoneSeq, smsGroupSeq)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- SMS 문안
CREATE TABLE smsTemplate(
	smsTemplateSeq			INT  					NOT NULL AUTO_INCREMENT 	COMMENT '문안키',
	userID					VARCHAR(50)				NOT NULL					COMMENT '사용자 ID',
	smsTemplateTitle		VARCHAR(100)			NOT NULL					COMMENT '명칭',
	smsTemplate				VARCHAR(2000)			NOT NULL					COMMENT '문안',
	
	createDate				DATETIME				NOT NULL					COMMENT '생성일',
	updateDate				DATETIME					NULL					COMMENT '수정일',
	deleteDate				DATETIME					NULL					COMMENT '삭제일',
	PRIMARY KEY(smsTemplateSeq)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- SMS 발송
CREATE TABLE smsMst(
	smsMstSeq				INT						NOT NULL AUTO_INCREMENT		COMMENT 'SMS키',
	userID					VARCHAR(50)				NOT NULL					COMMENT '사용자 ID',
	smsContent				VARCHAR(4000)			NOT NULL					COMMENT 'SMS내용',
	smsType					CHAR(1)					NOT NULL					COMMENT 'D:즉시, R:예약',
	
	createDate				DATETIME				NOT NULL					COMMENT '생성일',
	reserveDate				DATETIME					NULL					COMMENT '예약시간',

	PRIMARY KEY(smsMstSeq)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- SMS 발송 > 수신자 목록
CREATE TABLE smsDtl(
	smsDtlSeq				INT						NOT NULL AUTO_INCREMENT		COMMENT 'SMS 수신자 키',
	smsMstSeq				INT						NOT NULL 					COMMENT 'SMS키',
	phoneName				VARCHAR(100) 	   		NOT NULL 					COMMENT '성함', 
	phoneNumber				VARCHAR(13)				NOT NULL					COMMENT '전화번호',			
	
	PRIMARY KEY(smsDtlSeq)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- SMS 발송 (크로샷)
CREATE TABLE SDK_SMS_SEND(
	MSG_ID					BIGINT					NOT NULL AUTO_INCREMENT		COMMENT '고유 메시지 구분값 (자동증가 key)',
	USER_ID					VARCHAR(20)				NOT NULL					COMMENT '회원 ID',
	SCHEDULE_TYPE			INT						NOT NULL DEFAULT 0			COMMENT '발송시점 구분 (즉시전송:0, 예약전송:1)',
	SUBJECT					VARCHAR(50)					NULL					COMMENT '제목',
	SMS_MSG					VARCHAR(200) 				NULL					COMMENT '발송 SMS 메시지 (80 byte)',
	CALLBACK_URL			VARCHAR(200)				NULL					COMMENT '전송할 CALLBACK URL',
	NOW_DATE				VARCHAR(20)					NULL					COMMENT 'DB 입력 시간: YYYYMMDDHHMMSS',
	SEND_DATE				VARCHAR(20)				NOT NULL					COMMENT '발송 희망 시간: YYYYMMDDHHMMSS',
	CALLBACK				VARCHAR(20)					NULL					COMMENT '콜백번호(회신번호)',
	DEST_TYPE				INT						NOT NULL DEFAULT 0			COMMENT '수신자 정보 저장 타입 (0:TEXT 고정)',
	DEST_COUNT				INT						NOT NULL DEFAULT 0			COMMENT '수신자 목록 개수 (Max : 100)',
	DEST_INFO				TEXT					NOT NULL					COMMENT '착신자 정보 이름과 번호 저장 / 홍길동^01011112222|아무개^01022223333|제삼자^01044445555',
	KT_OFFICE_CODE			VARCHAR(20)					NULL					COMMENT 'KT 유통망 코드',
	CDR_ID					VARCHAR(20)					NULL					COMMENT '과금 ID',
	RESERVED1				VARCHAR(64)					NULL					COMMENT '여분필드 1 (임의로 사용가능) / smsMst.smsMstSeq',
	RESERVED2				VARCHAR(50)					NULL					COMMENT '여분필드 2 (임의로 사용가능)',
	RESERVED3				VARCHAR(50)					NULL					COMMENT '여분필드 3 (임의로 사용가능)',
	RESERVED4				VARCHAR(50)					NULL					COMMENT '여분필드 4 (임의로 사용가능)',
	RESERVED5				VARCHAR(50)					NULL					COMMENT '여분필드 5 (임의로 사용가능)',
	RESERVED6				VARCHAR(50)					NULL					COMMENT '여분필드 6 (임의로 사용가능)',
	RESERVED7				VARCHAR(50)					NULL					COMMENT '여분필드 7 (임의로 사용가능)',
	RESERVED8				VARCHAR(50)					NULL					COMMENT '여분필드 8 (임의로 사용가능)',
	RESERVED9				VARCHAR(50)					NULL					COMMENT '여분필드 9 (임의로 사용가능)',
	SEND_STATUS				INT						NOT NULL DEFAULT 0 			COMMENT 'SEND 전송 처리 상태',
	SEND_COUNT				INT						NOT NULL DEFAULT 0 			COMMENT '서버로 전송 실패 시 재전송하는 회수',
	SEND_RESULT				INT						NOT NULL DEFAULT 0 			COMMENT '전송결과 서버 ACK 값',
	SEND_PROC_TIME			VARCHAR(20)					NULL					COMMENT '전송 처리 시간: YYYYMMDDHHMMSS',
	STD_ID					BIGINT						NULL					COMMENT '타 규격 연동 시 사용',
	
	PRIMARY KEY(MSG_ID)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- SMS 발송 이력 (크로샷)
CREATE TABLE SDK_SMS_REPORT(
	MSG_ID					BIGINT					NOT NULL					COMMENT '고유 메시지 구분값',
	USER_ID					VARCHAR(20)				NOT NULL					COMMENT '회원 ID',
	JOB_ID					BIGINT					NOT NULL DEFAULT 0			COMMENT '서버에서 관리되는 메시지 고유 ID 값',
	SCHEDULE_TYPE			INT						NOT NULL DEFAULT 0			COMMENT '발송시점 구분 (즉시전송:0, 예약전송:1)',
	SUBJECT					VARCHAR(50)					NULL					COMMENT '제목',
	SMS_MSG					VARCHAR(200) 				NULL					COMMENT '발송 SMS 메시지 (80 byte)',
	CALLBACK_URL			VARCHAR(200)				NULL					COMMENT '전송할 CALLBACK URL',
	NOW_DATE				VARCHAR(20)					NULL					COMMENT 'DB 입력 시간: YYYYMMDDHHMMSS',
	SEND_DATE				VARCHAR(20)				NOT NULL					COMMENT '발송 희망 시간: YYYYMMDDHHMMSS',
	CALLBACK				VARCHAR(20)					NULL					COMMENT '콜백번호(회신번호)',
	DEST_TYPE				INT						NOT NULL DEFAULT 0			COMMENT '수신자 정보 저장 타입 (0:TEXT 고정)',
	DEST_COUNT				INT						NOT NULL DEFAULT 0			COMMENT '수신자 목록 개수 (Max : 100)',
	DEST_INFO				TEXT					NOT NULL					COMMENT '착신자 정보 이름과 번호 저장 / 홍길동^01011112222|아무개^01022223333|제삼자^01044445555',
	KT_OFFICE_CODE			VARCHAR(20)					NULL					COMMENT 'KT 유통망 코드',
	CDR_ID					VARCHAR(20)					NULL					COMMENT '과금 ID',
	RESERVED1				VARCHAR(64)					NULL					COMMENT '여분필드 1 (임의로 사용가능) / smsMst.smsMstSeq',
	RESERVED2				VARCHAR(50)					NULL					COMMENT '여분필드 2 (임의로 사용가능)',
	RESERVED3				VARCHAR(50)					NULL					COMMENT '여분필드 3 (임의로 사용가능)',
	RESERVED4				VARCHAR(50)					NULL					COMMENT '여분필드 4 (임의로 사용가능)',
	RESERVED5				VARCHAR(50)					NULL					COMMENT '여분필드 5 (임의로 사용가능)',
	RESERVED6				VARCHAR(50)					NULL					COMMENT '여분필드 6 (임의로 사용가능)',
	RESERVED7				VARCHAR(50)					NULL					COMMENT '여분필드 7 (임의로 사용가능)',
	RESERVED8				VARCHAR(50)					NULL					COMMENT '여분필드 8 (임의로 사용가능)',
	RESERVED9				VARCHAR(50)					NULL					COMMENT '여분필드 9 (임의로 사용가능)',
	SUCC_COUNT				INT						NOT NULL DEFAULT 0			COMMENT '메시지 등록 성공 개수',
	FAIL_COUNT				INT						NOT NULL DEFAULT 0 			COMMENT '메시지 등록 실패 개수',
	CANCEL_STATUS			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 문서내용참조',
	CANCEL_COUNT			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 문서내용참조',
	CANCEL_REQ_DATE			VARCHAR(20)					NULL					COMMENT '기존 SDK 문서내용참조',
	CANCEL_RESULT			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 문서내용참조',
	DELIVER_STATUS			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 문서내용참조',
	DELIVER_COUNT			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 문서내용참조',
	DELIVER_REQ_DATE		VARCHAR(20)					NULL					COMMENT '기존 SDK 문서내용참조',
	DELIVER_RESUIT			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 문서내용참조',
	STD_ID					BIGINT						NULL					COMMENT '타 규격 연동 시 사용',

	PRIMARY KEY(MSG_ID)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- SMS 발송 이력 상세 (크로샷)
CREATE TABLE SDK_SMS_REPORT_DETAIL(
	MSG_ID					BIGINT					NOT NULL					COMMENT '고유 메시지 구분값',
	USER_ID					VARCHAR(20)				NOT NULL					COMMENT '회원 ID',
	JOB_ID					BIGINT					NOT NULL DEFAULT 0			COMMENT '서버에서 관리되는 메시지 고유 ID 값',
	SUBJOB_ID				INT						NOT NULL DEFAULT 0			COMMENT '메시지가 동보전송일 경우 세부 ID 값',
	SEND_DATE				VARCHAR(20)				NOT NULL					COMMENT '발송 희망 시간: YYYYMMDDHHMMSS',
	DEST_NAME				VARCHAR(20)				NOT NULL					COMMENT '수신자 이름',
	PHONE_NUMBER			VARCHAR(20)				NOT NULL					COMMENT '전화번호',
	RESULT					INT						NOT NULL DEFAULT 0			COMMENT '전송 결과값 (기존 SDK 참조)',
	TCS_RESULT				INT						NOT NULL DEFAULT -2			COMMENT '상세 전송 결과값 (5. 응답코드 참조)',
	FEE						FLOAT						NULL					COMMENT '요금',
	DELIVER_DATE			VARCHAR(20)					NULL					COMMENT 'SMS 전달 시간: YYYYMMDDHHMMSS',
	REPORT_RES_DATE			VARCHAR(20)					NULL					COMMENT '리포트 서버로부터 응답 날짜',
	MSG_SUBJOB_TYPE			INT							NULL					COMMENT '메시지 Sub Job Type',
	STAT_STATUS				INT						NOT NULL DEFAULT 0			COMMENT '통계 처리 상태',
	TELCOINFO				VARCHAR(8)					NULL					COMMENT '이통사 정보',
	STATUS_TEXT				VARCHAR(200)				NULL					COMMENT '전송결과 부가정보',
	SEND_SPID				VARCHAR(100)				NULL					COMMENT '이중화 구조 발송 SP_ID'

) ENGINE = InnoDB
DEFAULT CHARSET=utf8;


-- 방송 문안
CREATE TABLE broadcastTemplate(
	broadcastTemplateSeq	INT  					NOT NULL AUTO_INCREMENT 	COMMENT '문안키',
	userID					VARCHAR(50)				NOT NULL					COMMENT '사용자 ID',
	broadcastTemplateTitle	VARCHAR(100)			NOT NULL					COMMENT '경보',
	broadcastTemplate		VARCHAR(2000)			NOT NULL					COMMENT '문안',
	
	createDate				DATETIME				NOT NULL					COMMENT '생성일',
	updateDate				DATETIME					NULL					COMMENT '수정일',
	deleteDate				DATETIME					NULL					COMMENT '삭제일',
	PRIMARY KEY(broadcastTemplateSeq)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- 방송 송출
CREATE TABLE broadcastMst(
	broadcastMstSeq			INT 					NOT NULL AUTO_INCREMENT		COMMENT '방송 송출 키',
	broadcastTitle			VARCHAR(100)				NULL					COMMENT '방송 송출 제목 (방송 문안 > 경보)',
	broadcastContent		VARCHAR(4000)			NOT NULL					COMMENT '방송 송출 내용',
	beginEffect				INT							NULL					COMMENT '시작 효과음 { 0:차임벨, 1:사이렌 }',
	endEffect				INT							NULL					COMMENT '종료 효과음 { 0:차임벨, 1:사이렌 }',
	
	broadcastType			CHAR(1)					NOT NULL					COMMENT 'D:즉시(수동), R:예약(자동)',
	broadcastPeriodType		CHAR(1)						NULL					COMMENT 'D:일간, W:주간, M:월간',
	beginPeriod				DATETIME					NULL					COMMENT '시작 기간',
	endPeriod				DATETIME					NULL					COMMENT '종료 기간',
	sendHour				INT							NULL					COMMENT '시',
	sendMinute				INT							NULL					COMMENT '분',
	sendPeriod				VARCHAR(100)				NULL					COMMENT '* 콤마연결(ex.1,3,5,7 ...) > 주간 : {1:일, 2:월, 3:화, 4:수, 5:목, 6:금, 7:토} || 월간 : {1-30, 마지막날:L}',
	
	userID					VARCHAR(50)				NOT NULL					COMMENT '사용자 ID',
	createDate				DATETIME				NOT NULL					COMMENT '생성일',
	updateDate				DATETIME					NULL					COMMENT '수정일',
	
	PRIMARY KEY(broadcastMstSeq)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- 방송 송출 > 전송
CREATE TABLE broadcastDtl(
	broadcastDtlSeq			INT						NOT NULL AUTO_INCREMENT		COMMENT '방송 송출 전송 키',
	broadcastMstSeq			INT 					NOT NULL 					COMMENT '방송 송출 키',
	areaID					INT						NOT NULL					COMMENT '지역키',
	broadcastDevID			INT						NOT NULL 					COMMENT '방송장비키',
	
	PRIMARY KEY(broadcastDtlSeq)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- 방송 송출 (크로샷)
CREATE TABLE SDK_VMS_SEND(
	MSG_ID					BIGINT					NOT NULL AUTO_INCREMENT		COMMENT '고유 메시지 구분값 (자동증가 key)',
	USER_ID					VARCHAR(20)				NOT NULL					COMMENT '회원 ID',
	MSG_SUBTYPE				INT						NOT NULL DEFAULT 0			COMMENT '발송 타입 구분',
	SCHEDULE_TYPE			INT						NOT NULL DEFAULT 0 			COMMENT '즉시전송:0, 예약전송:1',
	DEST_TYPE				INT						NOT NULL DEFAULT 0			COMMENT '수신자 정보 저장 타입 (0:TEXT 고정)',
	MENT_TYPE				INT						NOT NULL DEFAULT 0			COMMENT '머릿말.본문.맺음말 재생 타입',
	VOICE_TYPE				INT						NOT NULL DEFAULT 0			COMMENT 'TTS의 음성 변환 타입',
	SUBJECT					VARCHAR(50)					NULL					COMMENT '제목',
	NOW_DATE				VARCHAR(20)					NULL					COMMENT 'DB 입력 시간:YYYYMMDDHHMMSS',
	SEND_DATE				VARCHAR(20)				NOT NULL					COMMENT '발송 희망 시간: YYYYMMDDHHMMSS',
	CALLBACK				VARCHAR(20)					NULL					COMMENT '콜백번호(회신번호)',
	REPLY_TYPE				INT						NOT NULL DEFAULT 0			COMMENT '답변받기 타입',
	REPLY_COUNT				INT						NOT NULL DEFAULT 0			COMMENT '답변받기 번호 범위',
	COUNSELOR_DTMF			INT						NOT NULL DEFAULT 0			COMMENT '상담원연결시 누르는 번호',
	COUNSELOR_NUMBER		VARCHAR(20)					NULL					COMMENT '상담원 전화번호',
	RELISTEN_COUNT			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 참고',
	KT_OFFICE_CODE			VARCHAR(20)					NULL					COMMENT 'KT 유통망 코드',
	CDR_ID					VARCHAR(20)					NULL					COMMENT '과금 ID',
	SMSPLUS_MSG				VARCHAR(100)				NULL					COMMENT '기존 SDK 참고',
	HEADER_MSG				VARCHAR(150)				NULL					COMMENT '음성의 HEADER 메시지',
	TAIL_MSG				VARCHAR(150)				NULL					COMMENT '음성의 TAIL 메시지',
	TTS_MSG					TEXT						NULL					COMMENT '음성의 TTS 메시지',
	DEST_COUNT				INT						NOT NULL DEFAULT 0			COMMENT '수신자 목록 개수 (Max : 100)',
	DEST_INFO				TEXT					NOT NULL					COMMENT '착신자 정보 이름과 번호 저장 / 홍길동^01011112222|아무개^01022223333|제삼자^01044445555',
	ATTACH_FILE				TEXT						NULL					COMMENT '로컬에 저장되어있는 첨부파일 이름으로 프로그램에서 업로드 함(파일이름 길이 최대 20byte)',
	RESERVED1				VARCHAR(50)					NULL					COMMENT '여분필드 1 (임의로 사용가능) / broadcastMst.broadcastMstSeq',
	RESERVED2				VARCHAR(50)					NULL					COMMENT '여분필드 2 (임의로 사용가능)',
	RESERVED3				VARCHAR(50)					NULL					COMMENT '여분필드 3 (임의로 사용가능)',
	RESERVED4				VARCHAR(50)					NULL					COMMENT '여분필드 4 (임의로 사용가능)',
	RESERVED5				VARCHAR(50)					NULL					COMMENT '여분필드 5 (임의로 사용가능)',
	RESERVED6				VARCHAR(50)					NULL					COMMENT '여분필드 6 (임의로 사용가능)',
	RESERVED7				VARCHAR(50)					NULL					COMMENT '여분필드 7 (임의로 사용가능)',
	RESERVED8				VARCHAR(50)					NULL					COMMENT '여분필드 8 (임의로 사용가능)',
	RESERVED9				VARCHAR(50)					NULL					COMMENT '여분필드 9 (임의로 사용가능)',
	SEND_STATUS				INT						NOT NULL DEFAULT 0			COMMENT '전송 처리 상태',
	SEND_COUNT				INT						NOT NULL DEFAULT 0			COMMENT '메시지 서버로 전송 횟수',
	SEND_RESULT				INT						NOT NULL DEFAULT 0			COMMENT '전송 결과',
	SEND_PROC_TIME			VARCHAR(20)					NULL					COMMENT '전송 처리 시간',
	STD_ID					BIGINT						NULL					COMMENT '타 규격 연동 시 사용',
	
	PRIMARY KEY(MSG_ID)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- 방송 송출 이력 (크로샷)
CREATE TABLE SDK_VMS_REPORT(
	MSG_ID					BIGINT					NOT NULL					COMMENT '고유 메시지 구분값',
	USER_ID					VARCHAR(20)				NOT NULL					COMMENT '회원 ID',
	JOB_ID					BIGINT					NOT NULL DEFAULT 0			COMMENT '서버에서 관리되는 메시지 고유 ID 값',
	MSG_SUBTYPE				INT						NOT NULL DEFAULT 0			COMMENT '발송 타입 구분',
	SCHEDULE_TYPE			INT						NOT NULL DEFAULT 0 			COMMENT '즉시전송:0, 예약전송:1',
	DEST_TYPE				INT						NOT NULL DEFAULT 0			COMMENT '수신자 정보 저장 타입 (0:TEXT 고정)',
	MENT_TYPE				INT						NOT NULL DEFAULT 0			COMMENT '머릿말.본문.맺음말 재생 타입',
	VOICE_TYPE				INT						NOT NULL DEFAULT 0			COMMENT 'TTS의 음성 변환 타입',
	SUBJECT					VARCHAR(50)					NULL					COMMENT '제목',
	NOW_DATE				VARCHAR(20)					NULL					COMMENT 'DB 입력 시간:YYYYMMDDHHMMSS',
	SEND_DATE				VARCHAR(20)				NOT NULL					COMMENT '발송 희망 시간: YYYYMMDDHHMMSS',
	CALLBACK				VARCHAR(20)					NULL					COMMENT '콜백번호(회신번호)',
	REPLY_TYPE				INT						NOT NULL DEFAULT 0			COMMENT '답변받기 타입',
	REPLY_COUNT				INT						NOT NULL DEFAULT 0			COMMENT '답변받기 번호 범위',
	COUNSELOR_DTMF			INT						NOT NULL DEFAULT 0			COMMENT '상담원연결시 누르는 번호',
	COUNSELOR_NUMBER		VARCHAR(20)					NULL					COMMENT '상담원 전화번호',
	RELISTEN_COUNT			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 참고',
	KT_OFFICE_CODE			VARCHAR(20)					NULL					COMMENT 'KT 유통망 코드',
	CDR_ID					VARCHAR(20)					NULL					COMMENT '과금 ID',
	SMSPLUS_MSG				VARCHAR(100)				NULL					COMMENT '기존 SDK 참고',
	HEADER_MSG				VARCHAR(150)				NULL					COMMENT '음성의 HEADER 메시지',
	TAIL_MSG				VARCHAR(150)				NULL					COMMENT '음성의 TAIL 메시지',
	TTS_MSG					TEXT						NULL					COMMENT '음성의 TTS 메시지',
	DEST_COUNT				INT						NOT NULL DEFAULT 0			COMMENT '수신자 목록 개수 (Max : 100)',
	DEST_INFO				TEXT					NOT NULL					COMMENT '착신자 정보 이름과 번호 저장 / 홍길동^01011112222|아무개^01022223333|제삼자^01044445555',
	ATTACH_FILE				TEXT						NULL					COMMENT '로컬에 저장되어있는 첨부파일 이름으로 프로그램에서 업로드 함(파일이름 길이 최대 20byte)',
	RESERVED1				VARCHAR(50)					NULL					COMMENT '여분필드 1 (임의로 사용가능) / broadcastMst.broadcastMstSeq',
	RESERVED2				VARCHAR(50)					NULL					COMMENT '여분필드 2 (임의로 사용가능)',
	RESERVED3				VARCHAR(50)					NULL					COMMENT '여분필드 3 (임의로 사용가능)',
	RESERVED4				VARCHAR(50)					NULL					COMMENT '여분필드 4 (임의로 사용가능)',
	RESERVED5				VARCHAR(50)					NULL					COMMENT '여분필드 5 (임의로 사용가능)',
	RESERVED6				VARCHAR(50)					NULL					COMMENT '여분필드 6 (임의로 사용가능)',
	RESERVED7				VARCHAR(50)					NULL					COMMENT '여분필드 7 (임의로 사용가능)',
	RESERVED8				VARCHAR(50)					NULL					COMMENT '여분필드 8 (임의로 사용가능)',
	RESERVED9				VARCHAR(50)					NULL					COMMENT '여분필드 9 (임의로 사용가능)',
	SUCC_COUNT				INT						NOT NULL DEFAULT 0			COMMENT '메시지 등록 성공 개수',
	FAIL_COUNT				INT						NOT NULL DEFAULT 0 			COMMENT '메시지 등록 실패 개수',
	CANCEL_STATUS			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 문서내용참조',
	CANCEL_COUNT			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 문서내용참조',
	CANCEL_REQ_DATE			VARCHAR(50)					NULL					COMMENT '기존 SDK 문서내용참조',
	CANCEL_RESULT			INT						NOT NULL DEFAULT 0			COMMENT '기존 SDK 문서내용참조',
	STD_ID					BIGINT						NULL					COMMENT '타 규격 연동 시 사용',

	PRIMARY KEY(MSG_ID)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- 방송 송출 이력 상세 (크로샷)
CREATE TABLE SDK_VMS_REPORT_DETAIL(
	MSG_ID					BIGINT					NOT NULL					COMMENT '고유 메시지 구분값',
	USER_ID					VARCHAR(20)				NOT NULL					COMMENT '회원 ID',
	JOB_ID					BIGINT					NOT NULL DEFAULT 0			COMMENT '서버에서 관리되는 메시지 고유 ID 값',
	SUBJOB_ID				INT						NOT NULL DEFAULT 0			COMMENT '메시지가 동보전송일 경우 세부 ID 값',
	SEND_DATE				VARCHAR(20)				NOT NULL					COMMENT '발송 희망 시간: YYYYMMDDHHMMSS',
	DEST_NAME				VARCHAR(20)				NOT NULL					COMMENT '수신자 이름',
	PHONE_NUMBER			VARCHAR(20)				NOT NULL					COMMENT '전화번호',
	RESULT					INT						NOT NULL DEFAULT 0			COMMENT '전송 결과값 (기존 SDK 참조)',
	TCS_RESULT				INT						NOT NULL DEFAULT -2			COMMENT '상세 전송 결과값 (5. 응답코드 참조)',
	STIME					VARCHAR(20)					NULL					COMMENT '호 연결 시간',
	RTIME					VARCHAR(20)					NULL					COMMENT '음성 메시지 청취 시작 시간',
	FEE						FLOAT						NULL					COMMENT '요금',
	DURATION				INT						NOT NULL DEFAULT 0			COMMENT '음성 메시지 청취시간(요금과 관련)',
	REPLIED_DTMF			INT						NOT NULL DEFAULT 0			COMMENT '답변',
	REPLIED_FILE			VARCHAR(250)				NULL					COMMENT '답변 파일(다단계 설문 답변 포함)',
	REPORT_STATUS			INT						NOT NULL DEFAULT 0			COMMENT '리포트 수집 처리 상태',
	REPORT_COUNT			INT						NOT NULL DEFAULT 0			COMMENT '요청 횟수',
	REPORT_REQ_DATE			VARCHAR(20)					NULL					COMMENT '리포트 요청 날짜',
	REPORT_RES_DATE			VARCHAR(20)					NULL					COMMENT '리포트 응답 날짜',
	MSG_SUBJOB_TYPE			INT							NULL					COMMENT '메시지 Sub Job Type',
	STAT_STATUS				INT						NOT NULL DEFAULT 0			COMMENT '통계 처리 상태',
	STATUS_TEXT				VARCHAR(200)				NULL					COMMENT '전송결과 부가정보',
	SEND_SPID				VARCHAR(100)				NULL					COMMENT '이중화 구조 발송 SP_ID'

) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- 지역
CREATE TABLE areaMst(
	areaID					INT						NOT NULL AUTO_INCREMENT		COMMENT '지역키',
	areaName				VARCHAR(100)			NOT NULL					COMMENT '지역명',
	areaLatitude			DOUBLE					NOT NULL					COMMENT '위도 (37.xxxxxx)',
	areaLongitude			DOUBLE					NOT NULL					COMMENT '경도 (127.xxxxxx)',
	areaMemo				MEDIUMTEXT					NULL					COMMENT '메모',
	
	createDate				DATETIME				NOT NULL					COMMENT '생성일',
	updateDate				DATETIME					NULL					COMMENT '수정일',
	deleteDate				DATETIME					NULL					COMMENT '삭제일',
	
	PRIMARY KEY(areaID)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;


-- * 지역 <> 디바이스 (방송장비, CCTV, RTU)
-- * 지역 <> 센서

-- CCTV
CREATE TABLE cctvDevice(
	cctvID					VARCHAR(100)			NOT NULL 					COMMENT 'CCTV키',
	areaID					INT						NOT NULL					COMMENT '지역키',
	connectionURL			VARCHAR(200)			NOT NULL					COMMENT 'CCTV 연결 URL',
	connectionPort			INT						NOT NULL					COMMENT 'CCTV 연결 포트',
	password				VARCHAR(100)			NOT NULL					COMMENT 'CCTV 연결 암호',
	encryptKey				VARCHAR(100)			NOT NULL					COMMENT 'CCTV 연결 암호 키',
	latitude				DOUBLE					NOT NULL					COMMENT '위도',
	longitude				DOUBLE					NOT NULL					COMMENT '경도',
	addr1					VARCHAR(20)				NOT NULL					COMMENT '주소1',
	addr2					VARCHAR(20)				NOT NULL					COMMENT '주소2',
	addr3					VARCHAR(100)			NOT NULL					COMMENT '주소3',
	memo					MEDIUMTEXT					NULL					COMMENT '메모',
	
	PRIMARY KEY(cctvID, areaID)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- 방송장비 (비상예경보방송기기/마을방송)
CREATE TABLE broadcastDevice(
	broadcastDevID			INT						NOT NULL AUTO_INCREMENT		COMMENT '방송장비키',
	areaID					INT						NOT NULL					COMMENT '지역키',
	deviceType				INT						NOT NULL					COMMENT '방송장비 타입 { 0:비상예경보방송기기, 1:마을방송 }',
	phoneNum				VARCHAR(20)				NOT NULL					COMMENT '전화번호',
	latitude				DOUBLE					NOT NULL					COMMENT '위도',
	longitude				DOUBLE					NOT NULL					COMMENT '경도',
	addr1					VARCHAR(20)				NOT NULL					COMMENT '주소1',
	addr2					VARCHAR(20)				NOT NULL					COMMENT '주소2',
	addr3					VARCHAR(100)			NOT NULL					COMMENT '주소3',
	memo					MEDIUMTEXT					NULL					COMMENT '메모',

	PRIMARY KEY(broadcastDevID, areaID)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- RTU
CREATE TABLE rtuDevice(
	rtuID					VARCHAR(100)			NOT NULL					COMMENT 'RTU키',
	areaID					INT						NOT NULL					COMMENT '지역키',
	connectionURL			VARCHAR(200)			NOT NULL					COMMENT 'RTU 연결 URL',
	connectionPort			INT						NOT NULL					COMMENT 'RTU 연결 포트',
	latitude				DOUBLE					NOT NULL					COMMENT '위도',
	longitude				DOUBLE					NOT NULL					COMMENT '경도',
	addr1					VARCHAR(20)				NOT NULL					COMMENT '주소1',
	addr2					VARCHAR(20)				NOT NULL					COMMENT '주소2',
	addr3					VARCHAR(100)			NOT NULL					COMMENT '주소3',
	memo					MEDIUMTEXT					NULL					COMMENT '메모',

	PRIMARY KEY(rtuID, areaID)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- 센서
CREATE TABLE sensorInfo(
	sensorID				VARCHAR(100)			NOT NULL					COMMENT '센서키',
	areaID					INT						NOT NULL					COMMENT '지역키',
	rtuID					VARCHAR(100)			NOT NULL					COMMENT 'RTU키',
	sensorType				INT						NOT NULL					COMMENT '센서 타입 { 0:강우량계, 1:수위계, 2:변위계 }',
	sensorMin				DOUBLE					NOT NULL					COMMENT '센서 최소값',
	sensorMax				DOUBLE					NOT NULL					COMMENT '센서 최대값',
	latitude				DOUBLE					NOT NULL					COMMENT '위도',
	longitude				DOUBLE					NOT NULL					COMMENT '경도',
	addr1					VARCHAR(20)				NOT NULL					COMMENT '주소1',
	addr2					VARCHAR(20)				NOT NULL					COMMENT '주소2',
	addr3					VARCHAR(100)			NOT NULL					COMMENT '주소3',
	memo					MEDIUMTEXT					NULL					COMMENT '메모',
	
	isAlarm					CHAR(1)						NULL					COMMENT '센서 경보 알림 { Y:ON, NULL:OFF }',
	isNDMS					CHAR(1)						NULL					COMMENT 'NDMS 연동 { Y:ON, NULL:OFF }',
	alarmStandard			CHAR(1)						NULL					COMMENT '경보 기준 { H:높은, L:작은 }',
	cautionValue			INT							NULL					COMMENT '주의 알림 기준값',
	cautionDeadband			INT							NULL					COMMENT '주의 알림 Dead Band',
	alarmValue				INT							NULL					COMMENT '경보 알림 기준값',
	alarmDeadband			INT							NULL					COMMENT '경보 알림 Dead Band',
	evacuationValue			INT							NULL					COMMENT '대피 알림 기준값',
	evacuationDeadband		INT							NULL					COMMENT '대피 알림 Dead Band',
	
	PRIMARY KEY(sensorID, areaID, rtuID)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;


-- MQTT - RTU STATUS
CREATE TABLE mqttRtuStatus(
	rtuID					VARCHAR(100)			NOT NULL					COMMENT 'RTU키',
	rtuStatus				BOOLEAN					NOT NULL					COMMENT 'RTU status',
	watchdogStatus			BOOLEAN					NOT NULL					COMMENT 'WatchDog status',
	cdmaModemStatus			BOOLEAN					NOT NULL					COMMENT 'CDMA Modem status',
	acStatus				BOOLEAN					NOT NULL					COMMENT 'AC status',
	batteryStatus			BOOLEAN					NOT NULL					COMMENT 'Battery status',
	doorOpenStatus			BOOLEAN					NOT NULL					COMMENT 'Door Open status',
	batteryVoltage			VARCHAR(10)				NOT NULL					COMMENT 'RTU status',
	receiveDate				DATETIME 			   	NOT NULL					COMMENT '생성일',

	PRIMARY KEY(rtuID, receiveDate)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- MQTT - SENSOR STATUS
CREATE TABLE mqttSensorStatus(
	rtuID					VARCHAR(100)			NOT NULL					COMMENT 'RTU키',
	sensorID				VARCHAR(100)			NOT NULL					COMMENT '센서키',
	sensorType				VARCHAR(10)				NOT NULL					COMMENT 'SENSOR type {11021:강우량계, 11031:수위계, 11071:변위계}',
	sensorStatus			BOOLEAN					NOT NULL					COMMENT 'SENSOR status',
	receiveDate				DATETIME 			   	NOT NULL					COMMENT '생성일',
	
	PRIMARY KEY(rtuID, sensorType, receiveDate)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

-- MQTT - SENSOR VALUE
CREATE TABLE mqttSensorValue(
	rtuID					VARCHAR(100)			NOT NULL					COMMENT 'RTU키',
	sensorID				VARCHAR(100)			NOT NULL					COMMENT '센서키',
	valueType				VARCHAR(10)				NOT NULL					COMMENT 'VALUE type',
	unitType				VARCHAR(10)				NOT NULL					COMMENT '단위타입 {cm, mm}',
	dataType				VARCHAR(10)				NOT NULL					COMMENT '데이터타입 {DEC, DOB, BOL(0,1)}',
	dataValue				VARCHAR(10)				NOT NULL					COMMENT '데이터',
	receiveDate				DATETIME 			   	NOT NULL					COMMENT '생성일',

	PRIMARY KEY(rtuID, valueType, receiveDate)
) ENGINE = InnoDB
DEFAULT CHARSET=utf8;

