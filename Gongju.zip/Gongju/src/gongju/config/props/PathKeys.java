package gongju.config.props;

public class PathKeys {

	public static String CALLBACK = "0418504300";

	
	public static String TTS_REQ = "http://124.194.27.99:8903/api/v1/file";
	public static String TTS_RES = "http://124.194.27.99:8902/TTS/files/";
	
	
	public static String MQTT_IP = "124.194.27.99";
	public static String MQTT_PORT = "8901";
	
}
