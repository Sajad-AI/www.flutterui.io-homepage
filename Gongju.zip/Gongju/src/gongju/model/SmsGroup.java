package gongju.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "SMS 그룹")
public class SmsGroup {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer smsGroupSeq;
	
	@ApiModelProperty(value = "그룹명", dataType = "String", required = true)
	String smsGroupName;
	
	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "생성일", dataType = "String", required = false)
	String createDate;
	
	@ApiModelProperty(value = "수정일", dataType = "String", required = false)
	String updateDate;
	
	@JsonIgnore
	String deleteDate;

	@ApiModelProperty(value = "연락처", dataType = "SmsPhone", required = false)
	List<SmsPhone> smsPhoneList;
	
	public Integer getSmsGroupSeq() {
		return smsGroupSeq;
	}

	public void setSmsGroupSeq(Integer smsGroupSeq) {
		this.smsGroupSeq = smsGroupSeq;
	}

	public String getSmsGroupName() {
		return smsGroupName;
	}

	public void setSmsGroupName(String smsGroupName) {
		this.smsGroupName = smsGroupName;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(String deleteDate) {
		this.deleteDate = deleteDate;
	}

	public List<SmsPhone> getSmsPhoneList() {
		return smsPhoneList;
	}

	public void setSmsPhoneList(List<SmsPhone> smsPhoneList) {
		this.smsPhoneList = smsPhoneList;
	}
	
}
