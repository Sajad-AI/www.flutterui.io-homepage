package gongju.model;

import java.io.Serializable;
import java.util.List;


public class PaginationList<E> implements Serializable{
	
	private static final long serialVersionUID = 6491434094376516123L;

	//DataList
	private List<?> dataList;
	
	//전체 카운트
	private int totalCount = 0;
	//페이지당 보여줄 목록
	private int pageRows = 0;
	//페이지 넘버링 
	private int pageNum = 0;
	//현재 페이지 number
	private int currentPage = 0;
	
	
	//페이지 단위 시작번호  
	private int pagingStartNum = 0;
	//페이지 단위 종료번호 
	private int pagingEndNum = 0;
	//마지막 페이지 번호
	private int pagingFinalNum = 0;
	//처음 페이지 번호
	private final int pagingFirstNum = 1;
	
	public PaginationList(List<?> list,int totalCount,int currentPage,int pageRows,int pageNum) {
		this.dataList = list;
		this.totalCount = totalCount;
		this.currentPage = currentPage;
		this.pageRows = pageRows;
		this.pageNum = pageNum;	
		makeNumbers();
	}
	
	private void makeNumbers(){
		//전체페이지 
		if(totalCount == 0){
			pagingStartNum = 1;
			pagingEndNum = 1;
			pagingFinalNum = 1;
			return;
		}
		//마지막 페이지
		pagingFinalNum = (int) Math.ceil( totalCount  / (double)pageRows );
		//페이지단위 스타트
		pagingStartNum = ( ( currentPage - 1 )  / pageNum ) * pageNum + 1 ; 
		//페이지 단위 마지막
		pagingEndNum = pagingStartNum + pageNum - 1;
		//페이지단위가 마지막페이지번호보다 크면안됨
		pagingEndNum = pagingEndNum > pagingFinalNum ? pagingFinalNum : pagingEndNum;
	}
	
	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public int getPageRows() {
		return pageRows;
	}

	public void setPageRows(int pageRows) {
		this.pageRows = pageRows;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	
	public List<?> getDataList() {
		return dataList;
	}

	public void setDataList(List<?> dataList) {
		this.dataList = dataList;
	}

	public int getPageNum() {
		return pageNum;
	}

	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}

	public int getPagingFirstNum() {
		return pagingFirstNum;
	}

	public int getPagingStartNum() {
		return pagingStartNum;
	}

	public int getPagingEndNum() {
		return pagingEndNum;
	}

	public int getPagingFinalNum() {
		return pagingFinalNum;
	}
	
}
