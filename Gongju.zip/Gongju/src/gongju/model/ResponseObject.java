package gongju.model;

import io.swagger.annotations.ApiModelProperty;

public class ResponseObject<T> {

	@ApiModelProperty(example = "HttpStatus Code")
	int 	code;
	
	@ApiModelProperty(example = "HttpStatus Message")
	String 	message;
		
	@ApiModelProperty(example = "Return Object")
	T 		data;
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	
}
