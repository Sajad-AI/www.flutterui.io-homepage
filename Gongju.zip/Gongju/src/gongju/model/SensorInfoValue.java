package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "센서")
public class SensorInfoValue {

	@ApiModelProperty(value = "센서 ID", dataType = "String", required = false)
	String sensorID;
	
	@ApiModelProperty(value = "31023(강우량/금일), 31031(수위계), 31071(변위계)", dataType = "String", required = false)
	String valueType;
	
	@ApiModelProperty(value = "단위타입 {cm, mm}", dataType = "String", required = false)
	String unitType;
	
	@ApiModelProperty(value = "데이터타입 {DEC, DOB, BOL(0,1)}", dataType = "String", required = false)
	String dataType;
	
	@ApiModelProperty(value = "데이터", dataType = "String", required = false)
	String dataValue;
	
	public String getSensorID() {
		return sensorID;
	}

	public void setSensorID(String sensorID) {
		this.sensorID = sensorID;
	}

	public String getValueType() {
		return valueType;
	}

	public void setValueType(String valueType) {
		this.valueType = valueType;
	}

	public String getUnitType() {
		return unitType;
	}

	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public String getDataValue() {
		return dataValue;
	}

	public void setDataValue(String dataValue) {
		this.dataValue = dataValue;
	}

}
