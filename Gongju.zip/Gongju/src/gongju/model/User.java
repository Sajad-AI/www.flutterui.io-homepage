package gongju.model;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class User implements UserDetails {

	/* 
	 * Basically Override Variables
	 */
	private static final long serialVersionUID = 1L;

	private String username; 
	private String password;

	private Collection<GrantedAuthority> authorities; 
	private boolean accountNonExpired = true; 
	private boolean accountNonLocked = true; 
	private boolean credentialsNonExpired = true; 
	private boolean enabled = true;
	
	/*
	 * Custom Column For Here
	 */
	
	String userID, userFullName, phoneNum, organizationName;
	Boolean isAdminPerm, isSMSPerm, isBroadcastPerm, isCCTVViewPerm, isCCTVCtrlPerm, isVerifiedByAdmin;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getUserFullName() {
		return userFullName;
	}
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	public String getOrganizationName() {
		return organizationName;
	}
	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	public Boolean getIsAdminPerm() {
		return isAdminPerm;
	}
	public void setIsAdminPerm(Boolean isAdminPerm) {
		this.isAdminPerm = isAdminPerm;
	}
	public Boolean getIsSMSPerm() {
		return isSMSPerm;
	}
	public void setIsSMSPerm(Boolean isSMSPerm) {
		this.isSMSPerm = isSMSPerm;
	}
	public Boolean getIsBroadcastPerm() {
		return isBroadcastPerm;
	}
	public void setIsBroadcastPerm(Boolean isBroadcastPerm) {
		this.isBroadcastPerm = isBroadcastPerm;
	}
	public Boolean getIsCCTVViewPerm() {
		return isCCTVViewPerm;
	}
	public void setIsCCTVViewPerm(Boolean isCCTVViewPerm) {
		this.isCCTVViewPerm = isCCTVViewPerm;
	}
	public Boolean getIsCCTVCtrlPerm() {
		return isCCTVCtrlPerm;
	}
	public void setIsCCTVCtrlPerm(Boolean isCCTVCtrlPerm) {
		this.isCCTVCtrlPerm = isCCTVCtrlPerm;
	}
	public Boolean getIsVerifiedByAdmin() {
		return isVerifiedByAdmin;
	}
	public void setIsVerifiedByAdmin(Boolean isVerifiedByAdmin) {
		this.isVerifiedByAdmin = isVerifiedByAdmin;
	}
	public void setAuthorities(Collection<GrantedAuthority> authorities) {
		this.authorities = authorities;
	}
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return this.authorities;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	@Override
	public String getUsername() {
		return this.username;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String getPassword() {
		return this.password;
	}
	public void setAccountNonExpired(boolean accountNonExpired) {
		this.accountNonExpired = accountNonExpired;
	}
	@Override
	public boolean isAccountNonExpired() {
		return this.accountNonExpired;
	}
	public void setAccountNonLocked(boolean accountNonLocked) {
		this.accountNonLocked = accountNonLocked;
	}
	@Override
	public boolean isAccountNonLocked() {
		return this.accountNonLocked;
	}
	public void setCredentialsNonExpired(boolean credentialsNonExpired) {
		this.credentialsNonExpired = credentialsNonExpired;
	}
	@Override
	public boolean isCredentialsNonExpired() {
		return this.credentialsNonExpired;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	@Override
	public boolean isEnabled() {
		return this.enabled;
	}
}
