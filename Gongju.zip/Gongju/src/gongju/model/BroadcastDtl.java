package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "방송 송출 > 전송")
public class BroadcastDtl {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer broadcastDtlSeq;
	
	@ApiModelProperty(value = "방송 송출 키", dataType = "Integer", required = false, example = "0")
	Integer broadcastMstSeq;
	
	@ApiModelProperty(value = "방송장비키", dataType = "Integer", required = true, example = "0")
	Integer broadcastDevID;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = true)
	String phoneNum;
	
	@ApiModelProperty(value = "지역키", dataType = "Integer", required = true, example = "0")
	Integer areaID;
	
	@ApiModelProperty(value = "방송일자", dataType = "String", required = false)
	String broadcastDate;
	
	public Integer getBroadcastDtlSeq() {
		return broadcastDtlSeq;
	}

	public void setBroadcastDtlSeq(Integer broadcastDtlSeq) {
		this.broadcastDtlSeq = broadcastDtlSeq;
	}

	public Integer getBroadcastMstSeq() {
		return broadcastMstSeq;
	}

	public void setBroadcastMstSeq(Integer broadcastMstSeq) {
		this.broadcastMstSeq = broadcastMstSeq;
	}

	public Integer getBroadcastDevID() {
		return broadcastDevID;
	}

	public void setBroadcastDevID(Integer broadcastDevID) {
		this.broadcastDevID = broadcastDevID;
	}

	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

	public String getBroadcastDate() {
		return broadcastDate;
	}

	public void setBroadcastDate(String broadcastDate) {
		this.broadcastDate = broadcastDate;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}
	
}
