package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "저수율 정보")
public class ReservoirRate {

	@ApiModelProperty(value = "지역명", dataType = "String", required = false)
	String areaName;
	
	@ApiModelProperty(value = "오늘", dataType = "Double", required = false, example = "0")
	Double todayRate;
	
	@ApiModelProperty(value = "전일", dataType = "Double", required = false, example = "0")
	Double yesterdayRate;

	@ApiModelProperty(value = "전일대비", dataType = "Double", required = false, example = "0")
	Double diffRate;

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public Double getTodayRate() {
		return todayRate;
	}

	public void setTodayRate(Double todayRate) {
		this.todayRate = todayRate;
	}

	public Double getYesterdayRate() {
		return yesterdayRate;
	}

	public void setYesterdayRate(Double yesterdayRate) {
		this.yesterdayRate = yesterdayRate;
	}

	public Double getDiffRate() {
		return diffRate;
	}

	public void setDiffRate(Double diffRate) {
		this.diffRate = diffRate;
	}
	
}
