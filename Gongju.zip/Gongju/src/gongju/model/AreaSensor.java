package gongju.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "지역")
public class AreaSensor {

	@ApiModelProperty(value = "지역키", dataType = "Integer", required = false, example = "0")
	Integer areaID;
	
	@ApiModelProperty(value = "지역명", dataType = "String", required = true)
	String areaName;
	
	@ApiModelProperty(value = "센서 목록", dataType = "SensorInfo", required = false)
	List<SensorInfoValue> sensorInfoValue;
	
	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public List<SensorInfoValue> getSensorInfoValue() {
		return sensorInfoValue;
	}

	public void setSensorInfoValue(List<SensorInfoValue> sensorInfoValue) {
		this.sensorInfoValue = sensorInfoValue;
	}

}
