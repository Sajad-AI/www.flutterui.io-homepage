package gongju.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "SMS 문안")
public class SmsTemplate {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer smsTemplateSeq;
	
	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "명칭", dataType = "String", required = true)
	String smsTemplateTitle;
	
	@ApiModelProperty(value = "문안", dataType = "String", required = true)
	String smsTemplate;
	
	@ApiModelProperty(value = "생성일", dataType = "String", required = false)
	String createDate;
	
	@ApiModelProperty(value = "수정일", dataType = "String", required = false)
	String updateDate;
	
	@JsonIgnore
	String deleteDate;

	public Integer getSmsTemplateSeq() {
		return smsTemplateSeq;
	}

	public void setSmsTemplateSeq(Integer smsTemplateSeq) {
		this.smsTemplateSeq = smsTemplateSeq;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getSmsTemplateTitle() {
		return smsTemplateTitle;
	}

	public void setSmsTemplateTitle(String smsTemplateTitle) {
		this.smsTemplateTitle = smsTemplateTitle;
	}

	public String getSmsTemplate() {
		return smsTemplate;
	}

	public void setSmsTemplate(String smsTemplate) {
		this.smsTemplate = smsTemplate;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(String deleteDate) {
		this.deleteDate = deleteDate;
	}
	
}
