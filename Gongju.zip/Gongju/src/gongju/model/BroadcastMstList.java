package gongju.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "방송 송출")
public class BroadcastMstList {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer broadcastMstSeq;
	
	@ApiModelProperty(value = "방송 송출 제목 (방송 문안 > 경보)", dataType = "String", required = false)
	String broadcastTitle;
	
	@ApiModelProperty(value = "방송 송출 내용", dataType = "String", required = false)
	String broadcastContent;
	
	@ApiModelProperty(value = "시작 효과음 { 0:차임벨, 1:사이렌 }", dataType = "Integer", required = false, example = "0")
	Integer beginEffect;
	
	@ApiModelProperty(value = "종료 효과음 { 0:차임벨, 1:사이렌 }", dataType = "Integer", required = false, example = "0")
	Integer endEffect;
	
	@ApiModelProperty(value = "D:즉시(수동), R:예약(자동)", dataType = "String", required = false)
	String broadcastType;
	
	@ApiModelProperty(value = "D:일간, W:주간, M:월간", dataType = "String", required = false)
	String broadcastPeriodType;
	
	@ApiModelProperty(value = "시작 기간 { yyyy-MM-dd }", dataType = "String", required = false)
	String beginPeriod;
	
	@ApiModelProperty(value = "종료 기간 { yyyy-MM-dd }", dataType = "String", required = false)
	String endPeriod;
	
	@ApiModelProperty(value = "시", dataType = "Integer", required = false, example = "0")
	Integer sendHour;
	
	@ApiModelProperty(value = "분", dataType = "Integer", required = false, example = "0")
	Integer sendMinute;
	
	@ApiModelProperty(value = "* 콤마연결(ex.1,3,5,7 ...) > 주간 : {1:월, 2:화, 3:수, 4:목, 5:금, 6:토, 7:일} || 월간 : {1-30, 마지막날:L}", dataType = "String", required = false)
	String sendPeriod;
	
	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = false)
	String userID;
	
	@ApiModelProperty(value = "방송시작", dataType = "String", required = false)
	String beginBroadcastDate;
	
	@ApiModelProperty(value = "방송종료", dataType = "String", required = false)
	String endBroadcastDate;
	
	@ApiModelProperty(value = "처리상태", dataType = "String", required = false)
	String sendStatus;
	
	@ApiModelProperty(value = "방송 송출 > 전송 목록", dataType = "BroadcastDtl", required = false)
	List<BroadcastDtlList> broadcastDtlList;

	public Integer getBroadcastMstSeq() {
		return broadcastMstSeq;
	}

	public void setBroadcastMstSeq(Integer broadcastMstSeq) {
		this.broadcastMstSeq = broadcastMstSeq;
	}

	public String getBroadcastTitle() {
		return broadcastTitle;
	}

	public void setBroadcastTitle(String broadcastTitle) {
		this.broadcastTitle = broadcastTitle;
	}

	public String getBroadcastContent() {
		return broadcastContent;
	}

	public void setBroadcastContent(String broadcastContent) {
		this.broadcastContent = broadcastContent;
	}

	public Integer getBeginEffect() {
		return beginEffect;
	}

	public void setBeginEffect(Integer beginEffect) {
		this.beginEffect = beginEffect;
	}

	public Integer getEndEffect() {
		return endEffect;
	}

	public void setEndEffect(Integer endEffect) {
		this.endEffect = endEffect;
	}

	public String getBroadcastType() {
		return broadcastType;
	}

	public void setBroadcastType(String broadcastType) {
		this.broadcastType = broadcastType;
	}

	public String getBroadcastPeriodType() {
		return broadcastPeriodType;
	}

	public void setBroadcastPeriodType(String broadcastPeriodType) {
		this.broadcastPeriodType = broadcastPeriodType;
	}

	public String getBeginPeriod() {
		return beginPeriod;
	}

	public void setBeginPeriod(String beginPeriod) {
		this.beginPeriod = beginPeriod;
	}

	public String getEndPeriod() {
		return endPeriod;
	}

	public void setEndPeriod(String endPeriod) {
		this.endPeriod = endPeriod;
	}

	public Integer getSendHour() {
		return sendHour;
	}

	public void setSendHour(Integer sendHour) {
		this.sendHour = sendHour;
	}

	public Integer getSendMinute() {
		return sendMinute;
	}

	public void setSendMinute(Integer sendMinute) {
		this.sendMinute = sendMinute;
	}

	public String getSendPeriod() {
		return sendPeriod;
	}

	public void setSendPeriod(String sendPeriod) {
		this.sendPeriod = sendPeriod;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getBeginBroadcastDate() {
		return beginBroadcastDate;
	}

	public void setBeginBroadcastDate(String beginBroadcastDate) {
		this.beginBroadcastDate = beginBroadcastDate;
	}

	public String getEndBroadcastDate() {
		return endBroadcastDate;
	}

	public void setEndBroadcastDate(String endBroadcastDate) {
		this.endBroadcastDate = endBroadcastDate;
	}

	public String getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}

	public List<BroadcastDtlList> getBroadcastDtlList() {
		return broadcastDtlList;
	}

	public void setBroadcastDtlList(List<BroadcastDtlList> broadcastDtlList) {
		this.broadcastDtlList = broadcastDtlList;
	}
	
}
