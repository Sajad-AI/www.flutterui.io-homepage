package gongju.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "SMS 발송")
public class SmsMstList {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer smsMstSeq;
	
	@ApiModelProperty(value = "전송/예약일", dataType = "String", required = false)
	String sendDate;
	
	@ApiModelProperty(value = "SMS내용", dataType = "String", required = false)
	String smsContent;
	
	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = false)
	String userID;
	
	@ApiModelProperty(value = "처리상태", dataType = "String", required = false)
	String sendStatus;

	@ApiModelProperty(value = "수신자 목록", dataType = "SmsDtl", required = false)
	List<SmsDtlList> smsDtlList;

	public Integer getSmsMstSeq() {
		return smsMstSeq;
	}

	public void setSmsMstSeq(Integer smsMstSeq) {
		this.smsMstSeq = smsMstSeq;
	}

	public String getSendDate() {
		return sendDate;
	}

	public void setSendDate(String sendDate) {
		this.sendDate = sendDate;
	}

	public String getSmsContent() {
		return smsContent;
	}

	public void setSmsContent(String smsContent) {
		this.smsContent = smsContent;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(String sendStatus) {
		this.sendStatus = sendStatus;
	}

	public List<SmsDtlList> getSmsDtlList() {
		return smsDtlList;
	}

	public void setSmsDtlList(List<SmsDtlList> smsDtlList) {
		this.smsDtlList = smsDtlList;
	}
	
}
