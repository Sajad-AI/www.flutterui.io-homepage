package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "방송장비 (비상예경보방송기기 / 마을방송)")
public class BroadcastDevice {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer broadcastDevID;
	
	@ApiModelProperty(value = "지역키", dataType = "Integer", required = true, example = "0")
	Integer areaID;
	
	@ApiModelProperty(value = "방송장비 타입 { 0:비상예경보방송기기, 1:마을방송 }", dataType = "Integer", required = true, example = "0")
	Integer deviceType;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = true)
	String phoneNum;
	
	@ApiModelProperty(value = "위도", dataType = "Double", required = true, example = "37.19778368619912")
	Double latitude;
	
	@ApiModelProperty(value = "경도", dataType = "Double", required = true, example = "127.48735537691726")
	Double longitude;
	
	@ApiModelProperty(value = "주소1", dataType = "String", required = true)
	String addr1;
	
	@ApiModelProperty(value = "주소2", dataType = "String", required = true)
	String addr2;
	
	@ApiModelProperty(value = "주소3", dataType = "String", required = true)
	String addr3;
	
	@ApiModelProperty(value = "메모", dataType = "String", required = false)
	String memo;

	public Integer getBroadcastDevID() {
		return broadcastDevID;
	}

	public void setBroadcastDevID(Integer broadcastDevID) {
		this.broadcastDevID = broadcastDevID;
	}

	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

	public Integer getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(Integer deviceType) {
		this.deviceType = deviceType;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}
	
}
