package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "방송 문안")
public class BroadcastTemplate {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer broadcastTemplateSeq;
	
	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "경보", dataType = "String", required = true)
	String broadcastTemplateTitle;
	
	@ApiModelProperty(value = "문안", dataType = "String", required = true)
	String broadcastTemplate;
	
	@ApiModelProperty(value = "생성일", dataType = "String", required = false)
	String createDate;
	
	@ApiModelProperty(value = "수정일", dataType = "String", required = false)
	String updateDate;

	public Integer getBroadcastTemplateSeq() {
		return broadcastTemplateSeq;
	}

	public void setBroadcastTemplateSeq(Integer broadcastTemplateSeq) {
		this.broadcastTemplateSeq = broadcastTemplateSeq;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getBroadcastTemplateTitle() {
		return broadcastTemplateTitle;
	}

	public void setBroadcastTemplateTitle(String broadcastTemplateTitle) {
		this.broadcastTemplateTitle = broadcastTemplateTitle;
	}

	public String getBroadcastTemplate() {
		return broadcastTemplate;
	}

	public void setBroadcastTemplate(String broadcastTemplate) {
		this.broadcastTemplate = broadcastTemplate;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	
}
