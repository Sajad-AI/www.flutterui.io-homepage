package gongju.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "SMS 발송")
public class SmsMst {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer smsMstSeq;
	
	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "SMS내용", dataType = "String", required = true)
	String smsContent;
	
	@ApiModelProperty(value = "D:즉시, R:예약", dataType = "String", required = true)
	String smsType;
	
	@ApiModelProperty(value = "생성일", dataType = "String", required = false)
	String createDate;
	
	@ApiModelProperty(value = "예약시간 { yyyy-MM-dd HH:mm }", dataType = "String", required = false)
	String reserveDate;

	@ApiModelProperty(value = "수신자 목록", dataType = "SmsDtl", required = false)
	List<SmsDtl> smsDtlList;
	
	public Integer getSmsMstSeq() {
		return smsMstSeq;
	}

	public void setSmsMstSeq(Integer smsMstSeq) {
		this.smsMstSeq = smsMstSeq;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getSmsContent() {
		return smsContent;
	}

	public void setSmsContent(String smsContent) {
		this.smsContent = smsContent;
	}

	public String getSmsType() {
		return smsType;
	}

	public void setSmsType(String smsType) {
		this.smsType = smsType;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getReserveDate() {
		return reserveDate;
	}

	public void setReserveDate(String reserveDate) {
		this.reserveDate = reserveDate;
	}

	public List<SmsDtl> getSmsDtlList() {
		return smsDtlList;
	}

	public void setSmsDtlList(List<SmsDtl> smsDtlList) {
		this.smsDtlList = smsDtlList;
	}
	
}
