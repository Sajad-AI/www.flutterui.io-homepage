package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "사용자")
public class UserMstList {

	@ApiModelProperty(value = "페이지번호", dataType = "Integer", required = false, example = "1")
	Integer currentPage;
	
	@ApiModelProperty(value = "사용자 명", dataType = "String", required = true)
	String userFullName;
	
	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}
	
}
