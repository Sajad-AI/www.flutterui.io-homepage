package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "센서")
public class SensorInfoModify {

	@ApiModelProperty(value = "센서 타입 { 0:강우량계, 1:수위계, 2:변위계 }", dataType = "Integer", required = true, example = "0")
	Integer sensorType;
	
	@ApiModelProperty(value = "RTU ID", dataType = "String", required = true)
	String rtuID;
	
	@ApiModelProperty(value = "센서 ID", dataType = "String", required = true)
	String sensorID;
	
	@ApiModelProperty(value = "지역키", dataType = "Integer", required = true, example = "0")
	Integer areaID;
	
	@ApiModelProperty(value = "위도", dataType = "Double", required = true, example = "37.19778368619912")
	Double latitude;
	
	@ApiModelProperty(value = "경도", dataType = "Double", required = true, example = "127.48735537691726")
	Double longitude;
	
	@ApiModelProperty(value = "주소1", dataType = "String", required = true)
	String addr1;
	
	@ApiModelProperty(value = "주소2", dataType = "String", required = true)
	String addr2;
	
	@ApiModelProperty(value = "주소3", dataType = "String", required = true)
	String addr3;
	
	@ApiModelProperty(value = "센서 최소값", dataType = "String", required = true)
	Integer sensorMin;
	
	@ApiModelProperty(value = "센서 최대값", dataType = "String", required = true)
	Integer sensorMax;
	
	@ApiModelProperty(value = "메모", dataType = "String", required = false)
	String memo;
	
	@ApiModelProperty(value = "센서 경보 알림 { Y:ON, N:OFF }", dataType = "String", required = false)
	String isAlarm;
	
	@ApiModelProperty(value = "NDMS 연동 { Y:ON, N:OFF }", dataType = "String", required = false)
	String isNDMS;
	
	@ApiModelProperty(value = "경보 기준 { H:높은, L:작은 }", dataType = "String", required = false)
	String alarmStandard;
	
	@ApiModelProperty(value = "주의 알림 기준값", dataType = "Integer", required = false, example = "0")
	Integer cautionValue;
	
	@ApiModelProperty(value = "주의 알림 Dead Band", dataType = "Integer", required = false, example = "0")
	Integer cautionDeadband;
	
	@ApiModelProperty(value = "경보 알림 기준값", dataType = "Integer", required = false, example = "0")
	Integer alarmValue;
	
	@ApiModelProperty(value = "경보 알림 Dead Band", dataType = "Integer", required = false, example = "0")
	Integer alarmDeadband;
	
	@ApiModelProperty(value = "대피 알림 기준값", dataType = "Integer", required = false, example = "0")
	Integer evacuationValue;
	
	@ApiModelProperty(value = "대피 알림 Dead Band", dataType = "Integer", required = false, example = "0")
	Integer evacuationDeadband;

	public Integer getSensorType() {
		return sensorType;
	}

	public void setSensorType(Integer sensorType) {
		this.sensorType = sensorType;
	}

	public String getRtuID() {
		return rtuID;
	}

	public void setRtuID(String rtuID) {
		this.rtuID = rtuID;
	}

	public String getSensorID() {
		return sensorID;
	}

	public void setSensorID(String sensorID) {
		this.sensorID = sensorID;
	}

	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	public Integer getSensorMin() {
		return sensorMin;
	}

	public void setSensorMin(Integer sensorMin) {
		this.sensorMin = sensorMin;
	}

	public Integer getSensorMax() {
		return sensorMax;
	}

	public void setSensorMax(Integer sensorMax) {
		this.sensorMax = sensorMax;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getIsAlarm() {
		return isAlarm;
	}

	public void setIsAlarm(String isAlarm) {
		this.isAlarm = isAlarm;
	}

	public String getIsNDMS() {
		return isNDMS;
	}

	public void setIsNDMS(String isNDMS) {
		this.isNDMS = isNDMS;
	}

	public String getAlarmStandard() {
		return alarmStandard;
	}

	public void setAlarmStandard(String alarmStandard) {
		this.alarmStandard = alarmStandard;
	}

	public Integer getCautionValue() {
		return cautionValue;
	}

	public void setCautionValue(Integer cautionValue) {
		this.cautionValue = cautionValue;
	}

	public Integer getCautionDeadband() {
		return cautionDeadband;
	}

	public void setCautionDeadband(Integer cautionDeadband) {
		this.cautionDeadband = cautionDeadband;
	}

	public Integer getAlarmValue() {
		return alarmValue;
	}

	public void setAlarmValue(Integer alarmValue) {
		this.alarmValue = alarmValue;
	}

	public Integer getAlarmDeadband() {
		return alarmDeadband;
	}

	public void setAlarmDeadband(Integer alarmDeadband) {
		this.alarmDeadband = alarmDeadband;
	}

	public Integer getEvacuationValue() {
		return evacuationValue;
	}

	public void setEvacuationValue(Integer evacuationValue) {
		this.evacuationValue = evacuationValue;
	}

	public Integer getEvacuationDeadband() {
		return evacuationDeadband;
	}

	public void setEvacuationDeadband(Integer evacuationDeadband) {
		this.evacuationDeadband = evacuationDeadband;
	}
	
}
