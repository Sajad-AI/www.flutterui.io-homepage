package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsGroupModify {

	@ApiModelProperty(value = "그룹키", dataType = "Integer", required = true, example = "0")
	Integer smsGroupSeq;
	
	@ApiModelProperty(value = "그룹명", dataType = "String", required = true)
	String smsGroupName;

	public Integer getSmsGroupSeq() {
		return smsGroupSeq;
	}

	public void setSmsGroupSeq(Integer smsGroupSeq) {
		this.smsGroupSeq = smsGroupSeq;
	}

	public String getSmsGroupName() {
		return smsGroupName;
	}

	public void setSmsGroupName(String smsGroupName) {
		this.smsGroupName = smsGroupName;
	}
	
}
