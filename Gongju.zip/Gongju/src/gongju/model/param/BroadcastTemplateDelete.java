package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class BroadcastTemplateDelete {

	@ApiModelProperty(value = "문안키", dataType = "Integer", required = true, example = "0")
	Integer broadcastTemplateSeq;

	public Integer getBroadcastTemplateSeq() {
		return broadcastTemplateSeq;
	}

	public void setBroadcastTemplateSeq(Integer broadcastTemplateSeq) {
		this.broadcastTemplateSeq = broadcastTemplateSeq;
	}
	
}
