package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "RTU")
public class RTUDeviceModify {

	@ApiModelProperty(value = "RTU ID", dataType = "String", required = true)
	String rtuID;
	
	@ApiModelProperty(value = "지역키", dataType = "Integer", required = true, example = "0")
	Integer areaID;

	@ApiModelProperty(value = "RTU 연결 URL", dataType = "String", required = true)
	String connectionURL;
	
	@ApiModelProperty(value = "RTU 연결 포트", dataType = "Integer", required = true, example = "0")
	Integer connectionPort;
	
	@ApiModelProperty(value = "위도", dataType = "Double", required = true, example = "37.19778368619912")
	Double latitude;
	
	@ApiModelProperty(value = "경도", dataType = "Double", required = true, example = "127.48735537691726")
	Double longitude;
	
	@ApiModelProperty(value = "주소1", dataType = "String", required = true)
	String addr1;
	
	@ApiModelProperty(value = "주소2", dataType = "String", required = true)
	String addr2;
	
	@ApiModelProperty(value = "주소3", dataType = "String", required = true)
	String addr3;
	
	@ApiModelProperty(value = "메모", dataType = "String", required = false)
	String memo;

	public String getRtuID() {
		return rtuID;
	}

	public void setRtuID(String rtuID) {
		this.rtuID = rtuID;
	}

	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

	public String getConnectionURL() {
		return connectionURL;
	}

	public void setConnectionURL(String connectionURL) {
		this.connectionURL = connectionURL;
	}

	public Integer getConnectionPort() {
		return connectionPort;
	}

	public void setConnectionPort(Integer connectionPort) {
		this.connectionPort = connectionPort;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}
	
}
