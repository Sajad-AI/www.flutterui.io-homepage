package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "방송장비 (비상예경보방송기기 / 마을방송)")
public class BroadcastDeviceDelete {

	@ApiModelProperty(value = "방송장비키", dataType = "Integer", required = true, example = "0")
	Integer broadcastDevID;
	
	@ApiModelProperty(value = "지역키", dataType = "Integer", required = true, example = "0")
	Integer areaID;
	
	public Integer getBroadcastDevID() {
		return broadcastDevID;
	}

	public void setBroadcastDevID(Integer broadcastDevID) {
		this.broadcastDevID = broadcastDevID;
	}

	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}
	
}
