package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsTemplateModify {

	@ApiModelProperty(value = "문안키", dataType = "Integer", required = true, example = "0")
	Integer smsTemplateSeq;
	
	@ApiModelProperty(value = "명칭", dataType = "String", required = true)
	String smsTemplateTitle;
	
	@ApiModelProperty(value = "문안", dataType = "String", required = true)
	String smsTemplate;

	public Integer getSmsTemplateSeq() {
		return smsTemplateSeq;
	}

	public void setSmsTemplateSeq(Integer smsTemplateSeq) {
		this.smsTemplateSeq = smsTemplateSeq;
	}

	public String getSmsTemplateTitle() {
		return smsTemplateTitle;
	}

	public void setSmsTemplateTitle(String smsTemplateTitle) {
		this.smsTemplateTitle = smsTemplateTitle;
	}

	public String getSmsTemplate() {
		return smsTemplate;
	}

	public void setSmsTemplate(String smsTemplate) {
		this.smsTemplate = smsTemplate;
	}
	
}
