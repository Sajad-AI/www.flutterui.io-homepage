package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "지역")
public class AreaMstAdd {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer areaID;
	
	@ApiModelProperty(value = "지역명", dataType = "String", required = true)
	String areaName;
	
	@ApiModelProperty(value = "경도", dataType = "Double", required = true, example = "127.48735537691726")
	Double areaLongitude;
	
	@ApiModelProperty(value = "위도", dataType = "Double", required = true, example = "37.19778368619912")
	Double areaLatitude;
	
	@ApiModelProperty(value = "메모", dataType = "String", required = false)
	String areaMemo;
	
	@ApiModelProperty(value = "생성일", dataType = "String", required = false)
	String createDate;
	
	@ApiModelProperty(value = "주소1", dataType = "String", required = false)
	String addr1;
	
	@ApiModelProperty(value = "주소2", dataType = "String", required = false)
	String addr2;
	
	@ApiModelProperty(value = "주소3", dataType = "String", required = false)
	String addr3;
	
	@ApiModelProperty(value = "NDMS 연계 여부", dataType = "boolean", required = false)
	boolean isNDMS;
	
	@ApiModelProperty(value = "NDMS 연계 상태", dataType = "int", required = false)
	int ndmsStatus;
	
	@ApiModelProperty(value = "NDMS 연계 결과", dataType = "String", required = false)
	String ndmsResult;
	
	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public Double getAreaLongitude() {
		return areaLongitude;
	}

	public void setAreaLongitude(Double areaLongitude) {
		this.areaLongitude = areaLongitude;
	}

	public Double getAreaLatitude() {
		return areaLatitude;
	}

	public void setAreaLatitude(Double areaLatitude) {
		this.areaLatitude = areaLatitude;
	}

	public String getAreaMemo() {
		return areaMemo;
	}

	public void setAreaMemo(String areaMemo) {
		this.areaMemo = areaMemo;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	public boolean isNDMS() {
		return isNDMS;
	}

	public void setNDMS(boolean isNDMS) {
		this.isNDMS = isNDMS;
	}

	public int getNdmsStatus() {
		return ndmsStatus;
	}

	public void setNdmsStatus(int ndmsStatus) {
		this.ndmsStatus = ndmsStatus;
	}

	public String getNdmsResult() {
		return ndmsResult;
	}

	public void setNdmsResult(String ndmsResult) {
		this.ndmsResult = ndmsResult;
	}
	
	
}
