package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsSendDelete {

	@ApiModelProperty(value = "SMS키", dataType = "Integer", required = true, example = "0")
	Integer smsMstSeq;

	public Integer getSmsMstSeq() {
		return smsMstSeq;
	}

	public void setSmsMstSeq(Integer smsMstSeq) {
		this.smsMstSeq = smsMstSeq;
	}
	
}
