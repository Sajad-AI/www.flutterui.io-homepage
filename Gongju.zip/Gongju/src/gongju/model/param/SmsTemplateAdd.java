package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsTemplateAdd {

	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "명칭", dataType = "String", required = true)
	String smsTemplateTitle;
	
	@ApiModelProperty(value = "문안", dataType = "String", required = true)
	String smsTemplate;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getSmsTemplateTitle() {
		return smsTemplateTitle;
	}

	public void setSmsTemplateTitle(String smsTemplateTitle) {
		this.smsTemplateTitle = smsTemplateTitle;
	}

	public String getSmsTemplate() {
		return smsTemplate;
	}

	public void setSmsTemplate(String smsTemplate) {
		this.smsTemplate = smsTemplate;
	}
	
}
