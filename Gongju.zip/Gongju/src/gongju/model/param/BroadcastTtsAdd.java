package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "방송 송출 > 음성생성")
public class BroadcastTtsAdd {

	@ApiModelProperty(value = "방송 송출 내용", dataType = "String", required = true)
	String broadcastContent;
	
	@ApiModelProperty(value = "시작 효과음 { 0:차임벨, 1:사이렌 }", dataType = "Integer", required = true, example = "0")
	Integer beginEffect;
	
	@ApiModelProperty(value = "종료 효과음 { 0:차임벨, 1:사이렌 }", dataType = "Integer", required = true, example = "0")
	Integer endEffect;
	
	public String getBroadcastContent() {
		return broadcastContent;
	}

	public void setBroadcastContent(String broadcastContent) {
		this.broadcastContent = broadcastContent;
	}

	public Integer getBeginEffect() {
		return beginEffect;
	}

	public void setBeginEffect(Integer beginEffect) {
		this.beginEffect = beginEffect;
	}

	public Integer getEndEffect() {
		return endEffect;
	}

	public void setEndEffect(Integer endEffect) {
		this.endEffect = endEffect;
	}
	
}
