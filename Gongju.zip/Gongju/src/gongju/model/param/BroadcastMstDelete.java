package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "방송 송출")
public class BroadcastMstDelete {

	@ApiModelProperty(value = "방송 송출 키", dataType = "Integer", required = true, example = "0")
	Integer broadcastMstSeq;

	public Integer getBroadcastMstSeq() {
		return broadcastMstSeq;
	}

	public void setBroadcastMstSeq(Integer broadcastMstSeq) {
		this.broadcastMstSeq = broadcastMstSeq;
	}
	
}
