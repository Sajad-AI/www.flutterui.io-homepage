package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "RTU")
public class RTUDeviceDelete {

	@ApiModelProperty(value = "RTU ID", dataType = "String", required = true)
	String rtuID;
	
	@ApiModelProperty(value = "지역키", dataType = "Integer", required = true, example = "0")
	Integer areaID;

	public String getRtuID() {
		return rtuID;
	}

	public void setRtuID(String rtuID) {
		this.rtuID = rtuID;
	}

	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

}
