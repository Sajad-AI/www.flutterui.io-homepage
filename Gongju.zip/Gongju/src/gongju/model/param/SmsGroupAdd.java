package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsGroupAdd {

	@ApiModelProperty(value = "그룹명", dataType = "String", required = true)
	String smsGroupName;
	
	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;

	public String getSmsGroupName() {
		return smsGroupName;
	}

	public void setSmsGroupName(String smsGroupName) {
		this.smsGroupName = smsGroupName;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}
	
}
