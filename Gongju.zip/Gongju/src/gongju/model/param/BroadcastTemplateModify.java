package gongju.model.param;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

public class BroadcastTemplateModify {

	@ApiModelProperty(value = "문안키", dataType = "Integer", required = true, example = "0")
	Integer broadcastTemplateSeq;
	
	@ApiModelProperty(value = "경보", dataType = "String", required = true)
	String broadcastTemplateTitle;
	
	@ApiModelProperty(value = "문안", dataType = "String", required = true)
	String broadcastTemplate;

	@JsonIgnore
	String updateDate;
	
	@JsonIgnore
	String deleteDate;

	public Integer getBroadcastTemplateSeq() {
		return broadcastTemplateSeq;
	}

	public void setBroadcastTemplateSeq(Integer broadcastTemplateSeq) {
		this.broadcastTemplateSeq = broadcastTemplateSeq;
	}

	public String getBroadcastTemplateTitle() {
		return broadcastTemplateTitle;
	}

	public void setBroadcastTemplateTitle(String broadcastTemplateTitle) {
		this.broadcastTemplateTitle = broadcastTemplateTitle;
	}

	public String getBroadcastTemplate() {
		return broadcastTemplate;
	}

	public void setBroadcastTemplate(String broadcastTemplate) {
		this.broadcastTemplate = broadcastTemplate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getDeleteDate() {
		return deleteDate;
	}

	public void setDeleteDate(String deleteDate) {
		this.deleteDate = deleteDate;
	}
	
}
