package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsGroupList {

	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}
	
}
