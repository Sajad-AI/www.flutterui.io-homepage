package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class VmsSendResultList {

	@ApiModelProperty(value = "페이지번호", dataType = "Integer", required = false, example = "1")
	Integer currentPage;
	
	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "검색조건 전송일자 시작 { yyyy-MM-dd }", dataType = "String", required = false)
	String beginSendDate;
	
	@ApiModelProperty(value = "검색조건 전송일자 종료 { yyyy-MM-dd }", dataType = "String", required = false)
	String endSendDate;
	
	@ApiModelProperty(value = "방송 제목", dataType = "String", required = false)
	String broadcastTitle;

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getBeginSendDate() {
		return beginSendDate;
	}

	public void setBeginSendDate(String beginSendDate) {
		this.beginSendDate = beginSendDate;
	}

	public String getEndSendDate() {
		return endSendDate;
	}

	public void setEndSendDate(String endSendDate) {
		this.endSendDate = endSendDate;
	}

	public String getBroadcastTitle() {
		return broadcastTitle;
	}

	public void setBroadcastTitle(String broadcastTitle) {
		this.broadcastTitle = broadcastTitle;
	}
	
}
