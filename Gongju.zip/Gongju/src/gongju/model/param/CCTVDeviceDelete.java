package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "CCTV")
public class CCTVDeviceDelete {

	@ApiModelProperty(value = "CCTV ID", dataType = "String", required = true)
	String cctvID;
	
	@ApiModelProperty(value = "지역키", dataType = "Integer", required = true, example = "0")
	Integer areaID;

	public String getCctvID() {
		return cctvID;
	}

	public void setCctvID(String cctvID) {
		this.cctvID = cctvID;
	}

	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

}
