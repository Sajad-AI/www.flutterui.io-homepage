package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class VmsSendReserveList {

	@ApiModelProperty(value = "페이지번호", dataType = "Integer", required = false, example = "1")
	Integer currentPage;
	
	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "검색조건 예약일자 시작 { yyyy-MM-dd }", dataType = "String", required = false)
	String beginReserveDate;
	
	@ApiModelProperty(value = "검색조건 예약일자 종료 { yyyy-MM-dd }", dataType = "String", required = false)
	String endReserveDate;
	
	@ApiModelProperty(value = "방송 제목", dataType = "String", required = false)
	String broadcastTitle;

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getBeginReserveDate() {
		return beginReserveDate;
	}

	public void setBeginReserveDate(String beginReserveDate) {
		this.beginReserveDate = beginReserveDate;
	}

	public String getEndReserveDate() {
		return endReserveDate;
	}

	public void setEndReserveDate(String endReserveDate) {
		this.endReserveDate = endReserveDate;
	}

	public String getBroadcastTitle() {
		return broadcastTitle;
	}

	public void setBroadcastTitle(String broadcastTitle) {
		this.broadcastTitle = broadcastTitle;
	}

}
