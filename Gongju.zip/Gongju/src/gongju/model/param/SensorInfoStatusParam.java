package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "센서")
public class SensorInfoStatusParam {

	@ApiModelProperty(value = "RTU ID", dataType = "String", required = true)
	String rtuID;
	
	@ApiModelProperty(value = "센서 ID", dataType = "String", required = true)
	String sensorID;
	
	@ApiModelProperty(value = "센서 타입 { 0:강우량계, 1:수위계, 2:변위계 }", dataType = "Integer", required = true, example = "0")
	Integer sensorType;

	@ApiModelProperty(value = "SENSOR type {11021:강우량계, 11031:수위계, 11071:변위계}", dataType = "String", required = false)
	String sensorTypeConvert;
	
	@ApiModelProperty(value = "SENSOR VALUE type", dataType = "String", required = false)
	String sensorValueTypeConvert;
	
	public String getSensorID() {
		return sensorID;
	}

	public void setSensorID(String sensorID) {
		this.sensorID = sensorID;
	}

	public Integer getSensorType() {
		return sensorType;
	}

	public void setSensorType(Integer sensorType) {
		this.sensorType = sensorType;
	}

	public String getRtuID() {
		return rtuID;
	}

	public void setRtuID(String rtuID) {
		this.rtuID = rtuID;
	}

	public String getSensorTypeConvert() {
		return sensorTypeConvert;
	}

	public void setSensorTypeConvert(String sensorTypeConvert) {
		this.sensorTypeConvert = sensorTypeConvert;
	}

	public String getSensorValueTypeConvert() {
		return sensorValueTypeConvert;
	}

	public void setSensorValueTypeConvert(String sensorValueTypeConvert) {
		this.sensorValueTypeConvert = sensorValueTypeConvert;
	}
	
}
