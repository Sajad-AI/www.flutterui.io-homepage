package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsGroupDelete {

	@ApiModelProperty(value = "그룹키", dataType = "Integer", required = true, example = "0")
	Integer smsGroupSeq;

	public Integer getSmsGroupSeq() {
		return smsGroupSeq;
	}

	public void setSmsGroupSeq(Integer smsGroupSeq) {
		this.smsGroupSeq = smsGroupSeq;
	}
	
}
