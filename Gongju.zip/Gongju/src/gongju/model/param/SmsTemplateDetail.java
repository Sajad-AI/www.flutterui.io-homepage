package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsTemplateDetail {

	@ApiModelProperty(value = "문안키", dataType = "Integer", required = true, example = "0")
	Integer smsTemplateSeq;

	public Integer getSmsTemplateSeq() {
		return smsTemplateSeq;
	}

	public void setSmsTemplateSeq(Integer smsTemplateSeq) {
		this.smsTemplateSeq = smsTemplateSeq;
	}
	
}
