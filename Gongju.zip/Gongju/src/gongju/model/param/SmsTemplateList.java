package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsTemplateList {

	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "페이지번호", dataType = "Integer", required = false, example = "1")
	Integer currentPage;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}
	
}
