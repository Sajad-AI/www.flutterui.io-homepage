package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsPhoneAdd {

	@ApiModelProperty(value = "그룹키", dataType = "Integer", required = true, example = "0")
	Integer smsGroupSeq;
	
	@ApiModelProperty(value = "성함", dataType = "String", required = true)
	String phoneName;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = true)
	String phoneNumber;

	public Integer getSmsGroupSeq() {
		return smsGroupSeq;
	}

	public void setSmsGroupSeq(Integer smsGroupSeq) {
		this.smsGroupSeq = smsGroupSeq;
	}

	public String getPhoneName() {
		return phoneName;
	}

	public void setPhoneName(String phoneName) {
		this.phoneName = phoneName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
}
