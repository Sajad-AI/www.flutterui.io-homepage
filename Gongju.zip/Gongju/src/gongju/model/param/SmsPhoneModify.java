package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsPhoneModify {

	@ApiModelProperty(value = "연락처키", dataType = "Integer", required = true, example = "0")
	Integer smsPhoneSeq;
	
	@ApiModelProperty(value = "성함", dataType = "String", required = true)
	String phoneName;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = true)
	String phoneNumber;

	public Integer getSmsPhoneSeq() {
		return smsPhoneSeq;
	}

	public void setSmsPhoneSeq(Integer smsPhoneSeq) {
		this.smsPhoneSeq = smsPhoneSeq;
	}

	public String getPhoneName() {
		return phoneName;
	}

	public void setPhoneName(String phoneName) {
		this.phoneName = phoneName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
}
