package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "지역")
public class AreaMstList {

	@ApiModelProperty(value = "페이지번호", dataType = "Integer", required = false, example = "1")
	Integer currentPage;
	
	public Integer getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(Integer currentPage) {
		this.currentPage = currentPage;
	}
	
}
