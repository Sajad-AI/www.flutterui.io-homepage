package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "지역")
public class AreaMstModify {

	@ApiModelProperty(value = "지역키", dataType = "Integer", required = true, example = "0")
	Integer areaID;
	
	@ApiModelProperty(value = "지역명", dataType = "String", required = true)
	String areaName;
	
	@ApiModelProperty(value = "경도", dataType = "Double", required = true, example = "127.48735537691726")
	Double areaLongitude;
	
	@ApiModelProperty(value = "위도", dataType = "Double", required = true, example = "37.19778368619912")
	Double areaLatitude;
	
	@ApiModelProperty(value = "메모", dataType = "String", required = false)
	String areaMemo;
	
	@ApiModelProperty(value = "수정일", dataType = "String", required = false)
	String updateDate;
	
	@ApiModelProperty(value = "삭제여부", dataType = "Boolean", required = false)
	Boolean isDeleteTarget;
	
	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public Double getAreaLongitude() {
		return areaLongitude;
	}

	public void setAreaLongitude(Double areaLongitude) {
		this.areaLongitude = areaLongitude;
	}

	public Double getAreaLatitude() {
		return areaLatitude;
	}

	public void setAreaLatitude(Double areaLatitude) {
		this.areaLatitude = areaLatitude;
	}

	public String getAreaMemo() {
		return areaMemo;
	}

	public void setAreaMemo(String areaMemo) {
		this.areaMemo = areaMemo;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public Boolean getIsDeleteTarget() {
		return isDeleteTarget;
	}

	public void setIsDeleteTarget(Boolean isDeleteTarget) {
		this.isDeleteTarget = isDeleteTarget;
	}
	
}
