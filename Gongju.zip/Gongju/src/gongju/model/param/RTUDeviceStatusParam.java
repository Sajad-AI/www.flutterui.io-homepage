package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "RTU")
public class RTUDeviceStatusParam {

	@ApiModelProperty(value = "RTU ID", dataType = "String", required = true)
	String rtuID;
	
	public String getRtuID() {
		return rtuID;
	}

	public void setRtuID(String rtuID) {
		this.rtuID = rtuID;
	}

}
