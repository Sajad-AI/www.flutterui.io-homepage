package gongju.model.param;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "사용자")
public class UserMstModify {

	@ApiModelProperty(value = "사용자 계정", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "사용자 명", dataType = "String", required = true)
	String userFullName;
	
	@ApiModelProperty(value = "기관명", dataType = "String", required = true)
	String organizationName;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = true)
	String phoneNum;
	
	@ApiModelProperty(value = "관리자", dataType = "boolean", required = true)
	boolean isAdminPerm;
	
	@ApiModelProperty(value = "SMS 전송 가능", dataType = "boolean", required = true)
	boolean isSMSPerm;
	
	@ApiModelProperty(value = "방송 송출 가능", dataType = "boolean", required = true)
	boolean isBroadcastPerm;
	
	@ApiModelProperty(value = "CCTV 뷰어", dataType = "boolean", required = true)
	boolean isCCTVViewPerm;
	
	@ApiModelProperty(value = "CCTV 콘트롤", dataType = "boolean", required = true)
	boolean isCCTVCtrlPerm;
	
	@ApiModelProperty(value = "수정 날짜", dataType = "String", required = true)
	String updateDate;
	
	@ApiModelProperty(value = "삭제 여부", dataType = "boolean", required = true)
	boolean isDelete;
	

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public boolean isAdminPerm() {
		return isAdminPerm;
	}

	public void setAdminPerm(boolean isAdminPerm) {
		this.isAdminPerm = isAdminPerm;
	}

	public boolean isSMSPerm() {
		return isSMSPerm;
	}

	public void setSMSPerm(boolean isSMSPerm) {
		this.isSMSPerm = isSMSPerm;
	}

	public boolean isBroadcastPerm() {
		return isBroadcastPerm;
	}

	public void setBroadcastPerm(boolean isBroadcastPerm) {
		this.isBroadcastPerm = isBroadcastPerm;
	}

	public boolean isCCTVViewPerm() {
		return isCCTVViewPerm;
	}

	public void setCCTVViewPerm(boolean isCCTVViewPerm) {
		this.isCCTVViewPerm = isCCTVViewPerm;
	}

	public boolean isCCTVCtrlPerm() {
		return isCCTVCtrlPerm;
	}

	public void setCCTVCtrlPerm(boolean isCCTVCtrlPerm) {
		this.isCCTVCtrlPerm = isCCTVCtrlPerm;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}
	
	public boolean isDelete() {
		return isDelete;
	}

	public void setDelete(boolean isDelete) {
		this.isDelete = isDelete;
	}
	
}
