package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class UserAdd {

	@ApiModelProperty(value = "사용자 ID", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "비밀번호", dataType = "String", required = true)
	String loginPassword;
	
	@ApiModelProperty(value = "이름", dataType = "String", required = true)
	String userFullName;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = true)
	String phoneNum;
	
	@ApiModelProperty(value = "기관", dataType = "String", required = true)
	String organizationName;
	
	@ApiModelProperty(value = "관리자: 모든 권한", dataType = "Boolean", required = false)
	Boolean isAdminPerm;
	
	@ApiModelProperty(value = "SMS 전송 가능", dataType = "Boolean", required = false)
	Boolean isSMSPerm;
	
	@ApiModelProperty(value = "방송 송출 가능", dataType = "Boolean", required = false)
	Boolean isBroadcastPerm;
	
	@ApiModelProperty(value = "CCTV 뷰어", dataType = "Boolean", required = false)
	Boolean isCCTVViewPerm;
	
	@ApiModelProperty(value = "CCTV 컨트롤", dataType = "Boolean", required = false)
	Boolean isCCTVCtrlPerm;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public Boolean getIsAdminPerm() {
		return isAdminPerm;
	}

	public void setIsAdminPerm(Boolean isAdminPerm) {
		this.isAdminPerm = isAdminPerm;
	}

	public Boolean getIsSMSPerm() {
		return isSMSPerm;
	}

	public void setIsSMSPerm(Boolean isSMSPerm) {
		this.isSMSPerm = isSMSPerm;
	}

	public Boolean getIsBroadcastPerm() {
		return isBroadcastPerm;
	}

	public void setIsBroadcastPerm(Boolean isBroadcastPerm) {
		this.isBroadcastPerm = isBroadcastPerm;
	}

	public Boolean getIsCCTVViewPerm() {
		return isCCTVViewPerm;
	}

	public void setIsCCTVViewPerm(Boolean isCCTVViewPerm) {
		this.isCCTVViewPerm = isCCTVViewPerm;
	}

	public Boolean getIsCCTVCtrlPerm() {
		return isCCTVCtrlPerm;
	}

	public void setIsCCTVCtrlPerm(Boolean isCCTVCtrlPerm) {
		this.isCCTVCtrlPerm = isCCTVCtrlPerm;
	}
	
}
