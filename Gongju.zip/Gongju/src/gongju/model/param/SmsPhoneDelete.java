package gongju.model.param;

import io.swagger.annotations.ApiModelProperty;

public class SmsPhoneDelete {

	@ApiModelProperty(value = "연락처키", dataType = "Integer", required = true, example = "0")
	Integer smsPhoneSeq;

	public Integer getSmsPhoneSeq() {
		return smsPhoneSeq;
	}

	public void setSmsPhoneSeq(Integer smsPhoneSeq) {
		this.smsPhoneSeq = smsPhoneSeq;
	}
	
}
