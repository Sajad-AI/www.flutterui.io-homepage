package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "SMS 그룹 > 연락처")
public class SmsPhone {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer smsPhoneSeq;
	
	@ApiModelProperty(value = "그룹키", dataType = "Integer", required = true, example = "0")
	Integer smsGroupSeq;
	
	@ApiModelProperty(value = "성함", dataType = "String", required = true)
	String phoneName;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = true)
	String phoneNumber;

	public Integer getSmsPhoneSeq() {
		return smsPhoneSeq;
	}

	public void setSmsPhoneSeq(Integer smsPhoneSeq) {
		this.smsPhoneSeq = smsPhoneSeq;
	}

	public Integer getSmsGroupSeq() {
		return smsGroupSeq;
	}

	public void setSmsGroupSeq(Integer smsGroupSeq) {
		this.smsGroupSeq = smsGroupSeq;
	}

	public String getPhoneName() {
		return phoneName;
	}

	public void setPhoneName(String phoneName) {
		this.phoneName = phoneName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
}
