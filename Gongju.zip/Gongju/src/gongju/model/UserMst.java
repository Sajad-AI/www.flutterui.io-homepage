package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "사용자")
public class UserMst {

	@ApiModelProperty(value = "사용자 계정", dataType = "String", required = true)
	String userID;
	
	@ApiModelProperty(value = "사용자 명", dataType = "String", required = true)
	String userFullName;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = false)
	String phoneNum;
	
	@ApiModelProperty(value = "기관 명", dataType = "String", required = false)
	String organizationName;
	
	@ApiModelProperty(value = "생성날짜", dataType = "String", required = false)
	String createDate;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}
	
	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
}
