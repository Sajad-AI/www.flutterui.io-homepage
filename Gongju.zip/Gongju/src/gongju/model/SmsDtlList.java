package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "SMS 발송 > 수신자 목록")
public class SmsDtlList {

	@ApiModelProperty(value = "이름", dataType = "String", required = false)
	String phoneName;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = false)
	String phoneNumber;

	@ApiModelProperty(value = "SMS결과", dataType = "String", required = false)
	String sendResult;

	public String getPhoneName() {
		return phoneName;
	}

	public void setPhoneName(String phoneName) {
		this.phoneName = phoneName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getSendResult() {
		return sendResult;
	}

	public void setSendResult(String sendResult) {
		this.sendResult = sendResult;
	}
	
}
