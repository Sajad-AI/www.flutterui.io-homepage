package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "방송 송출 > 전송")
public class BroadcastDtlList {

	@ApiModelProperty(value = "지역명", dataType = "String", required = true)
	String areaName;
	
	@ApiModelProperty(value = "방송장비 타입 { 0:비상예경보방송기기, 1:마을방송 }", dataType = "Integer", required = true, example = "0")
	Integer deviceType;
	
	@ApiModelProperty(value = "방송장비키 (장비 ID)", dataType = "Integer", required = false, example = "0")
	Integer broadcastDevID;
	
	@ApiModelProperty(value = "방송시작", dataType = "String", required = false)
	String beginBroadcastDate;
	
	@ApiModelProperty(value = "방송종료", dataType = "String", required = false)
	String endBroadcastDate;
	
	@ApiModelProperty(value = "방송결과", dataType = "String", required = false)
	String sendResult;

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public Integer getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(Integer deviceType) {
		this.deviceType = deviceType;
	}

	public Integer getBroadcastDevID() {
		return broadcastDevID;
	}

	public void setBroadcastDevID(Integer broadcastDevID) {
		this.broadcastDevID = broadcastDevID;
	}

	public String getBeginBroadcastDate() {
		return beginBroadcastDate;
	}

	public void setBeginBroadcastDate(String beginBroadcastDate) {
		this.beginBroadcastDate = beginBroadcastDate;
	}

	public String getEndBroadcastDate() {
		return endBroadcastDate;
	}

	public void setEndBroadcastDate(String endBroadcastDate) {
		this.endBroadcastDate = endBroadcastDate;
	}

	public String getSendResult() {
		return sendResult;
	}

	public void setSendResult(String sendResult) {
		this.sendResult = sendResult;
	}
	
}
