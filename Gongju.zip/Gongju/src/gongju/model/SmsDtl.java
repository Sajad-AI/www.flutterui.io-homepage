package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "SMS 발송 > 수신자 목록")
public class SmsDtl {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer smsDtlSeq;
	
	@ApiModelProperty(value = "SMS 발송키", dataType = "Integer", required = false, example = "0")
	Integer smsMstSeq;
	
	@ApiModelProperty(value = "성함", dataType = "String", required = true)
	String phoneName;
	
	@ApiModelProperty(value = "전화번호", dataType = "String", required = true)
	String phoneNumber;

	public Integer getSmsDtlSeq() {
		return smsDtlSeq;
	}

	public void setSmsDtlSeq(Integer smsDtlSeq) {
		this.smsDtlSeq = smsDtlSeq;
	}

	public Integer getSmsMstSeq() {
		return smsMstSeq;
	}

	public void setSmsMstSeq(Integer smsMstSeq) {
		this.smsMstSeq = smsMstSeq;
	}

	public String getPhoneName() {
		return phoneName;
	}

	public void setPhoneName(String phoneName) {
		this.phoneName = phoneName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
}
