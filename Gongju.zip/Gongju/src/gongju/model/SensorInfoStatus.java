package gongju.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "센서")
public class SensorInfoStatus {

	@ApiModelProperty(value = "RTU ID", dataType = "String", required = false)
	String rtuID;

	@ApiModelProperty(value = "센서 ID", dataType = "String", required = false)
	String sensorID;
	
	@ApiModelProperty(value = "센서 타입 { 0:강우량계, 1:수위계, 2:변위계 }", dataType = "Integer", required = false, example = "0")
	Integer sensorType;
	
	@ApiModelProperty(value = "센서 상태", dataType = "Boolean", required = false)
	Boolean sensorStatus;
	
	@ApiModelProperty(value = "센서 데이터", dataType = "sensorInfoValue", required = false)
	List<SensorInfoValue> sensorInfoValue;
	
	public String getSensorID() {
		return sensorID;
	}

	public void setSensorID(String sensorID) {
		this.sensorID = sensorID;
	}

	public Integer getSensorType() {
		return sensorType;
	}

	public void setSensorType(Integer sensorType) {
		this.sensorType = sensorType;
	}

	public String getRtuID() {
		return rtuID;
	}

	public void setRtuID(String rtuID) {
		this.rtuID = rtuID;
	}

	public Boolean getSensorStatus() {
		return sensorStatus;
	}

	public void setSensorStatus(Boolean sensorStatus) {
		this.sensorStatus = sensorStatus;
	}

	public List<SensorInfoValue> getSensorInfoValue() {
		return sensorInfoValue;
	}

	public void setSensorInfoValue(List<SensorInfoValue> sensorInfoValue) {
		this.sensorInfoValue = sensorInfoValue;
	}
	
}
