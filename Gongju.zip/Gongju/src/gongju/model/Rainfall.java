package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "공주시 일강우 현황")
public class Rainfall {

	@ApiModelProperty(value = "읍면동", dataType = "String", required = false)
	String town;
	
	@ApiModelProperty(value = "1시간 강우량", dataType = "Integer", required = false, example = "0")
	Integer rainfall;

	public String getTown() {
		return town;
	}

	public void setTown(String town) {
		this.town = town;
	}

	public Integer getRainfall() {
		return rainfall;
	}

	public void setRainfall(Integer rainfall) {
		this.rainfall = rainfall;
	}
	
}
