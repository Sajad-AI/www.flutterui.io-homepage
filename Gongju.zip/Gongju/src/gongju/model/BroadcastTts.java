package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "방송 송출 > 음성생성")
public class BroadcastTts {

	@ApiModelProperty(value = "음성 생성 결과", dataType = "String", required = true)
	String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	
}
