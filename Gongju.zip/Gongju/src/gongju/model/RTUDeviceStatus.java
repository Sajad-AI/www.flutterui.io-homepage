package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "RTU")
public class RTUDeviceStatus {

	@ApiModelProperty(value = "RTU ID", dataType = "String", required = false)
	String rtuID;
	
	@ApiModelProperty(value = "RTU 전체 상태", dataType = "Boolean", required = false)
	Boolean rtuStatus;
	
	@ApiModelProperty(value = "WatchDog 상태", dataType = "Boolean", required = false)
	Boolean watchdogStatus;
	
	@ApiModelProperty(value = "CDMA Modem 상태", dataType = "Boolean", required = false)
	Boolean cdmaModemStatus;
	
	@ApiModelProperty(value = "AC 상태", dataType = "Boolean", required = false)
	Boolean acStatus;
	
	@ApiModelProperty(value = "Battery 상태", dataType = "Boolean", required = false)
	Boolean batteryStatus;
	
	@ApiModelProperty(value = "Door Open 상태", dataType = "Boolean", required = false)
	Boolean doorOpenStatus;
	
	@ApiModelProperty(value = "Battery Voltage 상태", dataType = "String", required = false)
	String batteryVoltage;
	
	@ApiModelProperty(value = "수신일자", dataType = "String", required = false)
	String receiveDate;
	
	public String getRtuID() {
		return rtuID;
	}

	public void setRtuID(String rtuID) {
		this.rtuID = rtuID;
	}

	public Boolean getRtuStatus() {
		return rtuStatus;
	}

	public void setRtuStatus(Boolean rtuStatus) {
		this.rtuStatus = rtuStatus;
	}

	public Boolean getWatchdogStatus() {
		return watchdogStatus;
	}

	public void setWatchdogStatus(Boolean watchdogStatus) {
		this.watchdogStatus = watchdogStatus;
	}

	public Boolean getCdmaModemStatus() {
		return cdmaModemStatus;
	}

	public void setCdmaModemStatus(Boolean cdmaModemStatus) {
		this.cdmaModemStatus = cdmaModemStatus;
	}

	public Boolean getAcStatus() {
		return acStatus;
	}

	public void setAcStatus(Boolean acStatus) {
		this.acStatus = acStatus;
	}

	public Boolean getBatteryStatus() {
		return batteryStatus;
	}

	public void setBatteryStatus(Boolean batteryStatus) {
		this.batteryStatus = batteryStatus;
	}

	public Boolean getDoorOpenStatus() {
		return doorOpenStatus;
	}

	public void setDoorOpenStatus(Boolean doorOpenStatus) {
		this.doorOpenStatus = doorOpenStatus;
	}

	public String getReceiveDate() {
		return receiveDate;
	}

	public void setReceiveDate(String receiveDate) {
		this.receiveDate = receiveDate;
	}

	public String getBatteryVoltage() {
		return batteryVoltage;
	}

	public void setBatteryVoltage(String batteryVoltage) {
		this.batteryVoltage = batteryVoltage;
	}

}
