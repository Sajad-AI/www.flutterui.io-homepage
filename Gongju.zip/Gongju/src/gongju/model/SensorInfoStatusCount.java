package gongju.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "통신상태 현황")
public class SensorInfoStatusCount {

	@ApiModelProperty(value = "정상", dataType = "Integer", required = true, example = "0")
	Integer statusOk;
	
	@ApiModelProperty(value = "불량", dataType = "Integer", required = true, example = "0")
	Integer statusErr;

	public Integer getStatusOk() {
		return statusOk;
	}

	public void setStatusOk(Integer statusOk) {
		this.statusOk = statusOk;
	}

	public Integer getStatusErr() {
		return statusErr;
	}

	public void setStatusErr(Integer statusErr) {
		this.statusErr = statusErr;
	}
	
}
