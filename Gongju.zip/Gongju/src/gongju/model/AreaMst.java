package gongju.model;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description = "지역")
public class AreaMst {

	@ApiModelProperty(value = "PK, 자동 증가값", dataType = "Integer", required = false, example = "0")
	Integer areaID;
	
	@ApiModelProperty(value = "지역명", dataType = "String", required = true)
	String areaName;
	
	@ApiModelProperty(value = "경도", dataType = "Double", required = true, example = "127.48735537691726")
	Double areaLongitude;
	
	@ApiModelProperty(value = "위도", dataType = "Double", required = true, example = "37.19778368619912")
	Double areaLatitude;

	@ApiModelProperty(value = "주소1", dataType = "String", required = false)
	String addr1;

	@ApiModelProperty(value = "주소2", dataType = "String", required = false)
	String addr2;

	@ApiModelProperty(value = "상세주소", dataType = "String", required = false)
	String addr3;
	
	@ApiModelProperty(value = "메모", dataType = "String", required = false)
	String areaMemo;
	
	@ApiModelProperty(value = "생성일", dataType = "String", required = false)
	String createDate;
	
	@ApiModelProperty(value = "수정일", dataType = "String", required = false)
	String updateDate;

	@ApiModelProperty(value = "NDMS 연계 여부", dataType = "boolean", required = false)
	boolean isNDMS;
	
	@ApiModelProperty(value = "NDMS 연계 상태", dataType = "int", required = false)
	int ndmsStatus;
	
	@ApiModelProperty(value = "CCTV 목록", dataType = "CCTVDevice", required = false)
	List<CCTVDevice> cctvDevice;
	
	@ApiModelProperty(value = "방송장비 (비상예경보방송기기 / 마을방송) 목록", dataType = "BroadcastDevice", required = false)
	List<BroadcastDevice> broadcastDevice;
	
	@ApiModelProperty(value = "RTU 목록", dataType = "RTU", required = false)
	List<RTUDevice> rtuDevice;

	@ApiModelProperty(value = "센서 목록", dataType = "SensorInfo", required = false)
	List<SensorInfo> sensorInfo;
	
	public Integer getAreaID() {
		return areaID;
	}

	public void setAreaID(Integer areaID) {
		this.areaID = areaID;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public Double getAreaLongitude() {
		return areaLongitude;
	}

	public void setAreaLongitude(Double areaLongitude) {
		this.areaLongitude = areaLongitude;
	}

	public Double getAreaLatitude() {
		return areaLatitude;
	}

	public void setAreaLatitude(Double areaLatitude) {
		this.areaLatitude = areaLatitude;
	}

	public String getAreaMemo() {
		return areaMemo;
	}

	public void setAreaMemo(String areaMemo) {
		this.areaMemo = areaMemo;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public List<CCTVDevice> getCctvDevice() {
		return cctvDevice;
	}

	public void setCctvDevice(List<CCTVDevice> cctvDevice) {
		this.cctvDevice = cctvDevice;
	}

	public List<BroadcastDevice> getBroadcastDevice() {
		return broadcastDevice;
	}

	public void setBroadcastDevice(List<BroadcastDevice> broadcastDevice) {
		this.broadcastDevice = broadcastDevice;
	}

	public List<RTUDevice> getRtuDevice() {
		return rtuDevice;
	}

	public void setRtuDevice(List<RTUDevice> rtuDevice) {
		this.rtuDevice = rtuDevice;
	}

	public List<SensorInfo> getSensorInfo() {
		return sensorInfo;
	}

	public void setSensorInfo(List<SensorInfo> sensorInfo) {
		this.sensorInfo = sensorInfo;
	}

	public String getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1 = addr1;
	}

	public String getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2 = addr2;
	}

	public String getAddr3() {
		return addr3;
	}

	public void setAddr3(String addr3) {
		this.addr3 = addr3;
	}

	public boolean isNDMS() {
		return isNDMS;
	}

	public void setNDMS(boolean isNDMS) {
		this.isNDMS = isNDMS;
	}

	public int getNdmsStatus() {
		return ndmsStatus;
	}

	public void setNdmsStatus(int ndmsStatus) {
		this.ndmsStatus = ndmsStatus;
	}
	
}
