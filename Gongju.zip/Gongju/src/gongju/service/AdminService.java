package gongju.service;

public interface AdminService {
	
}
