package gongju.service;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.BroadcastMst;
import gongju.model.BroadcastMstList;
import gongju.model.BroadcastTemplate;
import gongju.model.BroadcastTts;
import gongju.model.PaginationList;
import gongju.model.ResponseObject;
import gongju.model.param.BroadcastTemplateDelete;
import gongju.model.param.BroadcastTemplateDetail;
import gongju.model.param.BroadcastTemplateList;
import gongju.model.param.BroadcastTemplateModify;
import gongju.model.param.BroadcastTtsAdd;

public interface BroadcastService {
	
	/**
	 * 방송 문안 등록
	 * 
	 * @param broadcastTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> broadcastTemplateAdd(BroadcastTemplate broadcastTemplate) throws SqlSessionException;
	
	/**
	 * 방송 문안 수정
	 * 
	 * @param broadcastTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> broadcastTemplateModify(BroadcastTemplateModify broadcastTemplate) throws SqlSessionException;
	
	/**
	 * 방송 문안 삭제
	 * 
	 * @param broadcastTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> broadcastTemplateDelete(BroadcastTemplateDelete broadcastTemplate) throws SqlSessionException;
	
	/**
	 * 방송 문안 목록
	 * 
	 * @param broadcastTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<PaginationList<BroadcastTemplate>> broadcastTemplateList(BroadcastTemplateList broadcastTemplate) throws SqlSessionException;

	/**
	 * 방송 문안 상세
	 * 
	 * @param broadcastTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<BroadcastTemplate> broadcastTemplateDetail(BroadcastTemplateDetail broadcastTemplate) throws SqlSessionException;
	
	
	
	/**
	 * 방송 송출 > 음성생성
	 * 
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<BroadcastTts> broadcastTts(BroadcastTtsAdd broadcastTts) throws SqlSessionException;
	
	/**
	 * 방송 송출 등록
	 * 
	 * @param broadcastMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> broadcastMstAdd(BroadcastMst broadcastMst) throws SqlSessionException;
	
	/**
	 * 방송 송출 수정
	 * 
	 * @param broadcastMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> broadcastMstModify(BroadcastMst broadcastMst) throws SqlSessionException;
	
	/**
	 * 방송 송출 삭제
	 * 
	 * @param broadcastMstSeq
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> broadcastMstDelete(Integer broadcastMstSeq) throws SqlSessionException;
	
	/**
	 * 방송 송출 내역
	 * 
	 * @param userID
	 * @param beginSendDate
	 * @param endSendDate
	 * @param broadcastTitle
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<PaginationList<BroadcastMstList>> vmsSendResultList(Integer currentPage, String userID, String beginSendDate, String endSendDate, String broadcastTitle) throws SqlSessionException;
	
	/**
	 * 방송 송출 내역
	 * 
	 * @param userID
	 * @param beginReserveDate
	 * @param endReserveDate
	 * @param broadcastTitle
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<PaginationList<BroadcastMstList>> vmsSendReserveList(Integer currentPage, String userID, String beginReserveDate, String endReserveDate, String broadcastTitle) throws SqlSessionException;
	
}
