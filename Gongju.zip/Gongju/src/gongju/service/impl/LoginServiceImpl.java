package gongju.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gongju.core.jwt.JwtUtil;
import gongju.dao.LoginDao;
import gongju.model.ResponseObject;
import gongju.model.User;
import gongju.service.LoginService;

@Service("loginService")
public class LoginServiceImpl implements LoginService {

	@Autowired
	private LoginDao loginDao;
	
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;
	
	@Override
	public ResponseObject<Map<String, Object>> loginUser(String userID, String loginPassword) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(null);
			
			User user = new User();
			user.setUserID(userID);
			user.setIsVerifiedByAdmin(true);
			
			user = getUser(user);
			
			if(user == null) {
				res.setCode(HttpStatus.NO_CONTENT.value());
				res.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			} else if(!bcryptEncoder.matches(loginPassword, getPassword(userID))) {
				res.setCode(HttpStatus.NOT_ACCEPTABLE.value());
				res.setMessage(HttpStatus.NOT_ACCEPTABLE.getReasonPhrase());
			} else if(!user.getIsVerifiedByAdmin()) {
				res.setCode(HttpStatus.LOCKED.value());
				res.setMessage(HttpStatus.LOCKED.getReasonPhrase());
			} else {
				String token = JwtUtil.generateToken(user);
				if(token == null) {
					res.setCode(HttpStatus.NON_AUTHORITATIVE_INFORMATION.value());
					res.setMessage(HttpStatus.NON_AUTHORITATIVE_INFORMATION.getReasonPhrase());
				} else {
					res.setCode(HttpStatus.OK.value());
					res.setMessage(HttpStatus.OK.getReasonPhrase());
					
					Map<String, Object> data = new HashMap<>();
					data.put("token", token);
					data.put("userFullName", user.getUserFullName());
					data.put("userID", user.getUserID());
					data.put("isAdminPerm", user.getIsAdminPerm());
					data.put("isSMSPerm", user.getIsSMSPerm());
			        data.put("isBroadcastPerm", user.getIsBroadcastPerm());
			        data.put("isCCTVViewPerm", user.getIsCCTVViewPerm());
			        data.put("isCCTVCtrlPerm", user.getIsCCTVCtrlPerm());
					
					res.setData(data);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> insertUser(String userID, String loginPassword, String userFullName, String phoneNum, String organizationName, 
											Boolean isAdminPerm, Boolean isSMSPerm, Boolean isBroadcastPerm, Boolean isCCTVViewPerm, Boolean isCCTVCtrlPerm) throws SqlSessionException {
		ResponseObject<?> res = new ResponseObject<>();
		
		try {
			User user = new User();
			user.setUserID(userID);
			
			if(getUser(user) != null) {
				res.setCode(HttpStatus.FAILED_DEPENDENCY.value());
				res.setMessage(HttpStatus.FAILED_DEPENDENCY.getReasonPhrase());
			} else {
				user.setPassword(bcryptEncoder.encode(loginPassword));
				user.setUserFullName(userFullName);
				user.setPhoneNum(phoneNum);
				user.setOrganizationName(organizationName);
				user.setIsAdminPerm(isAdminPerm);
				user.setIsSMSPerm(isSMSPerm);
				user.setIsBroadcastPerm(isBroadcastPerm);
				user.setIsCCTVViewPerm(isCCTVViewPerm);
				user.setIsCCTVCtrlPerm(isCCTVCtrlPerm);
				
				if(loginDao.insertUser(user) > 0) {
					res.setCode(HttpStatus.OK.value());
					res.setMessage(HttpStatus.OK.getReasonPhrase());
				} else {
					res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> verifyUser(String userID) throws SqlSessionException {
		ResponseObject<?> res = new ResponseObject<>();
		
		try {
			User user = new User();
			user.setUserID(userID);
			
			if(getUser(user) == null) {
				res.setCode(HttpStatus.NO_CONTENT.value());
				res.setMessage(HttpStatus.NO_CONTENT.getReasonPhrase());
			} else {
				user.setIsVerifiedByAdmin(true);
				
				if(loginDao.updateUser(user) > 0) {
					res.setCode(HttpStatus.OK.value());
					res.setMessage(HttpStatus.OK.getReasonPhrase());
				} else {
					res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public int updateUser(User user) throws SqlSessionException {
		if(user.getPassword() != null && user.getPassword().length() > 0)
			user.setPassword(bcryptEncoder.encode(user.getPassword()));
		
		return loginDao.updateUser(user);
	}

	@Override
	public String getPassword(String userID) throws SqlSessionException {
		return loginDao.getPassword(userID);
	}

	@Override
	public User getUser(User user) throws SqlSessionException {
		return loginDao.getUser(user);
	}

}
