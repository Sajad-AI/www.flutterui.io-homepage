package gongju.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gongju.dao.UserDao;
import gongju.model.PaginationList;
import gongju.model.ResponseObject;
import gongju.model.UserMst;
import gongju.model.param.UserMstDelete;
import gongju.model.param.UserMstList;
import gongju.model.param.UserMstModify;
import gongju.service.PaginationService;
import gongju.service.UserService;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDao userDao;
	
	@Autowired
	private PaginationService paginationService;
	
	@SuppressWarnings("unchecked")
	@Override
	public ResponseObject<PaginationList<UserMst>> userList(UserMstList userMst) throws SqlSessionException {
		ResponseObject<PaginationList<UserMst>> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			if(userMst.getCurrentPage() != null)
				params.put("currentPage", userMst.getCurrentPage());
			
			params.put("userFullName", userMst.getUserFullName());
			
			PaginationList<UserMst> sql = (PaginationList<UserMst>) paginationService.paginationSearch("gongju.dao.UserDao.userMstList", params);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(sql);
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> userMstModify(UserMstModify userMst) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			userMst.setUpdateDate(dtf.format(LocalDateTime.now()));
			
			if(userDao.userMstModify(userMst) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}


	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> userMstDelete(UserMstDelete userMst) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			UserMstModify userMstModify = new UserMstModify();
			userMstModify.setUserID(userMst.getUserID());
			userMstModify.setDelete(true);
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			userMstModify.setUpdateDate(dtf.format(LocalDateTime.now()));
			
			if(userDao.userMstDelete(userMstModify) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}


}
