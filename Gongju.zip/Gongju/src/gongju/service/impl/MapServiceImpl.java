package gongju.service.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.ibatis.session.SqlSessionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;

import gongju.dao.AreaDao;
import gongju.dao.MapDao;
import gongju.model.AreaMst;
import gongju.model.AreaSensor;
import gongju.model.BroadcastMstList;
import gongju.model.PaginationList;
import gongju.model.Rainfall;
import gongju.model.ReservoirRate;
import gongju.model.ResponseObject;
import gongju.model.SensorInfoStatusCount;
import gongju.model.SensorInfoValue;
import gongju.model.param.AreaMstDetail;
import gongju.service.MapService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Service("mapService")
public class MapServiceImpl implements MapService {

	@Autowired
	private MapDao mapDao;

	@Autowired
	private AreaDao areaDao;
	
	@Override
	public ResponseObject<AreaSensor> sensorValue(AreaMstDetail areaMst) throws SqlSessionException {
		ResponseObject<AreaSensor> res = new ResponseObject<>();
		
		try {
			AreaSensor data = new AreaSensor();
			
			Map<String, Object> params = new HashMap<>();
			params.put("areaID", areaMst.getAreaID());
			
			List<AreaMst> aml = areaDao.areaMstList(params);
			if(CollectionUtils.isNotEmpty(aml)) {
				AreaMst am = aml.get(0);
				data.setAreaID(am.getAreaID());
				data.setAreaName(am.getAreaName());
			}
			
			List<SensorInfoValue> sensorInfoValue = new ArrayList<>();
			List<SensorInfoValue> tmp = null;
			
			// 강우량계
			// 31023(강우량/금일)
			// 0
			params.put("valueType", 31023);
			params.put("sensorType", 0);
			tmp = mapDao.sensorInfoValueList(params);
			if(CollectionUtils.isNotEmpty(tmp)) {
				sensorInfoValue.addAll(tmp);
			}
			
			// 수위계
			// 31031(수위계)
			// 1
			params.put("valueType", 31031);
			params.put("sensorType", 1);
			tmp = mapDao.sensorInfoValueList(params);
			if(CollectionUtils.isNotEmpty(tmp)) {
				sensorInfoValue.addAll(tmp);
			}
			
			// 변위계
			// 31071(변위계)
			// 2
			params.put("valueType", 31071);
			params.put("sensorType", 2);
			tmp = mapDao.sensorInfoValueList(params);
			if(CollectionUtils.isNotEmpty(tmp)) {
				sensorInfoValue.addAll(tmp);
			}
			
			res.setData(data);
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	@Override
	public ResponseObject<List<ReservoirRate>> reservoirRate() throws SqlSessionException {
		ResponseObject<List<ReservoirRate>> res = new ResponseObject<>();
		
		// 현재의 센서값 가져올 것
		// 어제의 센서 평균값 가져올 것
		
		try {
			List<ReservoirRate> data = new ArrayList<>();
			Map<String, Object> params = new HashMap<>();
			List<SensorInfoValue> sensorInfoValue = new ArrayList<>();
			
			List<AreaMst> areaMstList = areaDao.areaMstList(null);
			for(AreaMst areaMst : areaMstList) {
				ReservoirRate rr = new ReservoirRate();
				rr.setAreaName(areaMst.getAreaName());
				
				// 수위계
				// 31031(수위계)
				// 1
				params.put("areaID", areaMst.getAreaID());
				params.put("valueType", 31031);
				params.put("sensorType", 1);
				
				// 오늘
				sensorInfoValue = mapDao.sensorInfoValueList(params);
				double todayValue = 0;
				double todayRate = 0;
				if(CollectionUtils.isNotEmpty(sensorInfoValue)) {
					SensorInfoValue siv = sensorInfoValue.get(0);
					todayValue = Double.parseDouble(siv.getDataValue());
				}
				
				// 전일
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
				params.put("yesterday", dtf.format(LocalDateTime.now()));
				
				sensorInfoValue = mapDao.sensorInfoValueYesterdayList(params);
				double yesterdayValue = 0;
				double yesterdayRate = 0;
				if(CollectionUtils.isNotEmpty(sensorInfoValue)) {
					SensorInfoValue siv = sensorInfoValue.get(0);
					yesterdayValue = Double.parseDouble(siv.getDataValue());
				}
				
				if("산소골저수지".equals(areaMst.getAreaName()) || "산소골 저수지".equals(areaMst.getAreaName())) {
					todayRate = getData("산소골저수지", todayValue);
					rr.setTodayRate(todayRate);
					
					yesterdayRate = getData("산소골저수지", yesterdayValue);
					rr.setYesterdayRate(yesterdayRate);
					
					rr.setDiffRate(todayRate - yesterdayRate);
				} else if("등대골저수지".equals(areaMst.getAreaName()) || "등대골 저수지".equals(areaMst.getAreaName())) {
					todayRate = getData("등대골저수지", todayValue);
					rr.setTodayRate(todayRate);
					
					yesterdayRate = getData("등대골저수지", yesterdayValue);
					rr.setYesterdayRate(yesterdayRate);
					
					rr.setDiffRate(todayRate - yesterdayRate);
				}
				
				data.add(rr);
			}
			
			res.setData(data);
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	private double getData(String areaName, double value) {
		double rate = 0;
		if("산소골저수지".equals(areaName)) {
			if(value == 63.8) {
				rate = 0.12;
			} else if(value > 63.8 && value < 64) {
				rate = (0.12 + 0.56) / 2;
			} else if(value == 64) {
				rate = 0.56;
			} else if(value > 64 && value < 64.2) {
				rate = (0.56 + 1.62) / 2;
			} else if(value == 64.2) {
				rate = 1.62;
			} else if(value > 64.2 && value < 64.4) {
				rate = (1.62 + 3.41) / 2;
			} else if(value == 64.4) {
				rate = 3.41;
			} else if(value > 64.4 && value < 64.6) {
				rate = (3.41 + 5.89) / 2;
			} else if(value == 64.6) {
				rate = 5.89;
			} else if(value > 64.6 && value < 64.8) {
				rate = (5.89 + 8.93) / 2;
			} else if(value == 64.8) {
				rate = 8.93;
			} else if(value > 64.8 && value < 65) {
				rate = (8.93 + 12.39) / 2;
			} else if(value == 65) {
				rate = 12.39;
			} else if(value > 65 && value < 65.2) {
				rate = (12.39 + 16.19) / 2;
			} else if(value == 65.2) {
				rate = 16.19;
			} else if(value > 65.2 && value < 65.4) {
				rate = (16.19 + 20.34) / 2;
			} else if(value == 65.4) {
				rate = 20.34;
			} else if(value > 65.4 && value < 65.6) {
				rate = (20.34 + 24.8) / 2;
			} else if(value == 65.6) {
				rate = 24.8;
			} else if(value > 65.6 && value < 65.8) {
				rate = (24.8 + 29.53) / 2;
			} else if(value == 65.8) {
				rate = 29.53;
			} else if(value > 65.8 && value < 66) {
				rate = (29.53 + 34.52) / 2;
			} else if(value == 66) {
				rate = 34.52;
			} else if(value > 66 && value < 66.2) {
				rate = (34.52 + 39.71) / 2;
			} else if(value == 66.2) {
				rate = 39.71;
			} else if(value > 66.2 && value < 66.4) {
				rate = (39.71 + 45.09) / 2;
			} else if(value == 66.4) {
				rate = 45.09;
			} else if(value > 66.4 && value < 66.6) {
				rate = (45.09 + 50.64) / 2;
			} else if(value == 66.6) {
				rate = 50.64;
			} else if(value > 66.6 && value < 66.8) {
				rate = (50.64 + 56.34) / 2;
			} else if(value == 66.8) {
				rate = 56.34;
			} else if(value > 66.8 && value < 67) {
				rate = (56.34 + 62.19) / 2;
			} else if(value == 67) {
				rate = 62.19;
			} else if(value > 67 && value < 67.2) {
				rate = (62.19 + 68.15) / 2;
			} else if(value == 67.2) {
				rate = 68.15;
			} else if(value > 67.2 && value < 67.4) {
				rate = (68.15 + 74.25) / 2;
			} else if(value == 67.4) {
				rate = 74.25;
			} else if(value > 67.4 && value < 67.6) {
				rate = (74.25 + 80.47) / 2;
			} else if(value == 67.6) {
				rate = 80.47;
			} else if(value > 67.6 && value < 67.8) {
				rate = (80.47 + 86.82) / 2;
			} else if(value == 67.8) {
				rate = 86.82;
			} else if(value > 67.8 && value < 68) {
				rate = (86.82 + 93.32) / 2;
			} else if(value == 68) {
				rate = 93.32;
			} else if(value > 68 && value < 68.2) {
				rate = (93.32 + 100) / 2;
			} else if(value == 68.2) {
				rate = 100;
			} else if(value > 68.2 && value < 68.4) {
				rate = (100 + 114.57) / 2;
			} else if(value == 68.4) {
				rate = 114.57;
			} else if(value > 68.4 && value < 68.6) {
				rate = (114.57 + 122.19) / 2;
			} else if(value == 68.6) {
				rate = 122.19;
			} else if(value > 68.6 && value < 68.8) {
				rate = (122.19 + 130.03) / 2;
			} else if(value == 68.8) {
				rate = 130.03;
			} else if(value > 68.8 && value < 69) {
				rate = (130.03 + 138.08) / 2;
			} else if(value == 69) {
				rate = 138.08;
			} else if(value > 69 && value < 69.2) {
				rate = (138.08 + 146.35) / 2;
			} else if(value == 69.2) {
				rate = 146.35;
			} else if(value > 69.2 && value < 69.4) {
				rate = (146.35 + 154.83) / 2;
			} else if(value == 69.4) {
				rate = 154.83;
			} else if(value > 69.4 && value < 69.6) {
				rate = (154.83 + 163.53) / 2;
			} else if(value == 69.6) {
				rate = 163.53;
			} else if(value > 69.6 && value < 69.8) {
				rate = (163.53 + 172.45) / 2;
			} else if(value == 69.8) {
				rate = 172.45;
			} else if(value > 69.8 && value < 70) {
				rate = (172.45 + 181.58) / 2;
			} else if(value == 70) {
				rate = 181.58;
			} else if(value > 70 && value < 70.2) {
				rate = (181.58 + 130.53) / 2;
			} else if(value == 70.2) {
				rate = 130.53;
			} else if(value > 70.2 && value < 70.4) {
				rate = (130.53 + 137.34) / 2;
			} else if(value == 70.4) {
				rate = 137.34;
			} else if(value > 70.4 && value < 70.6) {
				rate = (137.34 + 144.65) / 2;
			} else if(value == 70.6) {
				rate = 144.65;
			} else if(value > 70.6 && value < 70.8) {
				rate = (144.65 + 152.71) / 2;
			} else if(value == 70.8) {
				rate = 152.71;
			}
		} else if("등대골저수지".equals(areaName)) {
			if(value == 115.2) {
		 		rate = 0.03;
			} else if(value > 115.2 && value < 115.4) {
				rate = (0.03 + 0.19) / 2;
			} else if(value == 115.4) {
				rate = 0.19;
			} else if(value > 115.4 && value < 115.6) {
				rate = (0.19 + 0.48) / 2;
			} else if(value == 115.6) {
				rate = 0.48;
			} else if(value > 115.6 && value < 115.8) {
				rate = (0.48 + 0.9) / 2;
			} else if(value == 115.8) {
				rate = 0.9;
			} else if(value > 115.8 && value < 116) {
				rate = (0.9 + 1.42) / 2;
			} else if(value == 116) {
				rate = 1.42;
			} else if(value > 116 && value < 116.2) {
				rate = (1.42 + 2.03) / 2;
			} else if(value == 116.2) {
				rate = 2.03;
			} else if(value > 116.2 && value < 116.4) {
				rate = (2.03 + 2.74) / 2;
			} else if(value == 116.4) {
				rate = 2.74;
			} else if(value > 116.4 && value < 116.6) {
				rate = (2.74 + 3.55) / 2;
			} else if(value == 116.6) {
				rate = 3.55;
			} else if(value > 116.6 && value < 116.8) {
				rate = (3.55 + 4.45) / 2;
			} else if(value == 116.8) {
				rate = 4.45;
			} else if(value > 116.8 && value < 117) {
				rate = (4.45 + 5.45) / 2;
			} else if(value == 117) {
				rate = 5.45;
			} else if(value > 117 && value < 117.2) {
				rate = (5.45 + 6.58) / 2;
			} else if(value == 117.2) {
				rate = 6.58;
			} else if(value > 117.2 && value < 117.4) {
				rate = (6.58 + 7.84) / 2;
			} else if(value == 117.4) {
				rate = 7.84;
			} else if(value > 117.4 && value < 117.6) {
				rate = (7.84 + 9.23) / 2;
			} else if(value == 117.6) {
				rate = 9.23;
			} else if(value > 117.6 && value < 117.8) {
				rate = (9.23 + 10.81) / 2;
			} else if(value == 117.8) {
				rate = 10.81;
			} else if(value > 117.8 && value < 118) {
				rate = (10.81 + 12.61) / 2;
			} else if(value == 118) {
				rate = 12.61;
			} else if(value > 118 && value < 118.2) {
				rate = (12.61 + 14.58) / 2;
			} else if(value == 118.2) {
				rate = 14.58;
			} else if(value > 118.2 && value < 118.4) {
				rate = (14.58 + 16.71) / 2;
			} else if(value == 118.4) {
				rate = 16.71;
			} else if(value > 118.4 && value < 118.6) {
				rate = (16.71 + 18.97) / 2;
			} else if(value == 118.6) {
				rate = 18.97;
			} else if(value > 118.6 && value < 118.8) {
				rate = (18.97 + 21.32) / 2;
			} else if(value == 118.8) {
				rate = 21.32;
			} else if(value > 118.8 && value < 119) {
				rate = (21.32 + 23.77);
			} else if(value == 119) {
				rate = 23.77;
			} else if(value > 119 && value < 119.2) {
				rate = (23.77 + 26.32) / 2;
			} else if(value == 119.2) {
				rate = 26.32;
			} else if(value > 119.2 && value < 119.4) {
				rate = (26.32 + 28.94) / 2;
			} else if(value == 119.4) {
				rate = 28.94;
			} else if(value > 119.4 && value < 119.6) {
				rate = (28.94 + 31.65) / 2;
			} else if(value == 119.6) {
				rate = 31.65;
			} else if(value > 119.6 && value < 119.8) {
				rate = (31.65 + 34.45) / 2;
			} else if(value == 119.8) {
				rate = 34.45;
			} else if(value > 119.8 && value < 120) {
				rate = (34.45 + 37.32) / 2;
			} else if(value == 120) {
				rate = 37.32;
			} else if(value > 120 && value < 120.2) {
				rate = (37.32 + 40.29) / 2;
			} else if(value == 120.2) {
				rate = 40.29;
			} else if(value > 120.2 && value < 120.4) {
				rate = (40.29 + 43.32) / 2;
			} else if(value == 120.4) {
				rate = 43.32;
			} else if(value > 120.4 && value < 120.6) {
				rate = (43.32 + 46.45) / 2;
			} else if(value == 120.6) {
				rate = 46.45;
			} else if(value > 120.6 && value < 120.8) {
				rate = (46.45 + 49.65) / 2;
			} else if(value == 120.8) {
				rate = 49.65;
			} else if(value > 120.8 && value < 121) {
				rate = (49.65 + 52.94) / 2;
			} else if(value == 121) {
				rate = 52.94;
			} else if(value > 121 && value < 121.2) {
				rate = (52.94 + 56.29) / 2;
			} else if(value == 121.2) {
				rate = 56.29;
			} else if(value > 121.2 && value < 121.4) {
				rate = (56.29 + 59.74) / 2;
			} else if(value == 121.4) {
				rate = 59.74;
			} else if(value > 121.4 && value < 121.6) {
				rate = (59.74 + 63.26) / 2;
			} else if(value == 121.6) {
				rate = 63.26;
			} else if(value > 121.6 && value < 121.8) {
				rate = (63.26 + 66.84) / 2;
			} else if(value == 121.8) {
				rate = 66.84;
			} else if(value > 121.8 && value < 122) {
				rate = (66.84 + 70.52) / 2;
			} else if(value == 122) {
				rate = 70.52;
			} else if(value > 122 && value < 122.2) {
				rate = (70.52 + 74.26) / 2;
			} else if(value == 122.2) {
				rate = 74.26;
			} else if(value > 122.2 && value < 122.4) {
				rate = (74.26 + 78.06) / 2;
			} else if(value == 122.4) {
				rate = 78.06;
			} else if(value > 122.4 && value < 122.6) {
				rate = (78.06 + 82) / 2;
			} else if(value == 122.6) {
				rate = 82;
			} else if(value > 122.6 && value < 122.8) {
				rate = (82 + 86.06) / 2;
			} else if(value == 122.8) {
				rate = 86.06;
			} else if(value > 122.8 && value < 123) {
				rate = (86.06 + 90.23) / 2;
			} else if(value == 123) {
				rate = 90.23;
			} else if(value > 123 && value < 123.2) {
				rate = (90.23 + 94.52) / 2;
			} else if(value == 123.2) {
				rate = 94.52;
			} else if(value > 123.2 && value < 123.4) {
				rate = (94.52 + 98.9) / 2;
			} else if(value == 123.4) {
				rate = 98.9;
			} else if(value > 123.4 && value < 123.45) {
				rate = (98.9 + 100) / 2;
			} else if(value == 123.45) {
				rate = 100;
			} else if(value > 123.45 && value < 123.6) {
				rate = (100 + 103.84) / 2;
			} else if(value == 123.6) {
				rate = 103.84;
			} else if(value > 123.6 && value < 123.8) {
				rate = (103.84 + 109.08) / 2;
			} else if(value == 123.8) {
				rate = 109.08;
			} else if(value > 123.8 && value < 124) {
				rate = (109.08 + 114.45) / 2;
			} else if(value == 124) {
				rate = 114.45;
			} else if(value > 124 && value < 124.2) {
				rate = (114.45 + 119.93) / 2;
			} else if(value == 124.2) {
				rate = 119.93;
			} else if(value > 124.2 && value < 124.4) {
				rate = (119.93 + 125.53) / 2;
			} else if(value == 124.4) {
				rate = 125.53;
			} else if(value > 124.4 && value < 124.6) {
				rate = (125.53 + 131.26) / 2;
			} else if(value == 124.6) {
				rate = 131.26;
			} else if(value > 124.6 && value < 124.8) {
				rate = (131.26 + 137.1) / 2;
			} else if(value == 124.8) {
				rate = 137.1;
			} else if(value > 124.8 && value < 125) {
				rate = (137.1 + 143.07) / 2;
			} else if(value == 125) {
				rate = 143.07;
			} else if(value > 125 && value < 125.2) {
				rate = (143.07 + 149.19) / 2;
			} else if(value == 125.2) {
				rate = 149.19;
			} else if(value > 125.2 && value < 125.4) {
				rate = (149.19 + 155.52) / 2;
			} else if(value == 125.4) {
				rate = 155.52;
			} else if(value > 125.4 && value < 125.6) {
				rate = (155.52 + 162.05) / 2;
			} else if(value == 125.6) {
				rate = 162.05;
			} else if(value > 125.6 && value < 125.8) {
				rate = (162.05 + 168.67) / 2;
			} else if(value == 125.8) {
				rate = 168.67;
			} else if(value > 125.8 && value < 126) {
				rate = (168.67 + 175.6) / 2;
			} else if(value == 126) {
				rate = 175.6;
			} else if(value > 126 && value < 126.2) {
				rate = (175.6 + 182.73) / 2;
			} else if(value == 126.2) {
				rate = 182.73;
			} else if(value > 126.2 && value < 126.3) {
				rate = (182.73 + 186.37) / 2;
			} else if(value == 126.3) {
				rate = 186.37;
			}
		}
		return rate;
	}
	
	private static List<Rainfall> rfList = new ArrayList<>();
	private static Integer lastDateTime = null;
	
	@SuppressWarnings("unchecked")
	@Override
	public ResponseObject<List<Rainfall>> rainfall() throws SqlSessionException {
		ResponseObject<List<Rainfall>> res = new ResponseObject<>();

		HttpURLConnection conn = null;
		BufferedReader br = null;
		
		String[] townArr = {"유구읍", "이인면", "탄천면", "계룡면", "반포면", "의당면", "정안면", "우성면", "사곡면", "신풍면", "중학동", "웅진동", "금학동", "옥룡동", "신관동", "월송동"};
		String[] nxArr = {"60", "62", "61", "63", "65", "63", "63", "61", "61", "60", "63", "63", "63", "63", "63", "63"};
		String[] nyArr = {"105", "101", "100", "100", "101", "104", "106", "103", "104", "104", "102", "103", "102", "103", "103", "103"};
		
		try {
			String nowDate = DateFormatUtils.format(Calendar.getInstance(), "yyyyMMdd");
			String nowTime = DateFormatUtils.format(Calendar.getInstance(), "HH");
			
			int nowDateTime = Integer.parseInt(nowDate+nowTime);
			
			if(lastDateTime == null) {
				lastDateTime = nowDateTime;
			} else if(nowDateTime - lastDateTime >= 1) {
				lastDateTime = nowDateTime;
				rfList.clear();
			}
			
			if(rfList.size() == 0) {
				for(int f=0; f<townArr.length; f++) {
					StringBuilder urlBuilder = new StringBuilder("http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst"); /*URL*/
			        urlBuilder.append("?" + URLEncoder.encode("ServiceKey","UTF-8") + "=oj6MOING18raw9U15sl58xJDj5UWsg1N5wuu1zzHI6R5ph3mRLFSJHSpXXD2qee7dNuyDF43dSprBpa4uybyqg%3D%3D"); /*Service Key*/
			        urlBuilder.append("&" + URLEncoder.encode("pageNo","UTF-8") + "=" + URLEncoder.encode("1", "UTF-8")); /*페이지번호*/
			        urlBuilder.append("&" + URLEncoder.encode("numOfRows","UTF-8") + "=" + URLEncoder.encode("10", "UTF-8")); /*한 페이지 결과 수*/
			        urlBuilder.append("&" + URLEncoder.encode("dataType","UTF-8") + "=" + URLEncoder.encode("JSON", "UTF-8")); /*요청자료형식(XML/JSON) Default: XML*/
			        urlBuilder.append("&" + URLEncoder.encode("base_date","UTF-8") + "=" + URLEncoder.encode(nowDate, "UTF-8")); /*‘21년 6월 28일 발표*/
			        urlBuilder.append("&" + URLEncoder.encode("base_time","UTF-8") + "=" + URLEncoder.encode(nowTime+"00", "UTF-8")); /*06시 발표(정시단위) */
			        urlBuilder.append("&" + URLEncoder.encode("nx","UTF-8") + "=" + URLEncoder.encode(nxArr[f], "UTF-8")); /*예보지점의 X 좌표값*/
			        urlBuilder.append("&" + URLEncoder.encode("ny","UTF-8") + "=" + URLEncoder.encode(nyArr[f], "UTF-8")); /*예보지점의 Y 좌표값*/
			        URL url = new URL(urlBuilder.toString());
					
					Map<String, Object> resultMap = new HashMap<>();
					
					conn = (HttpURLConnection) url.openConnection();
					conn.setConnectTimeout(5000);
					conn.setReadTimeout(5000);
					conn.setDoOutput(true);
					conn.setRequestMethod("GET");
					conn.connect();
					br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
					String line = null;
					StringBuffer result = new StringBuffer();
					while((line=br.readLine()) != null) result.append(line);
					ObjectMapper mapper = new ObjectMapper();
					resultMap = mapper.readValue(result.toString(), HashMap.class);
					
					JSONObject jObj = JSONObject.fromObject(resultMap);
					JSONArray jArr = jObj.getJSONObject("response").getJSONObject("body").getJSONObject("items").getJSONArray("item");
					for(int i=0; i<jArr.size(); i++) {
						JSONObject jo = jArr.getJSONObject(i);
						if("RN1".equals(jo.get("category"))) {
							Rainfall rf = new Rainfall();
							rf.setTown(townArr[f]);
							rf.setRainfall(jo.getInt("obsrValue"));
							rfList.add(rf);
							break;
						}
					}
				}
			}
			
			res.setData(rfList);
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		} finally {
			if(conn != null) conn.disconnect();
			if(br != null)
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		
		return res;
	}

	@Override
	public ResponseObject<SensorInfoStatusCount> sensorStatus() throws SqlSessionException {
		ResponseObject<SensorInfoStatusCount> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("status", "true");
			int statusOk = mapDao.sensorStatusCount(params);
			
			params.put("status", "false");
			int statusErr = mapDao.sensorStatusCount(params);
			
			SensorInfoStatusCount data = new SensorInfoStatusCount();
			data.setStatusOk(statusOk);
			data.setStatusErr(statusErr);
			
			res.setData(data);
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

}
