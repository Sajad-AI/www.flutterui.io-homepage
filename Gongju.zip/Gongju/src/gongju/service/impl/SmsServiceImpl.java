package gongju.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.CollectionUtils;
import org.apache.ibatis.session.SqlSessionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gongju.config.props.PathKeys;
import gongju.dao.SmsDao;
import gongju.model.PaginationList;
import gongju.model.ResponseObject;
import gongju.model.SmsDtl;
import gongju.model.SmsGroup;
import gongju.model.SmsMst;
import gongju.model.SmsMstList;
import gongju.model.SmsPhone;
import gongju.model.SmsTemplate;
import gongju.service.PaginationService;
import gongju.service.SmsService;
import gongju.utils.ExcelUtil;

@Service("smsService")
public class SmsServiceImpl implements SmsService {

	@Autowired
	private PaginationService paginationService;
	
	@Autowired
	private SmsDao smsDao;

	@Autowired
	private ExcelUtil excelUtil;
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsGroupAdd(String smsGroupName, String userID) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsGroup smsGroup = new SmsGroup();
			smsGroup.setSmsGroupName(smsGroupName);
			smsGroup.setUserID(userID);
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			smsGroup.setCreateDate(dtf.format(LocalDateTime.now()));
			
			if(smsDao.smsGroupAdd(smsGroup) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsGroupModify(Integer smsGroupSeq, String smsGroupName) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsGroup smsGroup = new SmsGroup();
			smsGroup.setSmsGroupSeq(smsGroupSeq);
			smsGroup.setSmsGroupName(smsGroupName);
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			smsGroup.setUpdateDate(dtf.format(LocalDateTime.now()));
			
			if(smsDao.smsGroupModify(smsGroup) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsGroupDelete(Integer smsGroupSeq) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsGroup smsGroup = new SmsGroup();
			smsGroup.setSmsGroupSeq(smsGroupSeq);
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			smsGroup.setDeleteDate(dtf.format(LocalDateTime.now()));
			
			if(smsDao.smsGroupModify(smsGroup) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<List<SmsGroup>> smsGroupList(String userID) throws SqlSessionException {
		ResponseObject<List<SmsGroup>> res = new ResponseObject<>();
		
		try {
			SmsGroup smsGroup = new SmsGroup();
			smsGroup.setUserID(userID);
			
			List<SmsGroup> sgl = smsDao.smsGroupList(smsGroup);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(sgl);
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<?> smsGroupExcel(Integer smsGroupSeq, HttpServletResponse response) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			List<String> headers = new ArrayList<>();
			headers.add("그룹명"); headers.add("성함"); headers.add("연락처");
			
			List<Map<String, Object>> dataList = new ArrayList<>();
			
			SmsGroup smsGroup = new SmsGroup();
			smsGroup.setSmsGroupSeq(smsGroupSeq);
			
			List<SmsGroup> sgl = smsDao.smsGroupList(smsGroup);
			if(CollectionUtils.isNotEmpty(sgl)) {
				SmsGroup sg = sgl.get(0);
				String smsGroupName = sg.getSmsGroupName();
				for(SmsPhone sp : sg.getSmsPhoneList()) {
					Map<String, Object> data = new HashMap<>();
					data.put("그룹명", smsGroupName);
					data.put("성함", sp.getPhoneName());
					data.put("연락처", sp.getPhoneNumber());
					
					dataList.add(data);
				}
			}
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			
			Map<String, Object> excelParams = new HashMap<>();
			excelParams.put("header", headers);
			excelParams.put("data", dataList);
			excelParams.put("fileName", "smsPhoneList_" + dtf.format(LocalDateTime.now()) +".xls");
			excelUtil.downloadExcel(excelParams, response);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsPhoneAdd(Integer smsGroupSeq, String phoneName, String phoneNumber) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsPhone smsPhone = new SmsPhone();
			smsPhone.setSmsGroupSeq(smsGroupSeq);
			smsPhone.setPhoneName(phoneName);
			smsPhone.setPhoneNumber(phoneNumber.replaceAll("[^0-9]", ""));
			
			if(smsDao.smsPhoneAdd(smsPhone) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsPhoneModify(Integer smsPhoneSeq, String phoneName, String phoneNumber) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsPhone smsPhone = new SmsPhone();
			smsPhone.setSmsPhoneSeq(smsPhoneSeq);
			smsPhone.setPhoneName(phoneName);
			smsPhone.setPhoneNumber(phoneNumber.replaceAll("[^0-9]", ""));
			
			if(smsDao.smsPhoneModify(smsPhone) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsPhoneDelete(Integer smsPhoneSeq) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsPhone smsPhone = new SmsPhone();
			smsPhone.setSmsPhoneSeq(smsPhoneSeq);
			
			if(smsDao.smsPhoneDelete(smsPhone) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsTemplateAdd(String userID, String smsTemplateTitle, String smsTemplate) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsTemplate smsTemplate_ = new SmsTemplate();
			smsTemplate_.setUserID(userID);
			smsTemplate_.setSmsTemplateTitle(smsTemplateTitle);
			smsTemplate_.setSmsTemplate(smsTemplate);
			
			/*if(StringUtils.isNotBlank(smsTemplate)) {
				smsTemplate_.setSmsTemplate(smsTemplate.replaceAll("(\r\n|\r|\n|\n\r)","<br/>"));
			}*/
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			smsTemplate_.setCreateDate(dtf.format(LocalDateTime.now()));
			
			if(smsDao.smsTemplateAdd(smsTemplate_) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsTemplateModify(Integer smsTemplateSeq, String smsTemplateTitle, String smsTemplate) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsTemplate smsTemplate_ = new SmsTemplate();
			smsTemplate_.setSmsTemplateSeq(smsTemplateSeq);
			smsTemplate_.setSmsTemplateTitle(smsTemplateTitle);
			smsTemplate_.setSmsTemplate(smsTemplate);
			/*if(StringUtils.isNotBlank(smsTemplate)) {
				smsTemplate_.setSmsTemplate(smsTemplate.replaceAll("(\r\n|\r|\n|\n\r)","<br/>"));
			}*/
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			smsTemplate_.setUpdateDate(dtf.format(LocalDateTime.now()));
			
			if(smsDao.smsTemplateModify(smsTemplate_) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsTemplateDelete(Integer smsTemplateSeq) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsTemplate smsTemplate_ = new SmsTemplate();
			smsTemplate_.setSmsTemplateSeq(smsTemplateSeq);
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			smsTemplate_.setDeleteDate(dtf.format(LocalDateTime.now()));
			
			if(smsDao.smsTemplateModify(smsTemplate_) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseObject<PaginationList<SmsTemplate>> smsTemplateList(Integer currentPage, String userID) throws SqlSessionException {
		ResponseObject<PaginationList<SmsTemplate>> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			if(currentPage != null)
				params.put("currentPage", currentPage);
			params.put("userID", userID);
			
			PaginationList<SmsTemplate> stl = (PaginationList<SmsTemplate>) paginationService.paginationSearch("gongju.dao.SmsDao.smsTemplateList", params);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(stl);
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<SmsTemplate> smsTemplateDetail(Integer smsTemplateSeq) throws SqlSessionException {
		ResponseObject<SmsTemplate> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("smsTemplateSeq", smsTemplateSeq);
			
			List<SmsTemplate> stl = smsDao.smsTemplateList(params);
			if(CollectionUtils.isNotEmpty(stl)) {
				res.setData(stl.get(0));
			}
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	
	private void sdkSmsSend(SmsMst smsMst, LocalDateTime ldt) {
		Map<String, Object> sdkSms = null;
		DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		List<SmsDtl> smsDtlList = smsMst.getSmsDtlList();
		int receiverCnt = smsDtlList.size();
		int init = 0;
		int totInit = 0;
		String destInfo = "";
		for(int i=0; i<receiverCnt; i++) {
			if(init == 0) {
				sdkSms = new HashMap<>();
				sdkSms.put("userId", smsMst.getUserID());
				sdkSms.put("callback", PathKeys.CALLBACK);
				sdkSms.put("reserved1", smsMst.getSmsMstSeq());
				sdkSms.put("nowDate", dtf2.format(ldt));
				sdkSms.put("smsMsg", smsMst.getSmsContent());
				
				if("R".equals(smsMst.getSmsType())) {			// 예약발송
					sdkSms.put("sendDate", smsMst.getReserveDate().replaceAll("[^0-9]", ""));
					sdkSms.put("scheduleType", 1);
				} else if("D".equals(smsMst.getSmsType())) {	// 즉시발송
					sdkSms.put("sendDate", dtf2.format(ldt));
					sdkSms.put("scheduleType", 0);
				}
			}
			
			SmsDtl smsDtl = smsDtlList.get(i);
			if(destInfo.length() > 0) destInfo += "|";
			destInfo += smsDtl.getPhoneName()+"^"+smsDtl.getPhoneNumber().replaceAll("[^0-9]", "");
			
			init++;
			totInit++;
			
			if(init == 100 || totInit == receiverCnt) {
				sdkSms.put("destCount", init);
				sdkSms.put("destInfo", destInfo);
				
				// save
				smsDao.sdkSmsSendAdd(sdkSms);
				
				if(init == 100) {
					init = 0;
					destInfo = "";
				}
			}
		}
	}
		
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsSendAdd(SmsMst smsMst) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			LocalDateTime ldt = LocalDateTime.now();
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			smsMst.setCreateDate(dtf.format(ldt));
			// smsMst.setSmsContent(smsMst.getSmsContent().replaceAll("(\r\n|\r|\n|\n\r)","<br/>"));
			
			if("R".equals(smsMst.getSmsType())) {		// 예약발송
				smsMst.setReserveDate(dtf.format(LocalDateTime.parse(smsMst.getReserveDate()+":00", dtf)));
			}
			
			if(smsDao.smsMstAdd(smsMst) > 0) {
				if(smsDao.smsDtlAdd(smsMst) > 0) {
					
					// KT 크로샷
					sdkSmsSend(smsMst, ldt);
					
					res.setCode(HttpStatus.OK.value());
					res.setMessage(HttpStatus.OK.getReasonPhrase());
				} else {
					res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
				}
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> smsSendModify(SmsMst smsMst) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			LocalDateTime ldt = LocalDateTime.now();
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			// smsMst.setSmsContent(smsMst.getSmsContent().replaceAll("(\r\n|\r|\n|\n\r)","<br/>"));
			
			if("R".equals(smsMst.getSmsType()) && smsMst.getReserveDate() != null) {	// 예약발송
				smsMst.setReserveDate(dtf.format(LocalDateTime.parse(smsMst.getReserveDate()+":00", dtf)));
			}
			
			if(smsDao.smsMstModify(smsMst) > 0) {
				
				smsDao.smsDtlDelete(smsMst);							// 수신목록 초기화
				smsDao.sdkSmsSendDelete(smsMst.getSmsMstSeq());			// 크로샷 DB 초기화
				smsDao.sdkSmsSendReportDelete(smsMst.getSmsMstSeq());	// 크로샷 DB 초기화
				
				if(smsDao.smsDtlAdd(smsMst) > 0) {
					
					// KT 크로샷
					sdkSmsSend(smsMst, ldt);
					
					res.setCode(HttpStatus.OK.value());
					res.setMessage(HttpStatus.OK.getReasonPhrase());
				} else {
					res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
					res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
				}
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<?> smsSendDelete(Integer smsMstSeq) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			SmsMst smsMst = new SmsMst();
			smsMst.setSmsMstSeq(smsMstSeq);
			
			smsDao.smsMstDelete(smsMst);
			smsDao.smsDtlDelete(smsMst);
			smsDao.sdkSmsSendDelete(smsMst.getSmsMstSeq());
			smsDao.sdkSmsSendReportDelete(smsMst.getSmsMstSeq());
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ResponseObject<PaginationList<SmsMstList>> smsSendResultList(Integer currentPage, String userID, String beginSendDate, String endSendDate, String smsContent) throws SqlSessionException {
		ResponseObject<PaginationList<SmsMstList>> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			if(currentPage != null)
				params.put("currentPage", currentPage);
			params.put("userID", userID);
			params.put("beginSendDate", beginSendDate);
			params.put("endSendDate", endSendDate);
			params.put("smsContent", smsContent);
			
			params.put("isSend", "Y");	// 전송 완료건만
			
			PaginationList<SmsMstList> stl = (PaginationList<SmsMstList>) paginationService.paginationSearch("gongju.dao.SmsDao.smsSendResultList", params);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(stl);
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public ResponseObject<PaginationList<SmsMstList>> smsSendReserveList(Integer currentPage, String userID, String beginReserveDate, String endReserveDate, String smsContent) throws SqlSessionException {
		ResponseObject<PaginationList<SmsMstList>> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			if(currentPage != null)
				params.put("currentPage", currentPage);
			params.put("userID", userID);
			params.put("beginReserveDate", beginReserveDate);
			params.put("endReserveDate", endReserveDate);
			params.put("smsContent", smsContent);
			
			params.put("smsType", "R");	// 예약전송
			params.put("isSend", "N");	// 전송 미완료건만
			
			PaginationList<SmsMstList> stl = (PaginationList<SmsMstList>) paginationService.paginationSearch("gongju.dao.SmsDao.smsSendResultList", params);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(stl);
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
}
