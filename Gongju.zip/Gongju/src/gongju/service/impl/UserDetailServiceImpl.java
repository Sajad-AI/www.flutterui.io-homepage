package gongju.service.impl;

import java.util.ArrayList;
import java.util.Collection;

import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import gongju.dao.LoginDao;
import gongju.model.User;

public class UserDetailServiceImpl extends SqlSessionDaoSupport implements UserDetailsService {
	@Autowired LoginDao loginDao;
	
	@Override
	public User loadUserByUsername(String id) throws UsernameNotFoundException {
		User user = new User();
		user.setUserID(id);
		
		user = loginDao.getUser(user);
		
		if(user == null)
			return null;
		
		user.setUsername(id);
		user.setPassword(loginDao.getPassword(id));
		
		Collection<GrantedAuthority> role = new ArrayList<GrantedAuthority>();
		
		if(user.getIsAdminPerm()) {
			role.add(new SimpleGrantedAuthority("ROLE_ADMIN"));
		} else {
			role.add(new SimpleGrantedAuthority("ROLE_USER"));
		}
		
		user.setAuthorities(role);
		
		return user;
	}
}