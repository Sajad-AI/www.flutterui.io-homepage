package gongju.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import org.apache.commons.collections.CollectionUtils;
import org.apache.ibatis.session.SqlSessionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import gongju.dao.AreaDao;
import gongju.model.AreaMst;
import gongju.model.BroadcastDevice;
import gongju.model.CCTVDevice;
import gongju.model.PaginationList;
import gongju.model.RTUDevice;
import gongju.model.RTUDeviceStatus;
import gongju.model.ResponseObject;
import gongju.model.SensorInfo;
import gongju.model.SensorInfoStatus;
import gongju.model.SensorInfoValue;
import gongju.model.param.AreaMstAdd;
import gongju.model.param.AreaMstDelete;
import gongju.model.param.AreaMstDetail;
import gongju.model.param.AreaMstList;
import gongju.model.param.AreaMstModify;
import gongju.model.param.BroadcastDeviceDelete;
import gongju.model.param.BroadcastDeviceModify;
import gongju.model.param.CCTVDeviceDelete;
import gongju.model.param.CCTVDeviceModify;
import gongju.model.param.RTUDeviceDelete;
import gongju.model.param.RTUDeviceModify;
import gongju.model.param.SensorInfoDelete;
import gongju.model.param.SensorInfoModify;
import gongju.service.AreaService;
import gongju.service.PaginationService;

@Service("areaService")
public class AreaServiceImpl implements AreaService {

	@Autowired
	private AreaDao areaDao;

	@Autowired
	private PaginationService paginationService;
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> areaAdd(AreaMstAdd areaMst) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			areaMst.setCreateDate(dtf.format(LocalDateTime.now()));
			
			//행안부 연계 작업
			if(areaMst.isNDMS() == true) areaMst = apiDsrisk(areaMst);
			
			if(areaDao.areaMstAdd(areaMst) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> areaModify(AreaMstModify areaMst) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			areaMst.setUpdateDate(dtf.format(LocalDateTime.now()));
			
			if(areaDao.areaMstModify(areaMst) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> areaDelete(AreaMstDelete areaMst) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			AreaMstModify areaMstModify = new AreaMstModify();
			areaMstModify.setAreaID(areaMst.getAreaID());
			areaMstModify.setIsDeleteTarget(true);
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			areaMstModify.setUpdateDate(dtf.format(LocalDateTime.now()));
			
			if(areaDao.areaMstModify(areaMstModify) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseObject<PaginationList<AreaMst>> areaList(AreaMstList areaMst) throws SqlSessionException {
		ResponseObject<PaginationList<AreaMst>> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			if(areaMst.getCurrentPage() != null)
				params.put("currentPage", areaMst.getCurrentPage());
			
			PaginationList<AreaMst> aml = (PaginationList<AreaMst>) paginationService.paginationSearch("gongju.dao.AreaDao.areaMstList", params);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(aml);
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<AreaMst> areaDetail(AreaMstDetail areaMst) throws SqlSessionException {
		ResponseObject<AreaMst> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("areaID", areaMst.getAreaID());
			
			List<AreaMst> aml = areaDao.areaMstList(params);
			if(CollectionUtils.isNotEmpty(aml)) {
				res.setData(aml.get(0));
			}
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> cctvDeviceAdd(CCTVDevice cctvDevice) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.cctvDeviceAdd(cctvDevice) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> cctvDeviceModify(CCTVDeviceModify cctvDevice) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.cctvDeviceModify(cctvDevice) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> cctvDeviceDelete(CCTVDeviceDelete cctvDevice) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.cctvDeviceDelete(cctvDevice) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<CCTVDevice> cctvDeviceDetail(CCTVDeviceDelete cctvDevice) throws SqlSessionException {
		ResponseObject<CCTVDevice> res = new ResponseObject<>();
		
		try {
			res.setData(areaDao.cctvDeviceDetail(cctvDevice));
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> broadcastDeviceAdd(BroadcastDevice broadcastDevice) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.broadcastDeviceAdd(broadcastDevice) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> broadcastDeviceModify(BroadcastDeviceModify broadcastDevice) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.broadcastDeviceModify(broadcastDevice) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> broadcastDeviceDelete(BroadcastDeviceDelete broadcastDevice) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.broadcastDeviceDelete(broadcastDevice) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<BroadcastDevice> broadcastDeviceDetail(BroadcastDeviceDelete broadcastDevice) throws SqlSessionException {
		ResponseObject<BroadcastDevice> res = new ResponseObject<>();
		
		try {
			res.setData(areaDao.broadcastDeviceDetail(broadcastDevice));
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> rtuDeviceAdd(RTUDevice rtuDevice) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.rtuDeviceAdd(rtuDevice) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> rtuDeviceModify(RTUDeviceModify rtuDevice) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.rtuDeviceModify(rtuDevice) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> rtuDeviceDelete(RTUDeviceDelete rtuDevice) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.rtuDeviceDelete(rtuDevice) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<RTUDevice> rtuDeviceDetail(RTUDeviceDelete rtuDevice) throws SqlSessionException {
		ResponseObject<RTUDevice> res = new ResponseObject<>();
		
		try {
			res.setData(areaDao.rtuDeviceDetail(rtuDevice));
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<RTUDeviceStatus> rtuDeviceStatus(gongju.model.param.RTUDeviceStatusParam rtuDevice) throws SqlSessionException {
		ResponseObject<RTUDeviceStatus> res = new ResponseObject<>();
		
		try {
			res.setData(areaDao.rtuDeviceStatus(rtuDevice));
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> sensorInfoAdd(SensorInfo sensorInfo) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.sensorInfoAdd(sensorInfo) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> sensorInfoModify(SensorInfoModify sensorInfo) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.sensorInfoModify(sensorInfo) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> sensorInfoDelete(SensorInfoDelete sensorInfo) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			if(areaDao.sensorInfoDelete(sensorInfo) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<SensorInfo> sensorInfoDetail(SensorInfoDelete sensorInfo) throws SqlSessionException {
		ResponseObject<SensorInfo> res = new ResponseObject<>();
		
		try {
			res.setData(areaDao.sensorInfoDetail(sensorInfo));
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<SensorInfoStatus> sensorInfoStatus(gongju.model.param.SensorInfoStatusParam sensorInfo) throws SqlSessionException {
		ResponseObject<SensorInfoStatus> res = new ResponseObject<>();
		
		try {
			SensorInfoStatus sis = new SensorInfoStatus();
			
			if(sensorInfo.getSensorType() == 0) {			// 강우량계
				sensorInfo.setSensorTypeConvert("11021");
			} else if(sensorInfo.getSensorType() == 1) {	// 수위계
				sensorInfo.setSensorTypeConvert("11031");
			} else if(sensorInfo.getSensorType() == 2) {	// 변위계
				sensorInfo.setSensorTypeConvert("11071");
			}
			
			sis = areaDao.sensorInfoStatus(sensorInfo);
			List<SensorInfoValue> siv = new ArrayList<>();
			if(sensorInfo.getSensorType() == 0) {			// 강우량계
				sensorInfo.setSensorValueTypeConvert("31021"); 	// 시
				siv.add(areaDao.sensorInfoValue(sensorInfo));
				sensorInfo.setSensorValueTypeConvert("31023");	// 금일
				siv.add(areaDao.sensorInfoValue(sensorInfo));
				sensorInfo.setSensorValueTypeConvert("31025");	// 월
				siv.add(areaDao.sensorInfoValue(sensorInfo));
				sensorInfo.setSensorValueTypeConvert("31027");	// 연
				siv.add(areaDao.sensorInfoValue(sensorInfo));
				sensorInfo.setSensorValueTypeConvert("31029");	// 전일
				siv.add(areaDao.sensorInfoValue(sensorInfo));
			} else if(sensorInfo.getSensorType() == 1) {	// 수위계
				sensorInfo.setSensorValueTypeConvert("31031");
				siv.add(areaDao.sensorInfoValue(sensorInfo));
			} else if(sensorInfo.getSensorType() == 2) {	// 변위계
				sensorInfo.setSensorValueTypeConvert("31071");
				siv.add(areaDao.sensorInfoValue(sensorInfo));
			}
			sis.setSensorInfoValue(siv);
			
			res.setData(sis);
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	public AreaMstAdd apiDsrisk(AreaMstAdd areaMst) throws SqlSessionException, UnsupportedEncodingException 
	{
		/*
		 * 
		 *  재해위험지역 등록(NDMS 연계 버튼 클릭 시) 전송 항목
			apikey,dscode,dsname,dsaddr,bdong_cd,lat,lot,dsappday,dstype,dsfacnm,dsresn,admcode
			apikey = 지급받은 apiKey
			dscode = 재해위험지역코드(시군구코드 + 구분코드 + 일련번호) PK
			dsname = 재해위험지역명
			dsaddr = 재해위험지역 대표 주소
			bdong_cd = 법정동코드(KIKcd_B 문서 참고) > 지역 주소에 따라 코드 변경 필요
			lat = 위도
			lot = 경도
			dsappday = 지정일자(지역등록날짜 YYYYMMDD)
			dstype = 유형(필수값 X)
			dsfacnm = 시설명(필수값 X)
			dsresn = 지정사유(필수값 X)
			admcode = 관리기관코드(시군구코드)
			
			(고정) apiKey : 1aac7f462086dec413b63b4743a6ade7b0fa953be8
			(고정) 공주시 시군구코드 : 34020
			구분코드 : 하천(0), 내수(1), 해일(2), 저수지(3), 급경사지(4), 기타(9)
			일련번호 : NDMS 연계 시 sequence 부여(4자리)
			법정동코드 : 공주시 199건 Master Data DB 추가 필요(KIKcd_B 문서 참고)
		 * 
		 * */
		
		// 전송 URL
		String apiURL = "http://203.250.241.41/api/data/dsrisk.do";
		
		String apiKey = "1aac7f462086dec413b63b4743a6ade7b0fa953be8";
		String address = areaMst.getAddr1()+" "+areaMst.getAddr2()+" "+areaMst.getAddr3();
		String bdong_cd = areaDao.getbdongCd(areaMst);
		String admcode = "34020";
		
		String dscode = admcode+"3"+"0001";
		System.out.println("bdong_cd : "+bdong_cd);
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd");
		String dsappday = dtf.format(LocalDateTime.now());
		
		StringBuilder urlBuilder = new StringBuilder("apikey="+apiKey); /*apiKey*/
		urlBuilder.append("&" + "dscode=" + dscode); /*재해위험지역코드*/
		urlBuilder.append("&" + "dsname=" + areaMst.getAreaName()); /*재해위험지역명*/
		urlBuilder.append("&" + "dsaddr=" + address); /*재해위험지역 대표 주소*/
		urlBuilder.append("&" + "bdong_cd=" + bdong_cd); /*법정동코드*/
		urlBuilder.append("&" + "lat=" + areaMst.getAreaLatitude()); /*위도*/
		urlBuilder.append("&" + "lot=" + areaMst.getAreaLongitude()); /*경도*/
		urlBuilder.append("&" + "dsappday=" + dsappday); /*지정일자*/
		urlBuilder.append("&" + "admcode=" + admcode); /*관리기관코드*/
		
		// api 전송
		Map<String, Object> map = sendPost(apiURL, urlBuilder.toString());

		try {
			String responseCode = map.get("responseCode").toString();
			
			int ndmsStatus = 1;
			if("200".equals(responseCode)) ndmsStatus = 0;
			
			areaMst.setNdmsStatus(ndmsStatus);
			areaMst.setNdmsResult(map.get("responseString").toString());
			
			//System.out.println("HTTP body : " + map.get("responseString").toString()+", responseCode : "+map.get("responseCode").toString());
		} catch (Exception e) {
			e.printStackTrace();
		}

		return areaMst;
	}
	
	// post 방식 전송 
	public Map<String, Object> sendPost(String targetUrl, String parameters) {
		int responseCode = 0;
		String responseString = "";
		Map<String, Object> map = new HashMap<String, Object>();
		
		try {
			
			URL url = new URL(targetUrl);
			HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

			httpURLConnection.setRequestMethod("POST"); // HTTP POST 메소드 설정
			httpURLConnection.setDoInput(true);
			httpURLConnection.setDoOutput(true); // POST 전송 대기 설정
			httpURLConnection.setRequestProperty("Connection", "Keep-Alive");
			httpURLConnection.setRequestProperty("Cache-Control", "no-cache");
			httpURLConnection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");

			// 파라메터 전송
			DataOutputStream dataOutputStream = new DataOutputStream(httpURLConnection.getOutputStream());
			dataOutputStream.write(parameters.getBytes("utf-8"));
			dataOutputStream.flush();
			dataOutputStream.close();

			// 응답 받기
			responseCode = httpURLConnection.getResponseCode();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream(), "utf-8"));
			String inputLine;
			StringBuffer stringBuffer = new StringBuffer();
			while ((inputLine = bufferedReader.readLine()) != null) {
				stringBuffer.append(inputLine);
			}
			responseString = stringBuffer.toString();
			
			map.put("responseString", responseString);
			map.put("responseCode", responseCode);
			
			bufferedReader.close();
		} catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			// print result
			//System.out.println("HTTP 응답 코드 : " + responseCode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return map;
	}

}
