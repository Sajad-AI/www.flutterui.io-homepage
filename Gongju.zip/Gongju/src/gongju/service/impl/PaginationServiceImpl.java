package gongju.service.impl;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import gongju.model.PaginationList;
import gongju.service.PaginationService;

@Service("paginationService")
public class PaginationServiceImpl implements PaginationService {

	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public PaginationList<?> paginationSearch(String statement, Map<String, Object> params) {
		PaginationList<?> result = null;	//결과 List
		
		int totalCount = 0;			//전체 글카운트
		int page = 0;				//현제페이지에서 계산된값
		int row = params.containsKey("rows") ? convertObjectToInt(params.get("rows")) : 10;
		int pageNum = params.containsKey("pageNum") ? convertObjectToInt(params.get("pageNum")) : 10;
		
		//게시판 설정 - 페이지 행
		params.put("rows",row);
		
		//게시판 전체 카운트 
		int total =  sqlSessionTemplate.selectOne(statement+"Count",params);
		totalCount = total;
		
		//현재 페이지
		int currentPage = params.containsKey("currentPage") ? convertObjectToInt(params.get("currentPage")) : 1;  
		
		page = ( currentPage - 1 ) * row;
		params.put("page",page);
		
		//만들어진 parameter로 데이터 가져옴.
		List<?> list =  sqlSessionTemplate.selectList(statement, params);
		
		result = new PaginationList<>(list, totalCount, currentPage, row, pageNum);
		return result;
	}
	
	private int convertObjectToInt(Object obj) {
		int i = 0;
		if(obj instanceof String) {
			i = Integer.valueOf((String)obj);
		}else {
			i = (int)obj;
		}
		return i;		
	}

}
