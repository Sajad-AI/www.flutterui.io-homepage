package gongju.service.impl;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.ibatis.session.SqlSessionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import gongju.config.props.PathKeys;
import gongju.dao.BroadcastDao;
import gongju.model.BroadcastDtl;
import gongju.model.BroadcastMst;
import gongju.model.BroadcastMstList;
import gongju.model.BroadcastTemplate;
import gongju.model.BroadcastTts;
import gongju.model.PaginationList;
import gongju.model.ResponseObject;
import gongju.model.param.BroadcastTemplateDelete;
import gongju.model.param.BroadcastTemplateDetail;
import gongju.model.param.BroadcastTemplateList;
import gongju.model.param.BroadcastTemplateModify;
import gongju.model.param.BroadcastTtsAdd;
import gongju.service.BroadcastService;
import gongju.service.PaginationService;
import net.sf.json.JSONObject;

@Service("broadcastService")
public class BroadcastServiceImpl implements BroadcastService {

	@Autowired
	private PaginationService paginationService;
	
	@Autowired
	private BroadcastDao broadcastDao;

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> broadcastTemplateAdd(BroadcastTemplate broadcastTemplate) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			broadcastTemplate.setCreateDate(dtf.format(LocalDateTime.now()));
			
			if(broadcastDao.broadcastTemplateAdd(broadcastTemplate) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> broadcastTemplateModify(BroadcastTemplateModify broadcastTemplate) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			broadcastTemplate.setUpdateDate(dtf.format(LocalDateTime.now()));
			
			if(broadcastDao.broadcastTemplateModify(broadcastTemplate) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> broadcastTemplateDelete(BroadcastTemplateDelete broadcastTemplate) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			BroadcastTemplateModify broadcastTemplate_ = new BroadcastTemplateModify();
			broadcastTemplate_.setBroadcastTemplateSeq(broadcastTemplate.getBroadcastTemplateSeq());
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			broadcastTemplate_.setDeleteDate(dtf.format(LocalDateTime.now()));
			
			if(broadcastDao.broadcastTemplateModify(broadcastTemplate_) > 0) {
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseObject<PaginationList<BroadcastTemplate>> broadcastTemplateList(BroadcastTemplateList broadcastTemplate) throws SqlSessionException {
		ResponseObject<PaginationList<BroadcastTemplate>> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			if(broadcastTemplate.getCurrentPage() != null)
				params.put("currentPage", broadcastTemplate.getCurrentPage());
			params.put("userID", broadcastTemplate.getUserID());
			
			PaginationList<BroadcastTemplate> btl = (PaginationList<BroadcastTemplate>) paginationService.paginationSearch("gongju.dao.BroadcastDao.broadcastTemplateList", params);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(btl);
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<BroadcastTemplate> broadcastTemplateDetail(BroadcastTemplateDetail broadcastTemplate) throws SqlSessionException {
		ResponseObject<BroadcastTemplate> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			params.put("broadcastTemplateSeq", broadcastTemplate.getBroadcastTemplateSeq());
			
			List<BroadcastTemplate> btl = broadcastDao.broadcastTemplateList(params);
			if(CollectionUtils.isNotEmpty(btl)) {
				res.setData(btl.get(0));
			}
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	
	
	@Override
	public ResponseObject<BroadcastTts> broadcastTts(BroadcastTtsAdd broadcastTts) throws SqlSessionException {
		ResponseObject<BroadcastTts> res = new ResponseObject<>();
		
		try {
			RestTemplate rt = new RestTemplate();
			
			MultiValueMap<String, Object> params = new LinkedMultiValueMap<String, Object>();
			params.add("Amute", 5);
			params.add("Aaudio", broadcastTts.getBeginEffect() == 0 ? "chimeBell" : broadcastTts.getBeginEffect() == 1 ? "siren" : "chimeBell");
			params.add("Bmute", 5);
			params.add("Baudio", broadcastTts.getEndEffect() == 0 ? "chimeBell" : broadcastTts.getEndEffect() == 1 ? "siren" : "chimeBell");
			params.add("Message", broadcastTts.getBroadcastContent());
			params.add("Speed", 100);
			params.add("Volume", 100);
			
			HttpHeaders headers = new HttpHeaders();
			headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE + "; charset=UTF-8");
			
			HttpEntity<MultiValueMap<String, Object>> request = new HttpEntity<MultiValueMap<String, Object>>(params, headers);

			ResponseEntity<JSONObject> response = rt.postForEntity(PathKeys.TTS_REQ, request, JSONObject.class);
			
			BroadcastTts bct = new BroadcastTts();
			bct.setFileName(PathKeys.TTS_REQ + response.getBody().getString("file_name"));
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}
	
	private void sdkVmsSend(BroadcastMst broadcastMst, LocalDateTime ldt) {
		Map<String, Object> vdkSms = null;
		DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
		List<BroadcastDtl> broadcastDtlList = broadcastMst.getBroadcastDtlList();
		int receiverCnt = broadcastDtlList.size();
		int init = 0;
		int totInit = 0;
		String destInfo = "";
		for(int i=0; i<receiverCnt; i++) {
			BroadcastDtl broadcastDtl = broadcastDtlList.get(i);
			
			if(init == 0) {
				vdkSms = new HashMap<>();
				vdkSms.put("userId", broadcastMst.getUserID());
				
				vdkSms.put("msgSubtype", 31);
				
				String[] attachFileSplit = broadcastMst.getBroadcastTts().split("/");
				vdkSms.put("attachFile", attachFileSplit[attachFileSplit.length-1]);
				
				System.out.println(vdkSms.get("attachFile"));
				
				vdkSms.put("callback", PathKeys.CALLBACK);
				vdkSms.put("reserved1", broadcastMst.getBroadcastMstSeq());
				vdkSms.put("nowDate", dtf2.format(ldt));
				
				if("R".equals(broadcastMst.getBroadcastType())) {			// 예약발송
					vdkSms.put("sendDate", broadcastDtl.getBroadcastDate().replaceAll("[^0-9]", ""));
					vdkSms.put("scheduleType", 1);
				} else if("D".equals(broadcastMst.getBroadcastType())) {	// 즉시발송
					vdkSms.put("sendDate", dtf2.format(ldt));
					vdkSms.put("scheduleType", 0);
				}
			}
			
			if(destInfo.length() > 0) destInfo += "|";
			destInfo += broadcastDtl.getBroadcastDtlSeq()+"^"+broadcastDtl.getPhoneNum().replaceAll("[^0-9]", "");
			
			init++;
			totInit++;
			
			if(init == 100 || totInit == receiverCnt) {
				vdkSms.put("destCount", init);
				vdkSms.put("destInfo", destInfo);
				
				// save
				broadcastDao.sdkVmsSendAdd(vdkSms);
				
				if(init == 100) {
					init = 0;
					destInfo = "";
				}
			}
		}
	}
	
	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> broadcastMstAdd(BroadcastMst broadcastMst) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			LocalDateTime ldt = LocalDateTime.now();
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String now = dtf.format(ldt);
			broadcastMst.setCreateDate(now);
			
			if("R".equals(broadcastMst.getBroadcastType())) {					// 예약방송
				if("D".equals(broadcastMst.getBroadcastPeriodType())) { 			// 일간
					for(BroadcastDtl broadcastDtl : broadcastMst.getBroadcastDtlList()) {
						String broadcastDate = broadcastMst.getBeginPeriod()+" "+broadcastMst.getSendHour()+":"+broadcastMst.getSendMinute()+":00";
						broadcastDtl.setBroadcastDate(dtf.format(LocalDateTime.parse(broadcastDate, dtf)));
					}
				} else if("W".equals(broadcastMst.getBroadcastPeriodType()) ||
							"M".equals(broadcastMst.getBroadcastPeriodType())) {
					
					SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
					
					Date beginPeriodDate = fmt.parse(broadcastMst.getBeginPeriod());
					Calendar beginPeriodCal = Calendar.getInstance();
					beginPeriodCal.setTime(beginPeriodDate);
					
					Date endPeriodDate = fmt.parse(broadcastMst.getEndPeriod());
					Calendar endPeriodCal = Calendar.getInstance();
					endPeriodCal.setTime(endPeriodDate);
					
					long diffSec = (endPeriodCal.getTimeInMillis() - beginPeriodCal.getTimeInMillis()) / 1000;
					long diffDays = diffSec / (24*60*60);
					
					if("W".equals(broadcastMst.getBroadcastPeriodType())) {			// 주간
						List<BroadcastDtl> newBroadcastDtlList = new ArrayList<>();
						for(BroadcastDtl broadcastDtl : broadcastMst.getBroadcastDtlList()) {
							Calendar bpc = (Calendar) beginPeriodCal.clone();
							
							for(int i=0; i<=diffDays; i++) {
								boolean isReserve = false;
								int dayOfWeek = bpc.get(Calendar.DAY_OF_WEEK);
								
								for(String sendPeriod : broadcastMst.getSendPeriod().split(",")) {
									if(Integer.parseInt(sendPeriod) == dayOfWeek) {
										isReserve = true;
										break;
									}
								}
								
								if(isReserve) {
									BroadcastDtl newBroadcastDtl = new BroadcastDtl();
									newBroadcastDtl.setAreaID(broadcastDtl.getAreaID());
									newBroadcastDtl.setBroadcastDevID(broadcastDtl.getBroadcastDevID());
									
									String broadcastDate = DateFormatUtils.format(bpc, "yyyy-MM-dd")+" "+broadcastMst.getSendHour()+":"+broadcastMst.getSendMinute()+":00";
									newBroadcastDtl.setBroadcastDate(dtf.format(LocalDateTime.parse(broadcastDate, dtf)));
									
									newBroadcastDtlList.add(newBroadcastDtl);
								}
								
								bpc.add(Calendar.DATE, 1);
							}
						}
						broadcastMst.setBroadcastDtlList(newBroadcastDtlList);
					} else if("M".equals(broadcastMst.getBroadcastPeriodType())) {	// 월간
						List<BroadcastDtl> newBroadcastDtlList = new ArrayList<>();
						for(BroadcastDtl broadcastDtl : broadcastMst.getBroadcastDtlList()) {
							Calendar bpc = (Calendar) beginPeriodCal.clone();
							
							for(int i=0; i<=diffDays; i++) {
								boolean isReserve = false;
								int date = bpc.get(Calendar.DATE);
								
								for(String sendPeriod : broadcastMst.getSendPeriod().split(",")) {
									if("L".equals(sendPeriod)) {	// 마지막날
										if(bpc.getActualMaximum(Calendar.DAY_OF_MONTH) == date) {
											isReserve = true;
											break;
										}
									} else if(Integer.parseInt(sendPeriod) == date) {
										isReserve = true;
										break;
									}
								}
								
								if(isReserve) {
									BroadcastDtl newBroadcastDtl = new BroadcastDtl();
									newBroadcastDtl.setAreaID(broadcastDtl.getAreaID());
									newBroadcastDtl.setBroadcastDevID(broadcastDtl.getBroadcastDevID());
									
									String broadcastDate = DateFormatUtils.format(bpc, "yyyy-MM-dd")+" "+broadcastMst.getSendHour()+":"+broadcastMst.getSendMinute()+":00";
									newBroadcastDtl.setBroadcastDate(dtf.format(LocalDateTime.parse(broadcastDate, dtf)));
									
									newBroadcastDtlList.add(newBroadcastDtl);
								}
								
								bpc.add(Calendar.DATE, 1);
							}
						}
						broadcastMst.setBroadcastDtlList(newBroadcastDtlList);
					}
				}
				
				if(broadcastMst.getBeginPeriod() != null && broadcastMst.getBeginPeriod().length() > 0) {
					broadcastMst.setBeginPeriod(dtf.format(LocalDateTime.parse(broadcastMst.getBeginPeriod()+" 00:00:00", dtf)));
				}
				if(broadcastMst.getEndPeriod() != null && broadcastMst.getEndPeriod().length() > 0) {
					broadcastMst.setEndPeriod(dtf.format(LocalDateTime.parse(broadcastMst.getEndPeriod()+" 00:00:00", dtf)));
				}
			} else if("D".equals(broadcastMst.getBroadcastType())) {			// 즉시방송
				for(BroadcastDtl broadcastDtl : broadcastMst.getBroadcastDtlList()) {
					broadcastDtl.setBroadcastDate(now);
				}
			}
			
			if(broadcastDao.broadcastMstAdd(broadcastMst) > 0) {
				broadcastDao.broadcastDtlAdd(broadcastMst);
				sdkVmsSend(broadcastMst, ldt);
				
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	@Transactional(rollbackFor = { Exception.class })
	public ResponseObject<?> broadcastMstModify(BroadcastMst broadcastMst) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			LocalDateTime ldt = LocalDateTime.now();
			
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
			String now = dtf.format(ldt);
			broadcastMst.setUpdateDate(now);
			
			if("R".equals(broadcastMst.getBroadcastType())) {					// 예약방송
				if("D".equals(broadcastMst.getBroadcastPeriodType())) { 			// 일간
					for(BroadcastDtl broadcastDtl : broadcastMst.getBroadcastDtlList()) {
						String broadcastDate = broadcastMst.getBeginPeriod()+" "+broadcastMst.getSendHour()+":"+broadcastMst.getSendMinute()+":00";
						broadcastDtl.setBroadcastDate(dtf.format(LocalDateTime.parse(broadcastDate, dtf)));
					}
				} else if("W".equals(broadcastMst.getBroadcastPeriodType()) ||
							"M".equals(broadcastMst.getBroadcastPeriodType())) {
					
					SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
					
					Date beginPeriodDate = fmt.parse(broadcastMst.getBeginPeriod());
					Calendar beginPeriodCal = Calendar.getInstance();
					beginPeriodCal.setTime(beginPeriodDate);
					
					Date endPeriodDate = fmt.parse(broadcastMst.getEndPeriod());
					Calendar endPeriodCal = Calendar.getInstance();
					endPeriodCal.setTime(endPeriodDate);
					
					long diffSec = (endPeriodCal.getTimeInMillis() - beginPeriodCal.getTimeInMillis()) / 1000;
					long diffDays = diffSec / (24*60*60);
					
					if("W".equals(broadcastMst.getBroadcastPeriodType())) {			// 주간
						List<BroadcastDtl> newBroadcastDtlList = new ArrayList<>();
						for(BroadcastDtl broadcastDtl : broadcastMst.getBroadcastDtlList()) {
							Calendar bpc = (Calendar) beginPeriodCal.clone();
							
							for(int i=0; i<=diffDays; i++) {
								boolean isReserve = false;
								int dayOfWeek = bpc.get(Calendar.DAY_OF_WEEK);
								
								for(String sendPeriod : broadcastMst.getSendPeriod().split(",")) {
									if(Integer.parseInt(sendPeriod) == dayOfWeek) {
										isReserve = true;
										break;
									}
								}
								
								if(isReserve) {
									BroadcastDtl newBroadcastDtl = new BroadcastDtl();
									newBroadcastDtl.setAreaID(broadcastDtl.getAreaID());
									newBroadcastDtl.setBroadcastDevID(broadcastDtl.getBroadcastDevID());
									
									String broadcastDate = DateFormatUtils.format(bpc, "yyyy-MM-dd")+" "+broadcastMst.getSendHour()+":"+broadcastMst.getSendMinute()+":00";
									newBroadcastDtl.setBroadcastDate(dtf.format(LocalDateTime.parse(broadcastDate, dtf)));
									
									newBroadcastDtlList.add(newBroadcastDtl);
								}
								
								bpc.add(Calendar.DATE, 1);
							}
						}
						broadcastMst.setBroadcastDtlList(newBroadcastDtlList);
					} else if("M".equals(broadcastMst.getBroadcastPeriodType())) {	// 월간
						List<BroadcastDtl> newBroadcastDtlList = new ArrayList<>();
						for(BroadcastDtl broadcastDtl : broadcastMst.getBroadcastDtlList()) {
							Calendar bpc = (Calendar) beginPeriodCal.clone();
							
							for(int i=0; i<=diffDays; i++) {
								boolean isReserve = false;
								int date = bpc.get(Calendar.DATE);
								
								for(String sendPeriod : broadcastMst.getSendPeriod().split(",")) {
									if("L".equals(sendPeriod)) {	// 마지막날
										if(bpc.getActualMaximum(Calendar.DAY_OF_MONTH) == date) {
											isReserve = true;
											break;
										}
									} else if(Integer.parseInt(sendPeriod) == date) {
										isReserve = true;
										break;
									}
								}
								
								if(isReserve) {
									BroadcastDtl newBroadcastDtl = new BroadcastDtl();
									newBroadcastDtl.setAreaID(broadcastDtl.getAreaID());
									newBroadcastDtl.setBroadcastDevID(broadcastDtl.getBroadcastDevID());
									
									String broadcastDate = DateFormatUtils.format(bpc, "yyyy-MM-dd")+" "+broadcastMst.getSendHour()+":"+broadcastMst.getSendMinute()+":00";
									newBroadcastDtl.setBroadcastDate(dtf.format(LocalDateTime.parse(broadcastDate, dtf)));
									
									newBroadcastDtlList.add(newBroadcastDtl);
								}
								
								bpc.add(Calendar.DATE, 1);
							}
						}
						broadcastMst.setBroadcastDtlList(newBroadcastDtlList);
					}
				}
				
				if(broadcastMst.getBeginPeriod() != null && broadcastMst.getBeginPeriod().length() > 0) {
					broadcastMst.setBeginPeriod(dtf.format(LocalDateTime.parse(broadcastMst.getBeginPeriod()+" 00:00:00", dtf)));
				}
				if(broadcastMst.getEndPeriod() != null && broadcastMst.getEndPeriod().length() > 0) {
					broadcastMst.setEndPeriod(dtf.format(LocalDateTime.parse(broadcastMst.getEndPeriod()+" 00:00:00", dtf)));
				}
			} else if("D".equals(broadcastMst.getBroadcastType())) {			// 즉시방송
				for(BroadcastDtl broadcastDtl : broadcastMst.getBroadcastDtlList()) {
					broadcastDtl.setBroadcastDate(now);
				}
			}
			
			if(broadcastDao.broadcastMstModify(broadcastMst) > 0) {
				
				broadcastDao.broadcastDtlDelete(broadcastMst);							// 수신방송장비목록 초기화
				broadcastDao.sdkVmsSendDelete(broadcastMst.getBroadcastMstSeq());		// 크로샷 DB 초기화
				broadcastDao.sdkVmsSendReportDelete(broadcastMst.getBroadcastMstSeq());	// 크로샷 DB 초기화
				
				broadcastDao.broadcastDtlAdd(broadcastMst);
				sdkVmsSend(broadcastMst, ldt);
				
				res.setCode(HttpStatus.OK.value());
				res.setMessage(HttpStatus.OK.getReasonPhrase());
			} else {
				res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
				res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
			}
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@Override
	public ResponseObject<?> broadcastMstDelete(Integer broadcastMstSeq) throws SqlSessionException {
		ResponseObject<Map<String, Object>> res = new ResponseObject<>();
		
		try {
			BroadcastMst broadcastMst = new BroadcastMst();
			broadcastMst.setBroadcastMstSeq(broadcastMstSeq);
			
			broadcastDao.broadcastMstDelete(broadcastMst);
			broadcastDao.broadcastDtlDelete(broadcastMst);							
			broadcastDao.sdkVmsSendDelete(broadcastMst.getBroadcastMstSeq());		
			broadcastDao.sdkVmsSendReportDelete(broadcastMst.getBroadcastMstSeq());	
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseObject<PaginationList<BroadcastMstList>> vmsSendResultList(Integer currentPage, String userID, String beginSendDate, String endSendDate, String broadcastTitle) throws SqlSessionException {
		ResponseObject<PaginationList<BroadcastMstList>> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			if(currentPage != null)
				params.put("currentPage", currentPage);
			params.put("userID", userID);
			params.put("beginSendDate", beginSendDate);
			params.put("endSendDate", endSendDate);
			params.put("broadcastTitle", broadcastTitle);
			
			params.put("isSend", "Y");	// 전송 완료건만
			
			PaginationList<BroadcastMstList> bml = (PaginationList<BroadcastMstList>) paginationService.paginationSearch("gongju.dao.BroadcastDao.vmsSendResultList", params);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(bml);
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

	@SuppressWarnings("unchecked")
	@Override
	public ResponseObject<PaginationList<BroadcastMstList>> vmsSendReserveList(Integer currentPage, String userID, String beginReserveDate, String endReserveDate, String broadcastTitle) throws SqlSessionException {
		ResponseObject<PaginationList<BroadcastMstList>> res = new ResponseObject<>();
		
		try {
			Map<String, Object> params = new HashMap<>();
			if(currentPage != null)
				params.put("currentPage", currentPage);
			params.put("userID", userID);
			params.put("beginReserveDate", beginReserveDate);
			params.put("endReserveDate", endReserveDate);
			params.put("broadcastTitle", broadcastTitle);
			
			params.put("broadcastType", "R");	// 예약전송
			params.put("isSend", "N");			// 전송 미완료건만
			
			PaginationList<BroadcastMstList> bml = (PaginationList<BroadcastMstList>) paginationService.paginationSearch("gongju.dao.BroadcastDao.vmsSendResultList", params);
			
			res.setCode(HttpStatus.OK.value());
			res.setMessage(HttpStatus.OK.getReasonPhrase());
			res.setData(bml);
		} catch(Exception e) {
			e.printStackTrace();
			
			res.setData(null);
			res.setCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
			res.setMessage(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase());
		}
		
		return res;
	}

}
