package gongju.service.impl;

import java.util.UUID;

import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttAsyncClient;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import gongju.config.props.PathKeys;
import gongju.service.MqttService;
import gongju.utils.MqttCustomCallback;

@Service("mqttService")
public class MqttServiceImpl implements MqttService {

	@Autowired
	private MqttCustomCallback mqttCallback;
	
	public static MqttAsyncClient mqttAsyncClient;
	
	@Override
	@Scheduled(fixedDelay=60000)
	public void mqttAsyncInit() throws MqttException {
		if(mqttAsyncClient == null || !mqttAsyncClient.isConnected()) {
			System.out.println("mqtt connection lost ##");
			
			mqttAsyncClient = new MqttAsyncClient("tcp://" + PathKeys.MQTT_IP + ":" + PathKeys.MQTT_PORT, UUID.randomUUID().toString());
			mqttAsyncClient.setCallback(mqttCallback);
		     
			IMqttToken token = mqttAsyncClient.connect();
			token.waitForCompletion();
		     
			mqttAsyncClient.subscribe("#", 0);
		} else {
			System.out.println("mqtt connection live @@");
		}
	}

}
