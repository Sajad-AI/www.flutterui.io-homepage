package gongju.service;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.AreaMst;
import gongju.model.BroadcastDevice;
import gongju.model.CCTVDevice;
import gongju.model.PaginationList;
import gongju.model.RTUDevice;
import gongju.model.RTUDeviceStatus;
import gongju.model.ResponseObject;
import gongju.model.SensorInfo;
import gongju.model.SensorInfoStatus;
import gongju.model.param.AreaMstAdd;
import gongju.model.param.AreaMstDelete;
import gongju.model.param.AreaMstDetail;
import gongju.model.param.AreaMstList;
import gongju.model.param.AreaMstModify;
import gongju.model.param.BroadcastDeviceDelete;
import gongju.model.param.BroadcastDeviceModify;
import gongju.model.param.CCTVDeviceDelete;
import gongju.model.param.CCTVDeviceModify;
import gongju.model.param.RTUDeviceDelete;
import gongju.model.param.RTUDeviceModify;
import gongju.model.param.SensorInfoDelete;
import gongju.model.param.SensorInfoModify;

public interface AreaService {

	/**
	 * 재해 위험 지역 등록
	 * 
	 * @param areaMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> areaAdd(AreaMstAdd areaMst) throws SqlSessionException;
	
	/**
	 * 재해 위험 지역 수정
	 * 
	 * @param areaMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> areaModify(AreaMstModify areaMst) throws SqlSessionException;
	
	/**
	 * 재해 위험 지역 삭제
	 * 
	 * @param areaMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> areaDelete(AreaMstDelete areaMst) throws SqlSessionException;
	
	/**
	 * 재해 위험 지역 목록
	 * 
	 * @param areaMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<PaginationList<AreaMst>> areaList(AreaMstList areaMst) throws SqlSessionException;
	
	/**
	 * 재해 위험 지역 상세
	 * 
	 * @param areaMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<AreaMst> areaDetail(AreaMstDetail areaMst) throws SqlSessionException;
	
	
	
	/**
	 * CCTV 등록
	 * 
	 * @param cctvDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> cctvDeviceAdd(CCTVDevice cctvDevice) throws SqlSessionException;
	
	/**
	 * CCTV 수정
	 * 
	 * @param cctvDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> cctvDeviceModify(CCTVDeviceModify cctvDevice) throws SqlSessionException;
	
	/**
	 * CCTV 삭제
	 * 
	 * @param cctvDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> cctvDeviceDelete(CCTVDeviceDelete cctvDevice) throws SqlSessionException;
	
	/**
	 * CCTV 상세
	 * 
	 * @param cctvDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<CCTVDevice> cctvDeviceDetail(CCTVDeviceDelete cctvDevice) throws SqlSessionException;
	
	
	
	/**
	 * 방송장비 (비상예경보방송기기 / 마을방송) 등록
	 * 
	 * @param broadcastDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> broadcastDeviceAdd(BroadcastDevice broadcastDevice) throws SqlSessionException;
	
	/**
	 * 방송장비 (비상예경보방송기기 / 마을방송) 수정
	 * 
	 * @param broadcastDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> broadcastDeviceModify(BroadcastDeviceModify broadcastDevice) throws SqlSessionException;
	
	/**
	 * 방송장비 (비상예경보방송기기 / 마을방송) 삭제
	 * 
	 * @param broadcastDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> broadcastDeviceDelete(BroadcastDeviceDelete broadcastDevice) throws SqlSessionException;
	
	/**
	 * 방송장비 (비상예경보방송기기 / 마을방송) 상세
	 * 
	 * @param broadcastDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<BroadcastDevice> broadcastDeviceDetail(BroadcastDeviceDelete broadcastDevice) throws SqlSessionException;
	
	
	
	/**
	 * RTU 등록
	 * 
	 * @param rtuDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> rtuDeviceAdd(RTUDevice rtuDevice) throws SqlSessionException;
	
	/**
	 * RTU 수정
	 * 
	 * @param rtuDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> rtuDeviceModify(RTUDeviceModify rtuDevice) throws SqlSessionException;
	
	/**
	 * RTU 삭제
	 * 
	 * @param rtuDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> rtuDeviceDelete(RTUDeviceDelete rtuDevice) throws SqlSessionException;
	
	/**
	 * RTU 상세
	 * 
	 * @param rtuDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<RTUDevice> rtuDeviceDetail(RTUDeviceDelete rtuDevice) throws SqlSessionException;

	/**
	 * RTU 상태
	 * 
	 * @param rtuDevice
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<RTUDeviceStatus> rtuDeviceStatus(gongju.model.param.RTUDeviceStatusParam rtuDevice) throws SqlSessionException;
	
	
	
	/**
	 * 센서 등록
	 * 
	 * @param sensorInfo
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> sensorInfoAdd(SensorInfo sensorInfo) throws SqlSessionException;
	
	/**
	 * 센서 수정
	 * 
	 * @param sensorInfo
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> sensorInfoModify(SensorInfoModify sensorInfo) throws SqlSessionException;
	
	/**
	 * 센서 삭제
	 * 
	 * @param sensorInfo
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> sensorInfoDelete(SensorInfoDelete sensorInfo) throws SqlSessionException;
	
	/**
	 * 센서 상세
	 * 
	 * @param sensorInfo
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<SensorInfo> sensorInfoDetail(SensorInfoDelete sensorInfo) throws SqlSessionException;
	
	/**
	 * 센서 상태
	 * 
	 * @param sensorInfo
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<SensorInfoStatus> sensorInfoStatus(gongju.model.param.SensorInfoStatusParam sensorInfo) throws SqlSessionException;
	
}
