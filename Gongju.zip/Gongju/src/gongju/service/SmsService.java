package gongju.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.PaginationList;
import gongju.model.ResponseObject;
import gongju.model.SmsGroup;
import gongju.model.SmsMst;
import gongju.model.SmsMstList;
import gongju.model.SmsTemplate;

public interface SmsService {
	
	/**
	 * SMS 그룹 등록
	 * 
	 * @param smsGroupName
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsGroupAdd(String smsGroupName, String userID) throws SqlSessionException;
	
	/**
	 * SMS 그룹 수정
	 * 
	 * @param smsGroupSeq
	 * @param smsGroupName
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsGroupModify(Integer smsGroupSeq, String smsGroupName) throws SqlSessionException;
	
	/**
	 * SMS 그룹 삭제
	 * 
	 * @param smsGroupSeq
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsGroupDelete(Integer smsGroupSeq) throws SqlSessionException;
	
	/**
	 * SMS 그룹 목록
	 * 
	 * @param userID
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<List<SmsGroup>> smsGroupList(String userID) throws SqlSessionException;
	
	/**
	 * SMS 그룹 엑셀
	 * 
	 * @param smsGroupSeq
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsGroupExcel(Integer smsGroupSeq, HttpServletResponse response) throws SqlSessionException;
	
	
	
	/**
	 * SMS 그룹 > 연락처 등록
	 * 
	 * @param smsGroupSeq
	 * @param phoneName
	 * @param phoneNumber
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsPhoneAdd(Integer smsGroupSeq, String phoneName, String phoneNumber) throws SqlSessionException;
	
	/**
	 * SMS 그룹 > 연락처 수정
	 * 
	 * @param smsPhoneSeq
	 * @param phoneName
	 * @param phoneNumber
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsPhoneModify(Integer smsPhoneSeq, String phoneName, String phoneNumber) throws SqlSessionException;
	
	/**
	 * SMS 그룹 > 연락처 삭제
	 * 
	 * @param smsPhoneSeq
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsPhoneDelete(Integer smsPhoneSeq) throws SqlSessionException;
	
	
	
	/**
	 * SMS 문안 등록
	 * 
	 * @param userID
	 * @param smsTemplateTitle
	 * @param smsTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsTemplateAdd(String userID, String smsTemplateTitle, String smsTemplate) throws SqlSessionException;
	
	/**
	 * SMS 문안 수정
	 * 
	 * @param smsTemplateSeq
	 * @param smsTemplateTitle
	 * @param smsTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsTemplateModify(Integer smsTemplateSeq, String smsTemplateTitle, String smsTemplate) throws SqlSessionException;
	
	/**
	 * SMS 문안 삭제
	 * 
	 * @param smsTemplateSeq
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsTemplateDelete(Integer smsTemplateSeq) throws SqlSessionException;
	
	/**
	 * SMS 문안 목록
	 * 
	 * @param userID
	 * @return
	 * @throws SqlSessionExcepton
	 */
	public ResponseObject<PaginationList<SmsTemplate>> smsTemplateList(Integer currentPage, String userID) throws SqlSessionException;
	
	/**
	 * SMS 문안 상세
	 * 
	 * @param userID
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<SmsTemplate> smsTemplateDetail(Integer smsTemplateSeq) throws SqlSessionException;
	
	
	
	/**
	 * SMS 발송
	 * 
	 * @param smsMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsSendAdd(SmsMst smsMst) throws SqlSessionException;
	
	/**
	 * SMS 수정
	 * 
	 * @param smsMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsSendModify(SmsMst smsMst) throws SqlSessionException;
	
	/**
	 * SMS 삭제
	 * 
	 * @param smsMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> smsSendDelete(Integer smsMstSeq) throws SqlSessionException;
	
	/**
	 * SMS 내역
	 * 
	 * @param userID
	 * @param beginSendDate
	 * @param endSendDate
	 * @param smsContent
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<PaginationList<SmsMstList>> smsSendResultList(Integer currentPage, String userID, String beginSendDate, String endSendDate, String smsContent) throws SqlSessionException;
	
	/**
	 * SMS 내역
	 * 
	 * @param userID
	 * @param beginReserveDate
	 * @param endReserveDate
	 * @param smsContent
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<PaginationList<SmsMstList>> smsSendReserveList(Integer currentPage, String userID, String beginReserveDate, String endReserveDate, String smsContent) throws SqlSessionException;
	
}
