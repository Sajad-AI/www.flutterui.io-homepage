package gongju.service;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.PaginationList;
import gongju.model.ResponseObject;
import gongju.model.UserMst;
import gongju.model.param.UserMstDelete;
import gongju.model.param.UserMstList;
import gongju.model.param.UserMstModify;

public interface UserService {
	
	/**
	 * 사용자 목록
	 * 
	 * @param userID
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<PaginationList<UserMst>> userList(UserMstList userMst) throws SqlSessionException;
	
	/**
	 * 사용자 수정
	 * 
	 * @param userMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> userMstModify(UserMstModify userMst) throws SqlSessionException;
	
	/**
	 * 사용자 삭제
	 * 
	 * @param userMst
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<?> userMstDelete(UserMstDelete userMst) throws SqlSessionException;

}
