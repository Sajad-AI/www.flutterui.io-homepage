package gongju.service;

import java.util.Map;

import gongju.model.PaginationList;

public interface PaginationService {
	
	/**
	 * Mybatis 페이징 쿼리 
	 * 
	 * @param statement
	 * @param params {rows , pageNum , currentPage}
	 * @return
	 */
	PaginationList<?> paginationSearch(String statement,Map<String, Object> params);
	
}
