package gongju.service;

import org.eclipse.paho.client.mqttv3.MqttException;

public interface MqttService {
	
	public void mqttAsyncInit() throws MqttException;
	
}
