package gongju.service;

import java.util.List;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.AreaSensor;
import gongju.model.Rainfall;
import gongju.model.ReservoirRate;
import gongju.model.ResponseObject;
import gongju.model.SensorInfoStatusCount;
import gongju.model.param.AreaMstDetail;

public interface MapService {

	/**
	 * 재해 위험 지역 센서값 정보
	 * 
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<AreaSensor> sensorValue(AreaMstDetail areaMst) throws SqlSessionException;
	
	/**
	 * 저수율 정보
	 * 
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<List<ReservoirRate>> reservoirRate() throws SqlSessionException;
	
	/**
	 * 공주시 일강우 현황
	 * 
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<List<Rainfall>> rainfall() throws SqlSessionException;
	
	/**
	 * 통신상태 현황
	 * 
	 * @return
	 * @throws SqlSessionException
	 */
	public ResponseObject<SensorInfoStatusCount> sensorStatus() throws SqlSessionException;
	
}
