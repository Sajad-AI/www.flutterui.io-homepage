package gongju.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.AreaMst;
import gongju.model.BroadcastDevice;
import gongju.model.CCTVDevice;
import gongju.model.RTUDevice;
import gongju.model.RTUDeviceStatus;
import gongju.model.SensorInfo;
import gongju.model.SensorInfoStatus;
import gongju.model.SensorInfoValue;
import gongju.model.param.AreaMstAdd;
import gongju.model.param.AreaMstModify;
import gongju.model.param.BroadcastDeviceDelete;
import gongju.model.param.BroadcastDeviceModify;
import gongju.model.param.CCTVDeviceDelete;
import gongju.model.param.CCTVDeviceModify;
import gongju.model.param.RTUDeviceDelete;
import gongju.model.param.RTUDeviceModify;
import gongju.model.param.SensorInfoDelete;
import gongju.model.param.SensorInfoModify;

@Mapper
public interface AreaDao {

	public int areaMstAdd(AreaMstAdd areaMst) throws SqlSessionException;
	public int cctvDeviceAdd(CCTVDevice cctvDevice) throws SqlSessionException;
	public int broadcastDeviceAdd(BroadcastDevice broadcastDevice) throws SqlSessionException;
	public int rtuDeviceAdd(RTUDevice rtuDevice) throws SqlSessionException;
	public int sensorInfoAdd(SensorInfo sensorInfo) throws SqlSessionException;
	
	public int areaMstModify(AreaMstModify areaMst) throws SqlSessionException;
	public int cctvDeviceModify(CCTVDeviceModify cctvDevice) throws SqlSessionException;
	public int broadcastDeviceModify(BroadcastDeviceModify broadcastDevice) throws SqlSessionException;
	public int rtuDeviceModify(RTUDeviceModify rtuDevice) throws SqlSessionException;
	public int sensorInfoModify(SensorInfoModify sensorInfo) throws SqlSessionException;
	
	public int cctvDeviceDelete(CCTVDeviceDelete cctvDevice) throws SqlSessionException;
	public int broadcastDeviceDelete(BroadcastDeviceDelete broadcastDevice) throws SqlSessionException;
	public int rtuDeviceDelete(RTUDeviceDelete rtuDevice) throws SqlSessionException;
	public int sensorInfoDelete(SensorInfoDelete sensorInfo) throws SqlSessionException;
	
	public int areaMstListCount(Map<String, Object> params) throws SqlSessionException;
	public List<AreaMst> areaMstList(Map<String, Object> params) throws SqlSessionException;
	
	public CCTVDevice cctvDeviceDetail(CCTVDeviceDelete cctvDevice) throws SqlSessionException;
	public BroadcastDevice broadcastDeviceDetail(BroadcastDeviceDelete broadcastDevice) throws SqlSessionException;
	public RTUDevice rtuDeviceDetail(RTUDeviceDelete rtuDevice) throws SqlSessionException;
	public SensorInfo sensorInfoDetail(SensorInfoDelete sensorInfo) throws SqlSessionException;
	
	public RTUDeviceStatus rtuDeviceStatus(gongju.model.param.RTUDeviceStatusParam rtuDevice) throws SqlSessionException;
	public SensorInfoStatus sensorInfoStatus(gongju.model.param.SensorInfoStatusParam sensorInfo) throws SqlSessionException;
	public SensorInfoValue sensorInfoValue(gongju.model.param.SensorInfoStatusParam sensorInfo) throws SqlSessionException;
	
	/*법정동코드 조회*/
	public String getbdongCd(AreaMstAdd areaMst) throws SqlSessionException;
}
