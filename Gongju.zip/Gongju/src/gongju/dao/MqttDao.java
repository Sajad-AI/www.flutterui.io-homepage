package gongju.dao;

import java.util.Map;

import org.apache.ibatis.session.SqlSessionException;

@Mapper
public interface MqttDao {

	public int insertMqttRtuStatus(Map<String, Object> params) throws SqlSessionException;
	
	public int insertMqttSensorStatus(Map<String, Object> params) throws SqlSessionException;
	
	public int insertMqttSensorValue(Map<String, Object> params) throws SqlSessionException;
	
}
