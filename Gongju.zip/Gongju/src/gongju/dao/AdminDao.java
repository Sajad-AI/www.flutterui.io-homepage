package gongju.dao;

@Mapper
public interface AdminDao {

}
