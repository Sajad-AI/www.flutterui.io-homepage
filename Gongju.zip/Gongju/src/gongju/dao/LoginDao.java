package gongju.dao;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.User;

@Mapper
public interface LoginDao {
	
	/**
	 * 계정 등록 신청
	 * 
	 * @param user
	 * @return
	 * @throws SqlSessionException
	 */
	public int insertUser(User user) throws SqlSessionException;
	
	/**
	 * 회원수정
	 * 
	 * @param user
	 * @return
	 * @throws SqlSessionException
	 */
	public int updateUser(User user) throws SqlSessionException;

	/**
	 * Spring Security 로그인 처리에 필요한 비밀번호 검증(id)
	 * 
	 * @param id
	 * @return
	 * @throws SqlSessionException
	 */
	public String getPassword(String id) throws SqlSessionException;
	
	/**
	 * 회원정보 상세보기
	 * 
	 * @param user
	 * @return
	 * @throws SqlSessionException
	 */
	public User getUser(User user) throws SqlSessionException;
	
}