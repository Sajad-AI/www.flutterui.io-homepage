package gongju.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.SensorInfoValue;

@Mapper
public interface MapDao {

	/**
	 * 재해 위험 지역 센서값 정보
	 * 
	 * @param params
	 * @return
	 * @throws SqlSessionException
	 */
	public List<SensorInfoValue> sensorInfoValueList(Map<String, Object> params) throws SqlSessionException;
	
	/**
	 * 재해 위험 지역 센서값 정보 (어제 평균)
	 * 
	 * @param params
	 * @return
	 * @throws SqlSessionException
	 */
	public List<SensorInfoValue> sensorInfoValueYesterdayList(Map<String, Object> params) throws SqlSessionException;
	
	/**
	 * 통신상태 현황
	 * 
	 * @param params
	 * @return
	 * @throws SqlSessionException
	 */
	public int sensorStatusCount(Map<String, Object> params) throws SqlSessionException;
	
}
