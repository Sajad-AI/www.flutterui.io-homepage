package gongju.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.UserMst;
import gongju.model.param.UserMstDelete;
import gongju.model.param.UserMstModify;


@Mapper
public interface UserDao {
	
	/**
	 * 사용자 목록
	 * 
	 * @param UserMst
	 * @return
	 * @throws SqlSessionException
	 */
	public List<UserMst> userMstList(Map<String, Object> params) throws SqlSessionException;
	public int userMstListCount(Map<String, Object> params) throws SqlSessionException;
	
	/*
	 * 사용자 수정
	 */
	public int userMstModify(UserMstModify userMst) throws SqlSessionException;
	
	/*
	 * 사용자 삭제
	 */
	public int userMstDelete(UserMstModify userMst) throws SqlSessionException;

}
