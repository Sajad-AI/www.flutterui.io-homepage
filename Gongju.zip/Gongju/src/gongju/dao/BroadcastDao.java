package gongju.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.BroadcastMst;
import gongju.model.BroadcastMstList;
import gongju.model.BroadcastTemplate;
import gongju.model.param.BroadcastTemplateModify;

@Mapper
public interface BroadcastDao {

	/**
	 * 방송 문안 등록
	 * 
	 * @param broadcastTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public int broadcastTemplateAdd(BroadcastTemplate broadcastTemplate) throws SqlSessionException;
	
	/**
	 * 방송 문안 수정 / 삭제
	 * 
	 * @param broadcastTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public int broadcastTemplateModify(BroadcastTemplateModify broadcastTemplate) throws SqlSessionException;
	
	/**
	 * 방송 문안 목록 / 상세
	 * 
	 * @param params
	 * @return
	 * @throws SqlSessionException
	 */
	public int broadcastTemplateListCount(Map<String, Object> params) throws SqlSessionException;
	public List<BroadcastTemplate> broadcastTemplateList(Map<String, Object> params) throws SqlSessionException;

	
	
	/**
	 * 방송 송출 등록
	 * 
	 * @param broadcastMst
	 * @return
	 * @throws SqlSessionException
	 */
	public int broadcastMstAdd(BroadcastMst broadcastMst) throws SqlSessionException;
	
	/**
	 * 방송 송출 > 전송 수정
	 * 
	 * @param broadcastMst
	 * @return
	 * @throws SqlSessionException
	 */
	public int broadcastMstModify(BroadcastMst broadcastMst) throws SqlSessionException;
	
	/**
	 * 방송 송출 > 전송 삭제
	 * 
	 * @param broadcastMst
	 * @return
	 * @throws SqlSessionException
	 */
	public int broadcastMstDelete(BroadcastMst broadcastMst) throws SqlSessionException;
	
	/**
	 * 방송 송출 > 전송 등록
	 * 
	 * @param broadcastMst
	 * @return
	 * @throws SqlSessionException
	 */
	public int broadcastDtlAdd(BroadcastMst broadcastMst) throws SqlSessionException;
	
	/**
	 * 방송 송출 > 전송 삭제
	 * 
	 * @param broadcastMst
	 * @return
	 * @throws SqlSessionException
	 */
	public int broadcastDtlDelete(BroadcastMst broadcastMst) throws SqlSessionException;
	
	/**
	 * 방송 송출 > 크로샷 등록
	 * 
	 * @param params
	 * @return
	 * @throws SqlSessionException
	 */
	public int sdkVmsSendAdd(Map<String, Object> params) throws SqlSessionException;
	
	/**
	 * 방송 송출 > 크로샷 삭제(예약 수정)
	 * 
	 * @param broadcastMstSeq
	 * @return
	 * @throws SqlSessionException
	 */
	public int sdkVmsSendDelete(Integer broadcastMstSeq) throws SqlSessionException;
	public int sdkVmsSendReportDelete(Integer broadcastMstSeq) throws SqlSessionException;
	
	/**
	 * 방송 송출 내역
	 * 
	 * @param params
	 * @return
	 * @throws SqlSessionException
	 */
	public int vmsSendResultListCount(Map<String, Object> params) throws SqlSessionException;
	public List<BroadcastMstList> vmsSendResultList(Map<String, Object> params) throws SqlSessionException;
	
}
