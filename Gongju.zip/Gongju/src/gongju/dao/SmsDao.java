package gongju.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionException;

import gongju.model.SmsGroup;
import gongju.model.SmsMst;
import gongju.model.SmsMstList;
import gongju.model.SmsPhone;
import gongju.model.SmsTemplate;

@Mapper
public interface SmsDao {

	/**
	 * SMS 그룹 등록
	 * 
	 * @param smsGroup
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsGroupAdd(SmsGroup smsGroup) throws SqlSessionException;
	
	/**
	 * SMS 그룹 수정 / 삭제
	 * 
	 * @param smsGroup
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsGroupModify(SmsGroup smsGroup) throws SqlSessionException;
	
	/**
	 * SMS 그룹 목록
	 * 
	 * @param smsGroup
	 * @return
	 * @throws SqlSessionException
	 */
	public List<SmsGroup> smsGroupList(SmsGroup smsGroup) throws SqlSessionException;
	
	
	
	/**
	 * SMS 그룹 > 연락처 등록
	 * 
	 * @param smsPhone
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsPhoneAdd(SmsPhone smsPhone) throws SqlSessionException;
	
	/**
	 * SMS 그룹 > 연락처 수정
	 * 
	 * @param smsPhone
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsPhoneModify(SmsPhone smsPhone) throws SqlSessionException;
	
	/**
	 * SMS 그룹 > 연락처 삭제
	 * 
	 * @param smsPhone
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsPhoneDelete(SmsPhone smsPhone) throws SqlSessionException;
	
	
	
	/**
	 * SMS 문안 등록
	 * 
	 * @param smsTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsTemplateAdd(SmsTemplate smsTemplate) throws SqlSessionException;
	
	/**
	 * SMS 문안 수정 / 삭제
	 * 
	 * @param smsTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsTemplateModify(SmsTemplate smsTemplate) throws SqlSessionException;
	
	/**
	 * SMS 문안 목록 / 상세
	 * 
	 * @param smsTemplate
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsTemplateListCount(Map<String, Object> params) throws SqlSessionException;
	public List<SmsTemplate> smsTemplateList(Map<String, Object> params) throws SqlSessionException;
	
	
	
	/**
	 * SMS 발송 등록
	 * 
	 * @param smsMst
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsMstAdd(SmsMst smsMst) throws SqlSessionException;

	/**
	 * SMS 발송 수정
	 * 
	 * @param smsMst
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsMstModify(SmsMst smsMst) throws SqlSessionException;
	
	/**
	 * SMS 발송 삭제
	 * 
	 * @param smsMst
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsMstDelete(SmsMst smsMst) throws SqlSessionException;
	
	/**
	 * SMS 발송 > 수신자 목록 등록
	 * 
	 * @param smsMst
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsDtlAdd(SmsMst smsMst) throws SqlSessionException;
	
	/**
	 * SMS 발송 > 수신자 목록 삭제
	 * 
	 * @param smsMSt
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsDtlDelete(SmsMst smsMSt) throws SqlSessionException;
	
	/**
	 * SMS 발송 > 크로샷 등록
	 * 
	 * @param params
	 * @return
	 * @throws SqlSessionException
	 */
	public int sdkSmsSendAdd(Map<String, Object> params) throws SqlSessionException;
	
	/**
	 * SMS 발송 > 크로샷 삭제(예약 수정)
	 * 
	 * @param smsMstSeq
	 * @return
	 */
	public int sdkSmsSendDelete(Integer smsMstSeq) throws SqlSessionException;
	public int sdkSmsSendReportDelete(Integer smsMstSeq) throws SqlSessionException;
	
	/**
	 * SMS 내역
	 * 
	 * @param params
	 * @return
	 * @throws SqlSessionException
	 */
	public int smsSendResultListCount(Map<String, Object> params) throws SqlSessionException;
	public List<SmsMstList> smsSendResultList(Map<String, Object> params) throws SqlSessionException;
}
