package gongju.utils;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import gongju.dao.MqttDao;
import net.sf.json.JSONObject;

@Component
public class MqttCustomCallback implements MqttCallback {

	@Autowired
	MqttDao mqttDao;
	
	@Override
	public void messageArrived(String topic, MqttMessage message) throws Exception {
		try {
			/**
			 * TOPIC TYPE
			 */
			String[] topicArray;
			topicArray = topic.split("/");

			String topicType = "";
	        String rtuID = topicArray[1];
	        String sensorID = "";
	       
	        if("status".equals(topicArray[2])) {
	        	topicType = "RTU_STATUS";
	        } else if("sensor".equals(topicArray[2])) {
	        	sensorID = topicArray[3];
	        	if("status".equals(topicArray[4])) {
	        		topicType = "SENSOR_STATUS";
	        	} else if("value".equals(topicArray[4])) {
	        		topicType = "SENSOR_VALUE";
	        	}
	        }
	        
	        if(StringUtils.isNotBlank(topicType)) {
	        	/**
	        	 * DATA
	        	 */
	        	
	        	String tempMessage = new String(message.getPayload(), StandardCharsets.UTF_8);
	    		JSONObject mObj = JSONObject.fromObject(tempMessage);
	    		JSONAssistUtil.printJsonPretty(mObj);
	    		
	    		Map<String, Object> params = new HashMap<>();
	    		params.put("rtuID", rtuID);
	    		params.put("receiveDate", mObj.get("Date"));
	    		
	    		if("RTU_STATUS".equals(topicType)) {
	    			params.put("rtuStatus",	 		mObj.get("10001"));
	    			params.put("watchdogStatus", 	mObj.get("10002"));
	    			params.put("cdmaModemStatus", 	mObj.get("10003"));
	    			params.put("acStatus", 			mObj.get("10004"));
	    			params.put("batteryStatus", 	mObj.get("10005"));
	    			params.put("doorOpenStatus", 	mObj.get("10006"));
	    			params.put("batteryVoltage", 	mObj.get("31020"));
	    			mqttDao.insertMqttRtuStatus(params);
	    		} else if("SENSOR_STATUS".equals(topicType)) {
	    			params.put("sensorID", sensorID);
	    			params.put("sensorType", 		mObj.get("ID"));
	    			params.put("sensorStatus", 		mObj.get("Status"));
	    			mqttDao.insertMqttSensorStatus(params);
	    		} else if("SENSOR_VALUE".equals(topicType)) {
	    			params.put("sensorID", sensorID);
	    			params.put("valueType", 		mObj.get("ID"));
	    			params.put("unitType", 			mObj.get("Type"));
	    			params.put("dataType", 			mObj.get("DType"));
	    			params.put("dataValue", 		mObj.get("Value"));
	    			mqttDao.insertMqttSensorValue(params);
	    		}
	        }
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void connectionLost(Throwable cause) {
		
	}

	@Override
	public void deliveryComplete(IMqttDeliveryToken token) {
		
	}
	
}
