package gongju.utils;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import net.sf.json.JSONObject;

public class JSONAssistUtil {
	
	/**
	 * JSON System Out
	 * 
	 * @param obj
	 */
	public static void printJsonPretty(JSONObject obj) {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		JsonParser jp = new JsonParser();
		JsonElement je = jp.parse(obj.toString());
		String prettyJsonString = gson.toJson(je);
		
		System.out.println("======================================");
		System.out.println(prettyJsonString);
		System.out.println("======================================");
	}
	
}
