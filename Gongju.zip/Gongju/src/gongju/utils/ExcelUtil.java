package gongju.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.List;
import java.util.Map;

import javax.activation.DataSource;
import javax.mail.util.ByteArrayDataSource;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor.HSSFColorPredefined;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Component;
import org.springframework.util.FileCopyUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ExcelUtil {

	/**
	 * 엑셀 다운로드
	 * 
	 * @param data
	 *            => 실제 데이터 Object
	 * @param header
	 *            => 헤더
	 * @param destination
	 *            => 저장경로
	 * @param fileName
	 *            => 파일명
	 * 
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public void downloadExcel(Map<String, Object> params,HttpServletResponse response) throws Exception {
		// 데이터 변환
		ObjectMapper oMapper = new ObjectMapper();
		List<Map<String, Object>> datas = oMapper.convertValue(params.get("data"), List.class);

		// 헤더 정보
		List<String> headers = (List<String>) params.get("header");
		if (headers == null || headers.size() == 0)
			return;

		Workbook wb = new HSSFWorkbook();
		Sheet sheet = wb.createSheet();
		Row row = null;
		Cell cell = null;

		// 헤더 스타일
		CellStyle headStyle = wb.createCellStyle();

		// 경계선
		headStyle.setBorderTop(BorderStyle.THIN);
		headStyle.setBorderBottom(BorderStyle.THIN);
		headStyle.setBorderLeft(BorderStyle.THIN);
		headStyle.setBorderRight(BorderStyle.THIN);

		// 배경색
		headStyle.setFillForegroundColor(HSSFColorPredefined.GREY_40_PERCENT.getIndex());
		headStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

		// 정렬
		headStyle.setAlignment(HorizontalAlignment.CENTER);

		// 헤더 생성
		row = sheet.createRow(0);
		int k = 0;
		for (String header : headers) {
			cell = row.createCell(k++);
			cell.setCellStyle(headStyle);
			cell.setCellValue(header);
		}

		// 데이터 스타일
		CellStyle bodyStyle = wb.createCellStyle();
		bodyStyle.setBorderTop(BorderStyle.THIN);
		bodyStyle.setBorderBottom(BorderStyle.THIN);
		bodyStyle.setBorderLeft(BorderStyle.THIN);
		bodyStyle.setBorderRight(BorderStyle.THIN);

		// 데이터 생성
		int rowNo = 1;
		for (Map<String, Object> data : datas) {
			row = sheet.createRow(rowNo++);

			k = 0;
			for (String header : headers) {
				cell = row.createCell(k++);
				cell.setCellStyle(bodyStyle);
				cell.setCellValue(data.get(header) == null ? "" : data.get(header).toString());
			}
		}

		// 컬럼 너비 자동조정
		for (int colNum = 0; colNum < row.getLastCellNum(); colNum++) {
			wb.getSheetAt(0).autoSizeColumn(colNum);
		}

		// 컨텐츠 타입, 파일명 지정
		String fileName = (params.get("fileName") != null && params.get("fileName").toString().length() > 0) ? params.get("fileName").toString() : "download";
		DataSource dataSource = null;
		try ( ByteArrayOutputStream bos = new ByteArrayOutputStream() ){
			wb.write(bos);
			dataSource = new ByteArrayDataSource(bos.toByteArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		response.setContentType("apllication/download; charset=" + java.nio.charset.StandardCharsets.UTF_8.toString() + "\"");	
		response.setHeader("Content-Disposition", "attachment; filename=\"" + URLEncoder.encode(fileName,java.nio.charset.StandardCharsets.UTF_8.toString()).replaceAll("\\+", "") + "\";");
		response.setHeader("Content-Transfer-Encoding", "binary");
		try(InputStream is = dataSource.getInputStream();
			OutputStream os = response.getOutputStream();){
			FileCopyUtils.copy(is, os);
		}
	}
}
