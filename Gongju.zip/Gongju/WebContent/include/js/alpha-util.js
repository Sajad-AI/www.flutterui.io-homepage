/*!
* Common Util v0.0.1
* Written by Joker-Park, SouthPaw, Inc.
*/

// 3자리 콤마
function commaSeparateNumber(val){
    while (/(\d+)(\d{3})/.test(val.toString())){
      val = val.toString().replace(/(\d+)(\d{3})/, '$1'+','+'$2');
    }
    return val;
}